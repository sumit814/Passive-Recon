# 🚀 Quick Start - New Features

## 3 New Modules Added

### 1. SSL/TLS Analysis (`ssl`) - Works NOW! ✅
**No API key needed** - Direct TLS connection

```bash
# Test it immediately
python main.py run example.com -m ssl
```

**What it does:**
- Certificate validation & security checks
- Expiry monitoring
- TLS version detection
- Weak cipher identification
- Clear security status

---

### 2. IP Reputation (`iprep`) - Needs 1 FREE Key ⚠️
**Requires:** AbuseIPDB (free)

```bash
# Get free key: https://www.abuseipdb.com/register
# Add to .env: ABUSEIPDB_API_KEY=your_key

# Then test
python main.py run example.com -m iprep
```

**What it does:**
- Multi-source threat intelligence
- IP reputation scoring (VirusTotal, AbuseIPDB, GreyNoise)
- Automatic DNS resolution
- Clear threat level marking

---

### 3. Email Leak Check (`leakcheck`) - Needs Paid Key 💰
**Requires:** HaveIBeenPwned ($3.50/mo)

```bash
# Get key: https://haveibeenpwned.com/API/Key
# Add to .env: HIBP_API_KEY=your_key

# First harvest emails
python main.py run example.com -m email

# Then check for leaks
python main.py run example.com -m leakcheck
```

**What it does:**
- Breach database checking
- Paste/dump detection
- Risk level assessment
- Security recommendations

---

## Quick Commands

```bash
# Check API status
python main.py apikeys

# List all 25 modules
python main.py modules

# Test SSL (works now!)
python main.py run example.com -m ssl

# Run everything
python main.py scan example.com --all
```

---

## What You Need

### Priority 1 (Free - 5 minutes)
1. Install: `pip install pyOpenSSL`
2. Get AbuseIPDB key (free): https://www.abuseipdb.com/register
3. Add to `.env`: `ABUSEIPDB_API_KEY=your_key`

### Priority 2 (Paid - $3.50/mo)
4. Get HIBP key: https://haveibeenpwned.com/API/Key
5. Add to `.env`: `HIBP_API_KEY=your_key`

---

## Documentation

- **CONFIGURE_THESE_KEYS.txt** - Visual guide
- **API_KEYS_NEEDED.md** - Quick reference
- **API_KEYS_GUIDE.md** - Complete setup guide
- **IMPROVEMENTS_SUMMARY.md** - All enhancements
- **SETUP_COMPLETE.md** - Final status

---

## What Works Now

| Feature | Status | Requirement |
|---------|--------|-------------|
| SSL/TLS Analysis | ✅ Full | None |
| IP Reputation | ⚠️ Partial | Free AbuseIPDB key |
| Email Leak Check | ❌ Needs setup | Paid HIBP key |
| All 22 existing modules | ✅ Full | Already configured |

---

## Cost

- **Free**: SSL module + AbuseIPDB
- **$3.50/mo**: Add HIBP for email leak checking
- **Optional**: DeHashed (~$2/100 queries) + LeakCheck ($2/mo)

---

**Next Step:** Run `python main.py run example.com -m ssl` to test SSL analysis (works without any configuration!)
