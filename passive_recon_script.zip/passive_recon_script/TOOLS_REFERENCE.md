# 🛠️ Complete Tools & Data Sources Reference

## Overview

This framework integrates **28+ OSINT sources** across 9 reconnaissance modules. Below is the complete reference of all tools, their purposes, and implementation status.

---

## 📊 Implementation Status Legend

- ✅ **Fully Implemented** - Working and tested
- ⚙️ **Partially Implemented** - Basic functionality working
- 🔧 **Ready to Implement** - API config in place, needs module code
- 📋 **Planned** - Future enhancement
- ⏳ **API Key Required** - Needs user configuration

---

## 🌐 Internet-Wide Scanners

### 1. Shodan.io ✅
**Status**: Fully Implemented  
**Module**: `shodan_search`  
**API Required**: Yes (Free tier: 1 scan/month)

**Purpose**:
- Find internet-exposed devices and services
- Port scanning results
- Service version detection
- Geographic distribution
- Banner grabbing

**Free Tier**: 
- 1 scan per month
- 100 results per scan
- Historical data access

**Upgrade**: $59/month for unlimited

**Get API Key**: https://account.shodan.io/register

**Example Output**:
```json
{
  "ip": "93.184.216.34",
  "port": 443,
  "product": "nginx",
  "version": "1.18.0",
  "organization": "EDGECAST",
  "country": "United States"
}
```

---

### 2. Censys.io ⚙️
**Status**: Partially Implemented (Certificates only)  
**Module**: `certificate_search`  
**API Required**: Yes (Free tier: 250 queries/month)

**Purpose**:
- Internet-wide certificate search
- Host discovery
- Service enumeration
- Historical scanning data

**Free Tier**: 250 queries/month

**Get API Key**: https://censys.io/register

**To Add**: Full host search module

---

### 3. ZoomEye.org 🔧
**Status**: Ready to Implement  
**API Config**: `ZOOMEYE_API_KEY` in config.py  
**API Required**: Yes (Free tier: limited queries)

**Purpose**:
- Cyberspace search engine
- Device fingerprinting
- Vulnerability scanning
- Network mapping

**Free Tier**: Limited queries/day

**Get API Key**: https://www.zoomeye.org/register

**Implementation Template**:
```python
class ZoomEyeModule(BaseModule):
    def __init__(self):
        super().__init__("zoomeye_search")
    
    def collect(self, target: str, **kwargs):
        url = "https://api.zoomeye.org/host/search"
        headers = {'API-KEY': Config.ZOOMEYE_API_KEY}
        params = {'query': target}
        # Implementation here
```

---

### 4. BinaryEdge.io 🔧
**Status**: Ready to Implement  
**API Config**: `BINARYEDGE_API_KEY` in config.py  
**API Required**: Yes (Free tier: 250 queries/month)

**Purpose**:
- Internet scanning platform
- CVE detection
- Data breach monitoring
- Torrent monitoring

**Free Tier**: 250 queries/month

**Get API Key**: https://app.binaryedge.io/sign-up

---

### 5. FOFA.info 🔧
**Status**: Ready to Implement  
**API Config**: `FOFA_EMAIL`, `FOFA_API_KEY` in config.py  
**API Required**: Yes

**Purpose**:
- Cyberspace mapping
- Asset discovery (Chinese platform)
- Network device search

**Get API Key**: https://fofa.info/

---

### 6. Netlas.io 🔧
**Status**: Ready to Implement  
**API Config**: `NETLAS_API_KEY` in config.py  
**API Required**: Yes (Free tier: 50 queries/month)

**Purpose**:
- Internet asset search
- Service detection
- Security scanning

**Free Tier**: 50 queries/month

**Get API Key**: https://app.netlas.io/signup/

---

### 7. LeakIX.net 🔧
**Status**: Ready to Implement  
**API Config**: `LEAKIX_API_KEY` in config.py  
**API Required**: Yes (Free tier available)

**Purpose**:
- Publicly indexed information
- Leak detection
- Exposed database search
- Misconfiguration discovery

**Get API Key**: https://leakix.net/

---

### 8. Onyphe.io 🔧
**Status**: Ready to Implement  
**API Config**: `ONYPHE_API_KEY` in config.py  
**API Required**: Yes

**Purpose**:
- Cyber threat intelligence
- Internet scanning
- Geolocation data

**Get API Key**: https://www.onyphe.io/

---

### 9. GreyNoise.io 🔧
**Status**: Ready to Implement  
**API Config**: `GREYNOISE_API_KEY` in config.py  
**API Required**: Yes (Free community tier)

**Purpose**:
- Internet background noise
- Mass scanner detection
- Benign vs malicious traffic
- Threat intelligence

**Free Tier**: Community edition

**Get API Key**: https://viz.greynoise.io/signup

---

## 🔒 Certificate & SSL Intelligence

### 10. crt.sh ✅
**Status**: Fully Implemented  
**Module**: `subdomain_enum`, `certificate_search`  
**API Required**: No (Public service)

**Purpose**:
- Certificate transparency logs
- Subdomain discovery
- Historical certificates
- Issuer information

**Free**: Unlimited queries

**No Registration Required**

**Best For**: Quick subdomain enumeration

---

### 11. SecurityTrails ✅
**Status**: Fully Implemented  
**Module**: `subdomain_enum`  
**API Required**: Yes (Free tier: 50 queries/month)

**Purpose**:
- Historical DNS data
- WHOIS history
- Subdomain enumeration
- DNS changes tracking

**Free Tier**: 50 API calls/month

**Get API Key**: https://securitytrails.com/app/signup

---

## 🛡️ Threat Intelligence & Vulnerabilities

### 12. VirusTotal ✅
**Status**: Fully Implemented  
**Module**: `virustotal_lookup`, `subdomain_enum`  
**API Required**: Yes (Free tier: 4 req/min)

**Purpose**:
- Domain reputation
- Passive DNS
- Malware detection
- URL analysis

**Free Tier**: 500 requests/day, 4/min

**Get API Key**: https://www.virustotal.com/gui/join-us

---

### 13. Vulners.com 🔧
**Status**: Ready to Implement  
**API Config**: `VULNERS_API_KEY` in config.py  
**API Required**: Yes (Free tier available)

**Purpose**:
- Vulnerability database
- CVE lookup
- Security bulletins
- Exploit database

**Get API Key**: https://vulners.com/

---

### 14. PulseDive.com 🔧
**Status**: Ready to Implement  
**API Config**: `PULSEDIVE_API_KEY` in config.py  
**API Required**: Yes (Free tier available)

**Purpose**:
- Threat intelligence
- IOC tracking
- Risk scoring
- Community feeds

**Get API Key**: https://pulsedive.com/

---

### 15. SocRadar.io 🔧
**Status**: Ready to Implement  
**API Config**: `SOCRADAR_API_KEY` in config.py  
**API Required**: Yes (Enterprise)

**Purpose**:
- Digital risk protection
- Brand monitoring
- Dark web monitoring
- Threat intelligence

---

### 16. FullHunt.io 🔧
**Status**: Ready to Implement  
**API Config**: `FULLHUNT_API_KEY` in config.py  
**API Required**: Yes

**Purpose**:
- Attack surface management
- Subdomain monitoring
- Port scanning
- Asset discovery

---

### 17. AlienVault OTX 🔧
**Status**: Ready to Implement  
**API Config**: `ALIENVAULT_API_KEY` in config.py  
**API Required**: Yes (Free tier available)

**Purpose**:
- Open threat exchange
- IOC sharing
- Threat intelligence
- Community feeds

**Get API Key**: https://otx.alienvault.com/

---

## 💻 Code & Repository Intelligence

### 18. GitHub API ✅
**Status**: Fully Implemented  
**Module**: `github_intel`  
**API Required**: Yes (Free: 5000 req/hour)

**Purpose**:
- Code search
- Repository discovery
- Commit history
- Secret scanning

**Free Tier**: 5000 requests/hour with token

**Get Token**: https://github.com/settings/tokens

---

### 19. grep.app 📋
**Status**: Planned  
**API Required**: No (Web scraping or API if available)

**Purpose**:
- Search GitHub code
- Regex searching
- Fast code discovery

**Website**: https://grep.app/

---

### 20. SearchCode.com 📋
**Status**: Planned  
**API Required**: No (Free API available)

**Purpose**:
- Source code search
- Multiple platforms
- Syntax highlighting

**Website**: https://searchcode.com/

---

## 🌍 Web Intelligence

### 21. URLScan.io ✅
**Status**: Fully Implemented  
**Module**: `urlscan_lookup`  
**API Required**: Optional (Better limits with key)

**Purpose**:
- Website scanning
- Screenshot capture
- Technology detection
- Redirect analysis

**Free**: Unlimited public scans

**Get API Key**: https://urlscan.io/user/signup

---

### 22. PublicWWW.com 🔧
**Status**: Ready to Implement  
**API Config**: `PUBLICWWW_API_KEY` in config.py  
**API Required**: Yes (Paid service)

**Purpose**:
- Source code search
- Website technology search
- Marketing intelligence

**Pricing**: $49+/month

---

### 23. Wayback Machine 📋
**Status**: Planned  
**API Required**: No (Free API)

**Purpose**:
- Historical snapshots
- Deleted content
- Change tracking

**Website**: https://archive.org/web/

---

### 24. CommonCrawl 📋
**Status**: Planned  
**API Required**: No (Free datasets)

**Purpose**:
- Web archive
- Large-scale analysis
- SEO research

**Website**: https://commoncrawl.org/

---

## 📧 Email & People Intelligence

### 25. Hunter.io ✅
**Status**: Fully Implemented  
**Module**: `email_harvesting`  
**API Required**: Yes (Free tier: 25 searches/month)

**Purpose**:
- Email discovery
- Email verification
- Domain search
- Confidence scoring

**Free Tier**: 25 searches/month

**Get API Key**: https://hunter.io/users/sign_up

---

### 26. IntelX.io ✅
**Status**: Fully Implemented  
**Module**: `email_harvesting`  
**API Required**: Yes (Free tier available)

**Purpose**:
- OSINT search engine
- Data breach search
- Darknet data
- Historical records

**Get API Key**: https://intelx.io/signup

---

## 🌐 DNS & Network Intelligence

### 27. DNS Resolver ✅
**Status**: Fully Implemented  
**Module**: `dns_intelligence`  
**API Required**: No

**Purpose**:
- DNS record enumeration
- A, AAAA, MX, NS, TXT, SOA, CNAME
- TTL information

**Free**: Built into Python (dnspython)

---

### 28. WHOIS ✅
**Status**: Fully Implemented  
**Module**: `whois_lookup`  
**API Required**: No

**Purpose**:
- Domain registration info
- Registrar details
- Name servers
- Creation/expiration dates

**Free**: System command

---

### 29. WhoisXML API 🔧
**Status**: Ready to Implement  
**API Config**: `WHOISXML_API_KEY` in config.py  
**API Required**: Yes (Free tier: 500 queries)

**Purpose**:
- Enhanced WHOIS data
- Historical WHOIS
- Reverse WHOIS
- Domain availability

**Get API Key**: https://whoisxmlapi.com/

---

### 30. WiGLE.net 🔧
**Status**: Ready to Implement  
**API Config**: `WIGLE_API_NAME`, `WIGLE_API_TOKEN` in config.py  
**API Required**: Yes (Free tier available)

**Purpose**:
- Wireless network database
- SSID tracking
- Geolocation
- Network mapping

**Get API Key**: https://wigle.net/

---

### 31. IPInfo.io 🔧
**Status**: Ready to Implement  
**API Config**: `IPINFO_TOKEN` in config.py  
**API Required**: Yes (Free tier: 50k req/month)

**Purpose**:
- IP geolocation
- ASN information
- Company data
- Hosting provider

**Free Tier**: 50,000 requests/month

**Get API Key**: https://ipinfo.io/signup

---

### 32. BGPView 📋
**Status**: Planned  
**API Required**: No (Free API)

**Purpose**:
- BGP routing data
- ASN lookup
- IP prefix information
- Peer relationships

**Website**: https://bgpview.io/

---

## 📊 Summary by Category

### Implemented (9 modules, 12 sources)
1. ✅ Shodan
2. ✅ Censys (Certificates)
3. ✅ crt.sh
4. ✅ SecurityTrails
5. ✅ VirusTotal
6. ✅ GitHub
7. ✅ URLScan
8. ✅ Hunter.io
9. ✅ IntelX
10. ✅ DNS Resolver
11. ✅ WHOIS
12. ✅ crt.sh (Subdomain)

### Ready to Implement (15 sources)
13. 🔧 ZoomEye
14. 🔧 BinaryEdge
15. 🔧 FOFA
16. 🔧 Netlas
17. 🔧 LeakIX
18. 🔧 Onyphe
19. 🔧 GreyNoise
20. 🔧 Vulners
21. 🔧 PulseDive
22. 🔧 SocRadar
23. 🔧 FullHunt
24. 🔧 AlienVault OTX
25. 🔧 PublicWWW
26. 🔧 WhoisXML
27. 🔧 WiGLE

### Planned (5 sources)
28. 📋 grep.app
29. 📋 SearchCode
30. 📋 Wayback Machine
31. 📋 CommonCrawl
32. 📋 BGPView

---

## 🆓 Free vs Paid Breakdown

### Completely Free (No Registration)
- crt.sh
- DNS Resolver
- WHOIS
- grep.app
- BGPView

### Free Tier (Registration Required)
- Shodan (1 scan/month)
- Censys (250 queries/month)
- VirusTotal (500/day)
- GitHub (5000/hour)
- URLScan (unlimited public)
- Hunter.io (25/month)
- SecurityTrails (50/month)
- AlienVault OTX
- GreyNoise (Community)
- IPInfo (50k/month)

### Paid Only
- PublicWWW
- SocRadar
- Some advanced features of other tools

---

## 🎯 Recommended Setup

### Minimum (Free)
```bash
GITHUB_TOKEN=xxx           # Must have
VIRUSTOTAL_API_KEY=xxx     # Recommended
```

### Optimal (Free)
```bash
GITHUB_TOKEN=xxx
VIRUSTOTAL_API_KEY=xxx
SHODAN_API_KEY=xxx
SECURITYTRAILS_API_KEY=xxx
HUNTER_API_KEY=xxx
URLSCAN_API_KEY=xxx
```

### Complete (Free + Some Paid)
All of the above plus:
```bash
CENSYS_API_ID=xxx
CENSYS_API_SECRET=xxx
ZOOMEYE_API_KEY=xxx
BINARYEDGE_API_KEY=xxx
NETLAS_API_KEY=xxx
```

---

## 📝 Quick Reference Table

| Tool | Module | Free? | API Needed | Best For |
|------|--------|-------|------------|----------|
| Shodan | shodan_search | Limited | Yes | Exposed services |
| crt.sh | subdomain_enum | Yes | No | Subdomains |
| GitHub | github_intel | Yes | Yes | Code/secrets |
| VirusTotal | virustotal_lookup | Yes | Yes | Reputation |
| Hunter.io | email_harvesting | Limited | Yes | Emails |
| URLScan | urlscan_lookup | Yes | Optional | Web scanning |
| DNS | dns_intelligence | Yes | No | DNS records |
| WHOIS | whois_lookup | Yes | No | Registration |
| Censys | certificate_search | Limited | Yes | Certificates |

---

**Last Updated**: 2025-12-16  
**Total Sources**: 32+  
**Implemented**: 12  
**Ready**: 15  
**Planned**: 5
