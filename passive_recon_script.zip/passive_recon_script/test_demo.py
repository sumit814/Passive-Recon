#!/usr/bin/env python3
"""
Demo/Test Script for Passive Recon Framework
Tests modules without requiring API keys
"""

import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from modules import DNSIntelligenceModule, WhoisModule, SubdomainEnumModule
from rich.console import Console
from rich.panel import Panel

console = Console()

def test_dns_module():
    """Test DNS Intelligence Module (no API required)"""
    console.print("\n[bold cyan]Testing DNS Intelligence Module[/bold cyan]")
    console.print("Target: example.com\n")
    
    try:
        module = DNSIntelligenceModule()
        results = module.run("example.com")
        
        if results:
            console.print("[green]✓ DNS Module working![/green]")
            console.print(f"Results saved to: {results.get('json')}\n")
            return True
        else:
            console.print("[yellow]⚠ No results, but module executed[/yellow]\n")
            return True
    except Exception as e:
        console.print(f"[red]✗ DNS Module failed: {str(e)}[/red]\n")
        return False

def test_whois_module():
    """Test WHOIS Module (no API required)"""
    console.print("[bold cyan]Testing WHOIS Module[/bold cyan]")
    console.print("Target: example.com\n")
    
    try:
        module = WhoisModule()
        results = module.run("example.com")
        
        if results:
            console.print("[green]✓ WHOIS Module working![/green]")
            console.print(f"Results saved to: {results.get('json')}\n")
            return True
        else:
            console.print("[yellow]⚠ No results, but module executed[/yellow]\n")
            return True
    except Exception as e:
        console.print(f"[red]✗ WHOIS Module failed: {str(e)}[/red]\n")
        return False

def test_subdomain_module():
    """Test Subdomain Enumeration Module (uses free crt.sh)"""
    console.print("[bold cyan]Testing Subdomain Enumeration Module[/bold cyan]")
    console.print("Target: example.com (using crt.sh - no API required)\n")
    
    try:
        module = SubdomainEnumModule()
        results = module.run("example.com")
        
        if results:
            console.print("[green]✓ Subdomain Module working![/green]")
            console.print(f"Results saved to: {results.get('json')}\n")
            return True
        else:
            console.print("[yellow]⚠ No results, but module executed[/yellow]\n")
            return True
    except Exception as e:
        console.print(f"[red]✗ Subdomain Module failed: {str(e)}[/red]\n")
        return False

def main():
    """Run all tests"""
    console.print(Panel.fit(
        "[bold cyan]Passive Recon Framework - Demo Test[/bold cyan]\n"
        "Testing modules that don't require API keys",
        border_style="cyan"
    ))
    
    results = {
        "DNS Intelligence": test_dns_module(),
        "WHOIS Lookup": test_whois_module(),
        "Subdomain Enumeration": test_subdomain_module(),
    }
    
    console.print("\n" + "="*60 + "\n")
    console.print("[bold]Test Summary:[/bold]\n")
    
    passed = sum(results.values())
    total = len(results)
    
    for test_name, result in results.items():
        status = "[green]✓ PASS[/green]" if result else "[red]✗ FAIL[/red]"
        console.print(f"{status} - {test_name}")
    
    console.print(f"\n[bold]Results: {passed}/{total} tests passed[/bold]")
    
    if passed == total:
        console.print("\n[green]✓ All tests passed! Framework is ready to use.[/green]")
        console.print("\n[dim]Next steps:[/dim]")
        console.print("1. Configure API keys in .env file")
        console.print("2. Run: python main.py modules")
        console.print("3. Run: python main.py scan yourtarget.com --all\n")
    else:
        console.print("\n[yellow]⚠ Some tests failed. Check the errors above.[/yellow]\n")
    
    return passed == total

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
