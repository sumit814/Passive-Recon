# 🔧 Troubleshooting Guide

## Common Issues & Solutions

### ❌ Issue: "Request failed with status 404" or "Request failed with status 401"

**Cause**: API key is incorrect, expired, or the target format is wrong

**Solutions**:

1. **Check Target Format**:
```bash
# ❌ WRONG - Don't include protocol or trailing slash
python main.py run https://example.com/ -m subdomain

# ✅ CORRECT - Just the domain
python main.py run example.com -m subdomain
```

The framework now **automatically cleans** URLs, but it's best to provide clean domains.

2. **Verify API Keys**:
```bash
# Check which keys are configured
python main.py apikeys

# Edit .env file if needed
nano .env
```

3. **Test API Keys**:
```bash
# Test with free modules first
python main.py run example.com -m dns       # No API needed
python main.py run example.com -m whois     # No API needed
python main.py run example.com -m subdomain # Uses free crt.sh
```

---

### ❌ Issue: "No data collected by [module]"

**Cause**: Target doesn't have data in that source, or API limits reached

**Solutions**:

1. **This is Normal!** - Not all targets have data everywhere
   - Small domains may not be in Shodan/Censys
   - New domains may not be in certificate transparency logs
   - Private companies may not have public GitHub repos

2. **Try Different Modules**:
```bash
# If subdomain fails, try others
python main.py run example.com -m dns
python main.py run example.com -m whois
python main.py run example.com -m certificate
```

3. **Check API Rate Limits**:
   - Free tiers have limits (e.g., Shodan: 1 scan/month)
   - Wait and try again later
   - Or upgrade to paid tier

---

### ❌ Issue: "Request timeout"

**Cause**: Network issues or API server slow

**Solutions**:

1. **Check Internet Connection**:
```bash
ping -c 3 google.com
```

2. **Try Again** - Timeout errors are usually temporary

3. **Use Different Module**:
```bash
# If one times out, try others
python main.py run example.com -m dns
```

---

### ❌ Issue: Target Format Problems

**Problem**: You have URLs but framework expects domains

**Solution**: Framework now auto-cleans! But here's the proper format:

```bash
# ✅ All these work now (auto-cleaned):
python main.py run https://example.com -m subdomain
python main.py run http://example.com/ -m dns  
python main.py run example.com:443 -m whois

# They're converted to:
example.com
```

**See cleaning in action**:
```bash
$ python main.py run https://example.com/ -m dns
Cleaned target: https://example.com/ → example.com
[Scan proceeds...]
```

---

### ❌ Issue: Module Not Found

**Error**: `ModuleNotFoundError: No module named 'X'`

**Solutions**:

1. **Install Dependencies**:
```bash
pip install --break-system-packages -r requirements.txt
```

2. **Check Python Version**:
```bash
python --version  # Should be 3.8+
```

3. **Reinstall Specific Package**:
```bash
pip install --break-system-packages <package-name>
```

---

### ❌ Issue: API Key Not Working

**Error**: `Request failed with status 401` or `403`

**Solutions**:

1. **Verify API Key Format**:
```bash
# Check .env file
cat .env | grep -v '^#' | grep API_KEY

# Keys should not have quotes or extra spaces
SHODAN_API_KEY=abc123xyz    # ✅ Correct
SHODAN_API_KEY="abc123xyz"  # ❌ Wrong (has quotes)
SHODAN_API_KEY= abc123xyz   # ❌ Wrong (has space)
```

2. **Get New API Key**:
   - Go to service website
   - Generate new key
   - Replace in .env

3. **Test Specific Service**:
```bash
# Test Shodan
python main.py run example.com -m shodan

# Check if error persists
```

---

### ❌ Issue: Empty Results / Zero Findings

**Situation**: Scan completes but finds nothing

**This is OK!** Reasons:

1. **Target is New**:
   - Recently registered domains have less data
   - Give it time to appear in databases

2. **Target is Private**:
   - Internal/private infrastructure won't be public
   - Employee emails may not be publicly listed

3. **Limited Free Tier**:
   - Some APIs limit free results
   - Upgrade for more data

**What to Do**:
```bash
# Try all modules to get complete picture
python main.py scan example.com --all

# Check which modules found data
ls -lh outputs/*/data.json
```

---

### ❌ Issue: Censys "401 Unauthorized"

**Cause**: Censys API authentication format

**Solution**:

Your Censys credentials should be in this format:
```bash
CENSYS_API_ID=your_api_id_here
CENSYS_API_SECRET=your_api_secret_here
```

**NOT** the same value for both. Get proper credentials from:
https://censys.io/account/api

---

### ❌ Issue: Shodan "403 Forbidden"

**Cause**: API key is invalid or quota exceeded

**Solutions**:

1. **Check Quota**:
   - Free tier: 1 scan/month
   - Log into Shodan dashboard to check usage

2. **Verify API Key**:
```bash
# Test with Shodan CLI
curl "https://api.shodan.io/api-info?key=YOUR_KEY"
```

3. **Wait for Reset** or upgrade to paid plan

---

### ❌ Issue: SecurityTrails "404 Not Found"

**Cause**: Target doesn't exist in their database

**Solution**:

This is normal for:
- New domains
- Very small websites
- Non-indexed sites

Try other subdomain sources:
```bash
# crt.sh doesn't require API
python main.py run example.com -m certificate
```

---

### ❌ Issue: GitHub Rate Limiting

**Error**: `Request failed with status 403`

**Solutions**:

1. **Check Token**:
```bash
# Verify GitHub token in .env
grep GITHUB_TOKEN .env
```

2. **Token Permissions**:
   - Go to https://github.com/settings/tokens
   - Generate new token with `public_repo` and `read:user` scopes

3. **Rate Limits**:
   - Without token: 60 requests/hour
   - With token: 5000 requests/hour

---

### ❌ Issue: DNS Resolution Fails

**Error**: Domain doesn't resolve or "NXDOMAIN"

**Solutions**:

1. **Check Domain Exists**:
```bash
# Test DNS manually
dig example.com
nslookup example.com
```

2. **Use Correct Domain**:
```bash
# ✅ Correct
python main.py run example.com -m dns

# ❌ Wrong (subdomain might not exist)
python main.py run nonexistent.example.com -m dns
```

3. **Try WHOIS Instead**:
```bash
python main.py run example.com -m whois
```

---

### ❌ Issue: WHOIS Returns No Data

**Cause**: Domain doesn't exist or WHOIS privacy enabled

**Solutions**:

1. **Check Domain Registration**:
```bash
whois example.com
```

2. **Some Domains Hide WHOIS**:
   - Privacy protection enabled
   - Certain TLDs (.gov, some ccTLDs)
   - Use other modules instead

---

### ❌ Issue: Output Files Not Generated

**Cause**: Permission issues or disk space

**Solutions**:

1. **Check Permissions**:
```bash
# Check outputs directory
ls -ld outputs/

# Fix permissions if needed
chmod 755 outputs/
```

2. **Check Disk Space**:
```bash
df -h
```

3. **Verify Output Generation**:
```bash
# Check if files were created
ls -lh outputs/subdomain_enumeration/

# Should see data.json and report.html
```

---

## 🔍 Debugging Tips

### Enable Verbose Output

```bash
# Run with Python's verbose flag
python -v main.py run example.com -m subdomain
```

### Check API Connectivity

```bash
# Test individual APIs
curl "https://crt.sh/?q=%.example.com&output=json"
curl -H "x-apikey: YOUR_VT_KEY" "https://www.virustotal.com/api/v3/domains/example.com"
```

### View Raw JSON Output

```bash
# Pretty print JSON
cat outputs/subdomain_enumeration/data.json | jq '.'

# Check metadata
cat outputs/subdomain_enumeration/data.json | jq '.metadata'

# Count results
cat outputs/subdomain_enumeration/data.json | jq '.results | length'
```

### Test Individual Modules

```bash
# Test each module separately
for module in dns whois subdomain certificate; do
    echo "Testing $module..."
    python main.py run example.com -m $module
done
```

---

## 📊 Verification Checklist

Use this checklist to verify your setup:

- [ ] `python main.py --help` works
- [ ] `python main.py modules` shows all 9 modules
- [ ] `python main.py apikeys` shows configured keys
- [ ] `python main.py run example.com -m dns` returns results
- [ ] `python main.py run example.com -m whois` returns results
- [ ] `python main.py run example.com -m subdomain` returns results
- [ ] Output files generated in `outputs/*/`
- [ ] HTML reports can be opened in browser
- [ ] JSON files can be parsed with `jq`

---

## 🆘 Still Having Issues?

### Check These Files:

1. **Configuration**:
```bash
cat .env | grep -v '^#' | grep -v '^$'
```

2. **Logs**:
```bash
# Run with error output
python main.py run example.com -m subdomain 2>&1 | tee scan.log
```

3. **Dependencies**:
```bash
pip list | grep -E "(requests|rich|click|dnspython)"
```

### Common Fixes:

```bash
# Reinstall everything
pip install --break-system-packages --upgrade -r requirements.txt

# Clear cache
rm -rf __pycache__/ outputs/* 

# Fresh start
cd /home/Vangdu/passive_recon_script
python main.py interactive
```

---

## 📚 Additional Help

- Read: `cat HOW_TO_USE.md` - Complete usage guide
- Read: `cat QUICKSTART.md` - Quick start
- Read: `cat EXAMPLES.md` - Usage examples
- Check: `python main.py --help` - All commands

---

## ✅ Quick Test

Run this to verify everything works:

```bash
# Test 1: DNS (no API needed)
python main.py run example.com -m dns

# Test 2: WHOIS (no API needed)
python main.py run example.com -m whois

# Test 3: Subdomain (uses free crt.sh)
python main.py run example.com -m subdomain

# If all 3 work, your setup is good!
```

---

**Remember**: The framework now automatically cleans domain inputs, so you can paste URLs directly!

```bash
# All these work now:
python main.py run https://example.com/ -m dns
python main.py run http://www.example.com -m dns
python main.py run example.com:443 -m dns
```
