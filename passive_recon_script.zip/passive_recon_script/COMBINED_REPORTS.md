# 📊 Combined Reports Feature

## ✅ NEW FEATURE: All-in-One Report

Your framework now automatically generates a **combined report** that merges results from **all 20 modules** into a single beautiful report!

---

## 🎯 What is a Combined Report?

After running multiple modules (especially with `--all`), the framework generates:

1. **Combined JSON** - All results in one machine-readable file
2. **Combined HTML** - Beautiful interactive report with all data

---

## 📁 Where Are Combined Reports Saved?

```
outputs/
└── combined_report/
    ├── all_results.json    # All results in JSON format
    └── all_results.html    # Beautiful HTML report
```

---

## 🚀 How to Generate Combined Reports

### **Automatic Generation**

Combined reports are **automatically generated** when you run:

```bash
# Scan with all modules
python main.py scan example.com --all

# Output includes:
# ✓ Individual module reports (20 folders)
# ✓ Combined report (1 folder with all data)
```

### **What You See**

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                            Scan Summary
╔══════════════╦═════════╦═══════════════════════════════╗
║ Module       ║ Results ║ Output Location               ║
╠══════════════╬═════════╬═══════════════════════════════╣
║ Subdomain    ║      71 ║ outputs/subdomain.../data.json║
║ Certificate  ║     592 ║ outputs/certificate.../...    ║
║ ... (18 more modules) ...                              ║
╚══════════════╩═════════╩═══════════════════════════════╝

📊 Generating combined report...
✓ Combined report generated!

📄 Combined Reports:
  JSON: /home/.../outputs/combined_report/all_results.json
  HTML: /home/.../outputs/combined_report/all_results.html

💡 Open the HTML file in your browser to see all results in one place!
```

---

## 📊 Combined HTML Report Features

### **Interactive Dashboard**

The HTML report includes:

✅ **Summary Statistics**
   - Total results across all modules
   - Number of modules executed
   - Successful modules count
   - Module breakdown

✅ **Beautiful Design**
   - Gradient header
   - Responsive layout
   - Professional styling
   - Print-friendly

✅ **Collapsible Sections**
   - Each module is a section
   - Click to expand/collapse
   - First 3 modules expanded by default
   - Easy navigation

✅ **Data Tables**
   - All results in sortable tables
   - Hover effects
   - Clean presentation
   - Scrollable content

---

## 📄 Combined JSON Structure

```json
{
  "target": "example.com",
  "scan_time": "2025-12-16T17:51:30.123456",
  "total_results": 859,
  "modules_executed": 20,
  "modules_with_results": 13,
  "modules": {
    "subdomain_enumeration": {
      "result_count": 71,
      "results": [
        {...},
        {...}
      ],
      "metadata": {...},
      "scan_info": {...}
    },
    "certificate_search": {
      "result_count": 592,
      "results": [...]
    },
    ... (18 more modules)
  }
}
```

---

## 🎨 HTML Report Preview

```
┌─────────────────────────────────────────────────────────┐
│        🎯 Combined Reconnaissance Report                │
│                Target: example.com                       │
│         Scan completed: 2025-12-16 17:51:30             │
├─────────────────────────────────────────────────────────┤
│  ╔═════════╗  ╔═════════╗  ╔═════════╗  ╔═════════╗   │
│  ║   859   ║  ║   20    ║  ║   13    ║  ║   20    ║   │
│  ║ Total   ║  ║ Modules ║  ║Success  ║  ║ Total   ║   │
│  ║ Results ║  ║Executed ║  ║ Modules ║  ║ Modules ║   │
│  ╚═════════╝  ╚═════════╝  ╚═════════╝  ╚═════════╝   │
├─────────────────────────────────────────────────────────┤
│ 📊 Module Summary                                       │
│  subdomain_enumeration → 71 results                    │
│  certificate_search → 592 results                      │
│  dns_intelligence → 18 results                         │
│  ... (17 more modules)                                 │
├─────────────────────────────────────────────────────────┤
│ ▼ subdomain_enumeration                     71 results │
│   ┌──────────────────────────────────────────────────┐│
│   │ Subdomain       | IP         | Source     | ... ││
│   ├──────────────────────────────────────────────────┤│
│   │ www.example.com | 93.184... | crt.sh    | ... ││
│   │ api.example.com | 93.184... | SecurityT | ... ││
│   └──────────────────────────────────────────────────┘│
│                                                         │
│ ▶ certificate_search                       592 results │
│ ▶ dns_intelligence                          18 results │
│ ... (17 more collapsed modules)                        │
└─────────────────────────────────────────────────────────┘
```

---

## 🔍 Use Cases

### **1. Quick Overview**

```bash
# Run full scan
python main.py scan target.com --all

# Open combined report
xdg-open outputs/combined_report/all_results.html

# See everything at once!
```

### **2. Executive Summary**

Share the combined HTML report with your team/client:
- Professional presentation
- All data in one place
- No need to check 20 separate files

### **3. Data Analysis**

Use combined JSON for automated analysis:

```bash
# Total results
jq '.total_results' outputs/combined_report/all_results.json

# Results per module
jq '.modules | to_entries[] | "\(.key): \(.value.result_count)"' \
  outputs/combined_report/all_results.json

# Extract specific module data
jq '.modules.subdomain_enumeration.results' \
  outputs/combined_report/all_results.json
```

### **4. Bug Bounty Reports**

```bash
# Scan target
python main.py scan bugbounty.com --all

# Combined report has:
# - All subdomains discovered
# - All certificates found
# - All exposed services
# - All GitHub leaks
# - Everything in one file!

# Perfect for bounty submission!
```

---

## 💡 Tips & Tricks

### **View in Browser**

```bash
# Linux
xdg-open outputs/combined_report/all_results.html

# macOS
open outputs/combined_report/all_results.html

# Windows
start outputs/combined_report/all_results.html
```

### **Search All Results**

```bash
# Search for keyword across all modules
jq '.. | .results[]? | select(.subdomain? | contains("admin"))' \
  outputs/combined_report/all_results.json
```

### **Export to CSV**

```bash
# Extract all results to CSV
jq -r '.modules | to_entries[] | 
  .value.results[] | 
  [.subdomain, .ip, .source] | 
  @csv' outputs/combined_report/all_results.json > all_results.csv
```

### **Count Results by Module**

```bash
jq '.modules | to_entries | 
  sort_by(.value.result_count) | 
  reverse | 
  .[] | 
  "\(.key): \(.value.result_count)"' \
  outputs/combined_report/all_results.json
```

---

## 📊 Benefits of Combined Reports

| Feature | Individual Reports | Combined Report |
|---------|-------------------|-----------------|
| **Files to check** | 20 separate files | 1 file |
| **Navigation** | Switch between files | Click to expand |
| **Overview** | Manual calculation | Automatic summary |
| **Sharing** | Share 20 files | Share 1 file |
| **Analysis** | Parse 20 JSONs | Parse 1 JSON |
| **Presentation** | Multiple tabs | Single dashboard |

---

## 🎯 Real-World Example

```bash
# Scan a target
$ python main.py scan c9lab.com --all

# What you get:
📁 outputs/
   ├── subdomain_enumeration/
   │   ├── data.json (71 results)
   │   └── report.html
   ├── certificate_search/
   │   ├── data.json (592 results)
   │   └── report.html
   ├── ... (18 more module folders)
   └── combined_report/          ← NEW!
       ├── all_results.json      ← All 859 results!
       └── all_results.html      ← Beautiful dashboard!

# Open combined report:
$ xdg-open outputs/combined_report/all_results.html

# See:
✓ 859 total results
✓ From 20 modules
✓ In one beautiful report
✓ Interactive & collapsible
✓ Perfect for presentations!
```

---

## 🎊 Summary

**Before**: Check 20 separate files  
**After**: Check 1 combined report! 🎉

**Individual reports**: Still there for detailed analysis  
**Combined report**: Perfect for overview and sharing!

---

## 🚀 Try It Now!

```bash
# Run full scan
python main.py scan example.com --all

# Open combined report
xdg-open outputs/combined_report/all_results.html

# Enjoy all your results in one place! 🎯
```

---

**You asked for combined reports - You got them!** ✅

**Sabhi results ek saath, alag alag bhi! Perfect!** 🎉
