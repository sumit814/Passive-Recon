#!/bin/bash

###############################################################################
# Batch Scanning Script for Passive Recon Framework
# Usage: ./batch_scan.sh targets.txt
# Example targets.txt:
#   target1.com
#   target2.com
#   target3.com
###############################################################################

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_BASE_DIR="$SCRIPT_DIR/batch_results"
DELAY_BETWEEN_SCANS=60  # seconds
DATE=$(date +%Y%m%d_%H%M%S)

# Banner
echo -e "${BLUE}"
echo "╔════════════════════════════════════════════════╗"
echo "║    Passive Recon Framework - Batch Scanner    ║"
echo "╚════════════════════════════════════════════════╝"
echo -e "${NC}"

# Check if target file is provided
if [ -z "$1" ]; then
    echo -e "${RED}Error: No target file provided${NC}"
    echo "Usage: $0 targets.txt"
    echo ""
    echo "Example targets.txt:"
    echo "  example.com"
    echo "  target.org"
    echo "  company.net"
    exit 1
fi

TARGET_FILE="$1"

# Check if target file exists
if [ ! -f "$TARGET_FILE" ]; then
    echo -e "${RED}Error: Target file '$TARGET_FILE' not found${NC}"
    exit 1
fi

# Count targets
TOTAL_TARGETS=$(grep -v '^#' "$TARGET_FILE" | grep -v '^$' | wc -l)
echo -e "${GREEN}Found $TOTAL_TARGETS targets to scan${NC}"
echo ""

# Create output directory
BATCH_OUTPUT="$OUTPUT_BASE_DIR/scan_$DATE"
mkdir -p "$BATCH_OUTPUT"
echo -e "${BLUE}Results will be saved to: $BATCH_OUTPUT${NC}"
echo ""

# Confirm before starting
echo -e "${YELLOW}This will scan $TOTAL_TARGETS targets${NC}"
echo -e "${YELLOW}Estimated time: ~$((TOTAL_TARGETS * 5)) minutes${NC}"
read -p "Continue? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Scan cancelled."
    exit 1
fi

echo ""
echo -e "${GREEN}Starting batch scan...${NC}"
echo ""

# Initialize counters
SUCCESS=0
FAILED=0
CURRENT=0

# Scan each target
while IFS= read -r target; do
    # Skip comments and empty lines
    [[ "$target" =~ ^#.*$ ]] && continue
    [[ -z "$target" ]] && continue
    
    CURRENT=$((CURRENT + 1))
    
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}[$CURRENT/$TOTAL_TARGETS] Scanning: $target${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    
    # Create target-specific output directory
    TARGET_OUTPUT="$BATCH_OUTPUT/$target"
    mkdir -p "$TARGET_OUTPUT"
    
    # Run scan
    if python "$SCRIPT_DIR/main.py" scan "$target" --all --output "$TARGET_OUTPUT" 2>&1 | tee "$TARGET_OUTPUT/scan.log"; then
        echo -e "${GREEN}✓ Successfully scanned $target${NC}"
        SUCCESS=$((SUCCESS + 1))
        
        # Count total results
        TOTAL_RESULTS=0
        for json_file in "$TARGET_OUTPUT"/*/data.json; do
            if [ -f "$json_file" ]; then
                COUNT=$(jq -r '.metadata.record_count // 0' "$json_file" 2>/dev/null || echo "0")
                TOTAL_RESULTS=$((TOTAL_RESULTS + COUNT))
            fi
        done
        echo -e "${GREEN}  Total results found: $TOTAL_RESULTS${NC}"
        
    else
        echo -e "${RED}✗ Failed to scan $target${NC}"
        FAILED=$((FAILED + 1))
    fi
    
    # Delay between scans (except for last target)
    if [ $CURRENT -lt $TOTAL_TARGETS ]; then
        echo ""
        echo -e "${YELLOW}Waiting $DELAY_BETWEEN_SCANS seconds before next scan...${NC}"
        sleep $DELAY_BETWEEN_SCANS
        echo ""
    fi
    
done < "$TARGET_FILE"

# Final summary
echo ""
echo -e "${BLUE}╔════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║              BATCH SCAN COMPLETE               ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${GREEN}Successful scans: $SUCCESS${NC}"
echo -e "${RED}Failed scans: $FAILED${NC}"
echo -e "${BLUE}Total targets: $TOTAL_TARGETS${NC}"
echo ""
echo -e "${BLUE}Results saved to: $BATCH_OUTPUT${NC}"
echo ""

# Generate index HTML
INDEX_FILE="$BATCH_OUTPUT/index.html"
cat > "$INDEX_FILE" << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>Batch Scan Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        h1 {
            color: #333;
            text-align: center;
        }
        .target {
            background: white;
            margin: 20px 0;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .target h2 {
            color: #667eea;
            margin-top: 0;
        }
        .modules {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 10px;
            margin-top: 15px;
        }
        .module {
            padding: 10px;
            background: #f8f9fa;
            border-radius: 4px;
            text-align: center;
        }
        .module a {
            color: #667eea;
            text-decoration: none;
            font-weight: bold;
        }
        .module a:hover {
            text-decoration: underline;
        }
        .count {
            color: #6c757d;
            font-size: 0.9em;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <h1>🔍 Batch Scan Results</h1>
EOF

echo "<p style='text-align: center; color: #6c757d;'>Scan Date: $(date)</p>" >> "$INDEX_FILE"

for target_dir in "$BATCH_OUTPUT"/*; do
    if [ -d "$target_dir" ] && [ "$(basename "$target_dir")" != "index.html" ]; then
        TARGET_NAME=$(basename "$target_dir")
        
        echo "<div class='target'>" >> "$INDEX_FILE"
        echo "<h2>$TARGET_NAME</h2>" >> "$INDEX_FILE"
        echo "<div class='modules'>" >> "$INDEX_FILE"
        
        for module_dir in "$target_dir"/*; do
            if [ -d "$module_dir" ]; then
                MODULE_NAME=$(basename "$module_dir")
                HTML_FILE="$module_dir/report.html"
                JSON_FILE="$module_dir/data.json"
                
                if [ -f "$HTML_FILE" ]; then
                    REL_PATH="$TARGET_NAME/$MODULE_NAME/report.html"
                    COUNT=$(jq -r '.metadata.record_count // 0' "$JSON_FILE" 2>/dev/null || echo "0")
                    
                    echo "<div class='module'>" >> "$INDEX_FILE"
                    echo "<a href='$REL_PATH'>$MODULE_NAME</a>" >> "$INDEX_FILE"
                    echo "<div class='count'>$COUNT results</div>" >> "$INDEX_FILE"
                    echo "</div>" >> "$INDEX_FILE"
                fi
            fi
        done
        
        echo "</div>" >> "$INDEX_FILE"
        echo "</div>" >> "$INDEX_FILE"
    fi
done

echo "</body></html>" >> "$INDEX_FILE"

echo -e "${GREEN}✓ Generated index page: $INDEX_FILE${NC}"
echo ""
echo -e "${YELLOW}Open in browser with:${NC}"
echo -e "${YELLOW}  xdg-open $INDEX_FILE${NC}  # Linux"
echo -e "${YELLOW}  open $INDEX_FILE${NC}      # macOS"
echo ""

exit 0
