# 🏗️ Architecture & Implementation Guide

## System Architecture

### Overview

The Passive Recon Framework follows a **modular, plugin-based architecture** with clear separation of concerns:

```
┌─────────────────────────────────────────────────────────┐
│                    CLI Interface (main.py)               │
│                 (Click + Rich for UI)                   │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ├──────────────────────────────────┐
                      ↓                                  ↓
           ┌──────────────────────┐         ┌───────────────────┐
           │   Module Registry    │         │  Config Manager   │
           │   (Dynamic Loading)  │         │   (API Keys)      │
           └──────────┬───────────┘         └─────────┬─────────┘
                      │                               │
                      ↓                               │
           ┌──────────────────────┐                   │
           │   Base Module        │←──────────────────┘
           │   (Abstract Class)   │
           └──────────┬───────────┘
                      │
        ┌─────────────┼─────────────┐
        ↓             ↓             ↓
   ┌─────────┐  ┌─────────┐  ┌─────────┐
   │Module 1 │  │Module 2 │  │Module N │
   │Subdomain│  │Certific │  │  ...    │
   └────┬────┘  └────┬────┘  └────┬────┘
        │            │            │
        └────────────┼────────────┘
                     ↓
        ┌────────────────────────┐
        │   Data Processing      │
        │  ┌─────────────────┐   │
        │  │ Formatter       │   │
        │  │ (Deduplicate)   │   │
        │  └─────────────────┘   │
        │  ┌─────────────────┐   │
        │  │ Filter False    │   │
        │  │ Positives       │   │
        │  └─────────────────┘   │
        └────────────┬───────────┘
                     ↓
        ┌────────────────────────┐
        │   Output Handler       │
        │  ┌─────────────────┐   │
        │  │ JSON Writer     │   │
        │  └─────────────────┘   │
        │  ┌─────────────────┐   │
        │  │ HTML Generator  │   │
        │  └─────────────────┘   │
        └────────────────────────┘
```

## Core Components

### 1. Configuration Layer (`config.py`)

**Purpose**: Centralized configuration and API key management

**Key Features**:
- Environment variable loading via python-dotenv
- API key validation
- Path management
- HTTP settings (timeout, retries, user-agent)

**Design Pattern**: Singleton configuration class

```python
class Config:
    # API keys loaded from .env
    SHODAN_API_KEY = os.getenv("SHODAN_API_KEY", "")
    
    # Settings
    TIMEOUT = 30
    MAX_RETRIES = 3
```

### 2. Base Module (`modules/base_module.py`)

**Purpose**: Abstract base class for all reconnaissance modules

**Responsibilities**:
- HTTP request handling with retry logic
- Rate limiting and error handling
- Output management
- Data processing pipeline

**Key Methods**:
- `collect()` - Abstract method for data collection
- `run()` - Main execution pipeline
- `process_data()` - Data cleaning and filtering
- `save_results()` - Output generation
- `make_request()` - HTTP wrapper with retries

**Design Patterns**: 
- Template Method Pattern (run method)
- Strategy Pattern (collection strategies)

### 3. Module Registry (`main.py`)

**Purpose**: Dynamic module loading and execution

```python
MODULES = {
    'subdomain': SubdomainEnumModule,
    'certificate': CertificateSearchModule,
    'shodan': ShodanSearchModule,
    # ... more modules
}
```

**Features**:
- Module discovery
- Dynamic instantiation
- Dependency injection

### 4. Data Processing Pipeline

#### a. Data Formatter (`utils/formatter.py`)

**Purpose**: Clean and normalize data

**Functions**:
- `deduplicate()` - Remove duplicate records
- `filter_false_positives()` - Type-specific filtering
- `normalize_data()` - Schema mapping
- `merge_results()` - Combine multiple sources

**Algorithms**:
- Hash-based deduplication (MD5)
- Regex pattern matching for validation
- IP range detection for filtering

#### b. Output Handler (`utils/output_handler.py`)

**Purpose**: Manage file I/O for results

**Features**:
- Dual-format output (JSON + HTML)
- Automatic directory management
- Metadata tracking
- Append functionality

#### c. HTML Visualizer (`utils/visualizer.py`)

**Purpose**: Generate beautiful HTML reports

**Features**:
- Responsive tables
- Gradient styling
- Statistics dashboard
- Print-friendly layout
- Empty state handling

## Module Implementation Guide

### Creating a New Module

1. **Create module file**: `modules/your_module.py`

2. **Import base class**:
```python
from .base_module import BaseModule
from config import Config
```

3. **Implement required methods**:

```python
class YourModule(BaseModule):
    def __init__(self):
        super().__init__("your_module_name")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://api.example.com"
    
    def requires_api_key(self) -> bool:
        return True  # or False
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """
        Main collection logic
        Returns list of dictionaries with consistent schema
        """
        results = []
        
        # Your API calls here
        response = self.make_request(
            url="https://api.example.com/search",
            params={'q': target},
            headers={'API-Key': Config.YOUR_API_KEY}
        )
        
        if response and response.json():
            data = response.json()
            for item in data.get('results', []):
                results.append({
                    'field1': item.get('field1', 'N/A'),
                    'field2': item.get('field2', 'N/A'),
                    'source': 'YourSource'
                })
        
        return results
```

4. **Optional: Add custom filtering**:
```python
def filter_data(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Custom filtering logic"""
    return [item for item in data if item['field1'] != 'spam']
```

5. **Register in main.py**:
```python
from modules import YourModule

MODULES = {
    'yourmodule': YourModule,
    # ... existing modules
}
```

6. **Add to module list display** in `main.py`:
```python
modules_info = [
    ("yourmodule", "Your Module", "Description", "Yes/No"),
    # ... existing modules
]
```

## Data Flow

### Single Module Execution

```
User Input (target + module)
    ↓
CLI Parser (Click)
    ↓
Module Instantiation
    ↓
module.run(target)
    ↓
module.collect(target) → Raw Data
    ↓
module.process_data() → Cleaned Data
    ↓
formatter.deduplicate()
    ↓
formatter.filter_false_positives()
    ↓
output_handler.save() → JSON + HTML
    ↓
Display Summary
```

### All Modules Execution

```
User Input (target + --all)
    ↓
CLI Parser
    ↓
For each module in MODULES:
    ↓
    Module Instantiation
    ↓
    module.run(target)
    ↓
    [Same as single module flow]
    ↓
    Collect results
    ↓
Aggregate Summary
    ↓
Display Final Report
```

## Error Handling Strategy

### Levels of Error Handling

1. **Network Level** (base_module.py)
   - Retry with exponential backoff
   - Rate limit detection
   - Timeout handling

2. **Module Level** (individual modules)
   - Try-catch around API calls
   - Graceful degradation
   - Error logging

3. **CLI Level** (main.py)
   - User-friendly error messages
   - Continue-on-error for batch operations
   - Exit code management

### Example Error Flow

```python
try:
    response = self.make_request(url)  # Level 1: Network
    if response:
        data = response.json()  # Level 2: Module
except Exception as e:
    print(f"[!] Error: {str(e)}")  # Level 3: CLI
    return []  # Graceful degradation
```

## Output Schema

### JSON Structure

```json
{
  "metadata": {
    "module": "string",
    "target": "string",
    "timestamp": "ISO 8601",
    "record_count": "integer"
  },
  "results": [
    {
      "field1": "value1",
      "field2": "value2",
      "source": "data_source"
    }
  ]
}
```

### HTML Structure

```html
<!DOCTYPE html>
<html>
  <head>
    <style>/* Inline CSS */</style>
  </head>
  <body>
    <div class="container">
      <header>Title + Metadata</header>
      <stats>Statistics Dashboard</stats>
      <table>Results Table</table>
      <footer>Credits</footer>
    </div>
  </body>
</html>
```

## Performance Considerations

### Optimization Strategies

1. **Connection Pooling**: Reuse HTTP sessions
2. **Parallel Requests**: Use asyncio for concurrent API calls (future enhancement)
3. **Caching**: Store API responses to avoid redundant calls (future)
4. **Rate Limiting**: Respect API limits to avoid bans
5. **Lazy Loading**: Only load modules when needed

### Current Performance

- **Single Module**: 5-30 seconds (depends on API)
- **All Modules**: 1-5 minutes (sequential execution)
- **Future with Async**: < 1 minute for all modules

## Security Considerations

### API Key Protection

- Stored in `.env` file (gitignored)
- Never logged or displayed
- Loaded at runtime only

### Rate Limiting

- Respects API terms of service
- Implements backoff strategies
- Configurable timeouts

### Data Privacy

- No data sent to third parties (except APIs)
- Local storage only
- User controls all data

## Testing Strategy

### Unit Tests (Planned)

```python
def test_formatter_deduplication():
    formatter = DataFormatter()
    data = [{'id': 1}, {'id': 1}, {'id': 2}]
    result = formatter.deduplicate(data, ['id'])
    assert len(result) == 2
```

### Integration Tests

- Test each module against live APIs
- Verify output format compliance
- Check error handling

### Demo Test (`test_demo.py`)

- Tests modules without API keys
- Validates installation
- Quick smoke test

## Future Enhancements

### Phase 2
- [ ] Async/parallel module execution
- [ ] Result caching system
- [ ] Database backend (SQLite/PostgreSQL)
- [ ] RESTful API server
- [ ] Web dashboard

### Phase 3
- [ ] Machine learning for false positive detection
- [ ] Automated monitoring and alerting
- [ ] Diff/compare functionality
- [ ] Export to more formats (CSV, PDF, XML)

### Phase 4
- [ ] Distributed scanning
- [ ] Cloud deployment
- [ ] CI/CD integration
- [ ] Webhook notifications

## Dependencies

### Core Dependencies
- `requests` - HTTP client
- `click` - CLI framework
- `rich` - Terminal formatting
- `python-dotenv` - Environment management
- `dnspython` - DNS queries
- `beautifulsoup4` - HTML parsing

### Why These Choices?

- **Click**: Powerful, composable CLI framework
- **Rich**: Beautiful terminal output
- **Requests**: De facto HTTP library
- **dnspython**: Pure Python DNS resolver

## Deployment Options

### Local Development
```bash
python main.py scan target.com --all
```

### Docker (Future)
```bash
docker run -it passive-recon scan target.com --all
```

### Cloud Functions (Future)
- AWS Lambda
- Google Cloud Functions
- Azure Functions

## Code Style & Standards

- **PEP 8** compliance
- **Type hints** where applicable
- **Docstrings** for all public methods
- **Error messages** prefixed with [!]
- **Success messages** prefixed with [+]
- **Info messages** prefixed with [*]

## Contributing Guidelines

1. Follow existing code structure
2. Add tests for new modules
3. Update documentation
4. Use meaningful commit messages
5. Submit PR with description

---

**Last Updated**: 2025-12-16
**Version**: 1.0
**Maintainer**: Security Research Team
