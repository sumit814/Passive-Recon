#!/usr/bin/env python3
"""
Passive Reconnaissance Framework
Main CLI Entry Point
"""

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich import box
import pyfiglet
from pathlib import Path
import sys
import signal
from contextlib import contextmanager

from config import Config
from utils import DomainParser, CombinedReportGenerator
from modules import (
    SubdomainEnumModule,
    CertificateSearchModule,
    ShodanSearchModule,
    GitHubIntelModule,
    EmailHarvestingModule,
    VirusTotalModule,
    URLScanModule,
    DNSIntelligenceModule,
    WhoisModule,
    ZoomEyeSearchModule,
    LeakIXSearchModule,
    GreyNoiseLookupModule,
    VulnersLookupModule,
    FullHuntSearchModule,
    PublicWWWSearchModule,
    WaybackSearchModule,
    DNSlyticsLookupModule,
    BuiltWithLookupModule,
    OTXLookupModule,
    HackerTargetLookupModule,
    SocialMediaEnumModule,
    PortEnumerationModule,
    IPReputationModule,
    SSLTLSAnalysisModule,
    EmailLeakCheckModule,
    EmailSecurityModule
)

console = Console()

class TimeoutException(Exception):
    pass

@contextmanager
def time_limit(seconds):
    """Context manager to limit execution time"""
    def signal_handler(signum, frame):
        raise TimeoutException("Timed out")
    
    signal.signal(signal.SIGALRM, signal_handler)
    signal.alarm(seconds)
    try:
        yield
    finally:
        signal.alarm(0)

# Module registry
MODULES = {
    'subdomain': SubdomainEnumModule,
    'certificate': CertificateSearchModule,
    'shodan': ShodanSearchModule,
    'github': GitHubIntelModule,
    'email': EmailHarvestingModule,
    'virustotal': VirusTotalModule,
    'urlscan': URLScanModule,
    'dns': DNSIntelligenceModule,
    'whois': WhoisModule,
    'zoomeye': ZoomEyeSearchModule,
    'leakix': LeakIXSearchModule,
    'greynoise': GreyNoiseLookupModule,
    'vulners': VulnersLookupModule,
    'fullhunt': FullHuntSearchModule,
    'publicwww': PublicWWWSearchModule,
    'wayback': WaybackSearchModule,
    'dnslytics': DNSlyticsLookupModule,
    'builtwith': BuiltWithLookupModule,
    'otx': OTXLookupModule,
    'hackertarget': HackerTargetLookupModule,
    'social': SocialMediaEnumModule,
    'ports': PortEnumerationModule,
    'iprep': IPReputationModule,
    'ssl': SSLTLSAnalysisModule,
    'leakcheck': EmailLeakCheckModule,
    'emailsec': EmailSecurityModule,
}

def print_banner():
    """Display ASCII art banner"""
    banner = pyfiglet.figlet_format("PASSIVE RECON", font="slant")
    console.print(banner, style="bold cyan")
    console.print("━" * 70, style="cyan")
    console.print("[bold cyan]Passive Reconnaissance Framework v1.0[/bold cyan]")
    console.print("[dim]Gather maximum intelligence without touching the target[/dim]\n")

def show_modules():
    """Display available modules in a table"""
    table = Table(title="Available Modules", box=box.ROUNDED, show_header=True, header_style="bold magenta")
    
    table.add_column("Module", style="cyan", no_wrap=True)
    table.add_column("Name", style="green")
    table.add_column("Description", style="white")
    table.add_column("Requires API", style="yellow")
    
    modules_info = [
        # Original 9 modules
        ("subdomain", "Subdomain Enumeration", "Find subdomains via crt.sh, SecurityTrails, VirusTotal", "Optional"),
        ("certificate", "Certificate Search", "SSL/TLS certificate intelligence", "No"),
        ("shodan", "Shodan Scanner", "Search for internet-exposed assets", "Yes"),
        ("github", "GitHub Intelligence", "Search code and repos on GitHub", "Yes"),
        ("email", "Email Harvesting", "Discover email addresses", "Yes"),
        ("virustotal", "VirusTotal Lookup", "Domain reputation and analysis", "Yes"),
        ("urlscan", "URLScan Lookup", "Web scanning and screenshots", "Optional"),
        ("dns", "DNS Intelligence", "DNS records enumeration", "No"),
        ("whois", "WHOIS Lookup", "Domain registration information", "No"),
        # Additional modules
        ("zoomeye", "ZoomEye Search", "Cyberspace search engine", "Yes"),
        ("leakix", "LeakIX Search", "Exposed services and data leaks", "Yes"),
        ("greynoise", "GreyNoise Lookup", "Internet noise and threat intel", "Yes"),
        ("vulners", "Vulners Lookup", "Vulnerability intelligence", "Yes"),
        ("fullhunt", "FullHunt Search", "Attack surface discovery", "Yes"),
        ("publicwww", "PublicWWW Search", "Source code search", "Yes"),
        ("wayback", "Wayback Machine", "Historical website snapshots", "No"),
        ("dnslytics", "DNSlytics Lookup", "Domain intelligence", "No"),
        ("builtwith", "BuiltWith Lookup", "Technology stack detection", "Yes"),
        ("otx", "AlienVault OTX", "Threat intelligence", "No"),
        ("hackertarget", "HackerTarget Lookup", "Multiple recon tools", "No"),
        # Social media & Port scanning
        ("social", "Social Media Enum", "Find social media profiles and handles", "Optional"),
        ("ports", "Port Enumeration", "Discover open ports from Shodan, Censys, etc.", "Yes"),
        # NEW: Enhanced security modules
        ("iprep", "IP Reputation", "Multi-source IP threat intelligence (VT, AbuseIPDB, GreyNoise)", "Yes"),
        ("ssl", "SSL/TLS Analysis", "Certificate validation & security analysis", "No"),
        ("leakcheck", "Email Leak Check", "Check emails for breaches (5 FREE tools)", "No"),
        ("emailsec", "Email Security", "DMARC/SPF/DKIM/MX/PTR analysis", "No"),
    ]
    
    for module_id, name, desc, api in modules_info:
        table.add_row(module_id, name, desc, api)
    
    console.print(table)
    console.print("\n[dim]Use --module <name> to run a specific module[/dim]")
    console.print("[dim]Use --all to run all modules[/dim]\n")

def show_api_status():
    """Display API key configuration status"""
    status = Config.get_api_keys_status()
    
    table = Table(title="API Keys Status", box=box.ROUNDED)
    table.add_column("Service", style="cyan")
    table.add_column("Status", style="green")
    
    for service, configured in status.items():
        status_icon = "✓ Configured" if configured else "✗ Not Set"
        style = "green" if configured else "red"
        table.add_row(service, f"[{style}]{status_icon}[/{style}]")
    
    console.print(table)

@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """Passive Reconnaissance Framework - Gather intelligence without touching the target"""
    if ctx.invoked_subcommand is None:
        print_banner()
        show_modules()
        console.print("\n[yellow]💡 Quick Start:[/yellow]")
        console.print("[dim]  python main.py scan <target> --all[/dim]")
        console.print("[dim]  python main.py run <target> -m dns[/dim]")
        console.print("[dim]  python main.py interactive[/dim]\n")

@cli.command()
@click.argument('target')
@click.option('--module', '-m', help='Specific module to run')
@click.option('--all', 'run_all', is_flag=True, help='Run all available modules')
@click.option('--output', '-o', help='Custom output directory')
def scan(target, module, run_all, output):
    """Run reconnaissance scan on TARGET"""
    print_banner()
    
    # Clean and validate target
    original_target = target
    target = DomainParser.extract_domain(target)
    
    # Validate target is not empty
    if not target or not target.strip():
        console.print("[bold red]Error:[/bold red] Invalid or empty target")
        return
    
    if original_target != target:
        console.print(f"[dim]Cleaned target: {original_target} → {target}[/dim]")
    
    # Ensure directories exist
    Config.ensure_directories()
    
    if output:
        Config.OUTPUT_DIR = Path(output)
        Config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    console.print(f"\n[bold green]Target:[/bold green] {target}\n")
    
    modules_to_run = []
    
    if run_all:
        modules_to_run = list(MODULES.keys())
        console.print("[bold cyan]Running ALL modules...[/bold cyan]\n")
    elif module:
        if module not in MODULES:
            console.print(f"[bold red]Error:[/bold red] Unknown module '{module}'")
            console.print(f"Available modules: {', '.join(MODULES.keys())}")
            return
        modules_to_run = [module]
        console.print(f"[bold cyan]Running module: {module}[/bold cyan]\n")
    else:
        console.print("[bold red]Error:[/bold red] Please specify --module or --all")
        return
    
    # Run modules
    results_summary = {}
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        
        for module_name in modules_to_run:
            task = progress.add_task(f"[cyan]Running {module_name}...", total=None)
            
            try:
                with time_limit(Config.MODULE_TIMEOUT):
                    module_class = MODULES[module_name]
                    module_instance = module_class()
                    
                    output_paths = module_instance.run(target)
                    
                    if output_paths:
                        result_count = len(module_instance.results)
                        results_summary[module_name] = {
                            'count': result_count,
                            'paths': output_paths
                        }
                        progress.update(task, description=f"[green]✓ {module_name} - Found {result_count} results")
                    else:
                        progress.update(task, description=f"[yellow]⚠ {module_name} - No results")
                        results_summary[module_name] = {'count': 0, 'paths': {}}
                
            except TimeoutException:
                progress.update(task, description=f"[red]✗ {module_name} - Timeout (>{Config.MODULE_TIMEOUT}s)")
                results_summary[module_name] = {'count': 0, 'error': f'Timeout after {Config.MODULE_TIMEOUT}s'}
            except Exception as e:
                progress.update(task, description=f"[red]✗ {module_name} - Error: {str(e)}")
                results_summary[module_name] = {'count': 0, 'error': str(e)}
            
            progress.remove_task(task)
    
    # Display summary
    console.print("\n" + "━" * 70 + "\n")
    summary_table = Table(title="Scan Summary", box=box.DOUBLE, show_header=True, header_style="bold magenta")
    
    summary_table.add_column("Module", style="cyan", no_wrap=True)
    summary_table.add_column("Results", justify="right", style="green")
    summary_table.add_column("Output Location", style="yellow")
    
    for module_name, result in results_summary.items():
        count = result.get('count', 0)
        paths = result.get('paths', {})
        
        if paths:
            json_path = paths.get('json', 'N/A')
            html_path = paths.get('html', 'N/A')
            output_info = f"JSON: {json_path}\nHTML: {html_path}"
        else:
            output_info = "No output generated"
        
        summary_table.add_row(
            module_name.title(),
            str(count),
            str(paths.get('json', 'N/A')) if paths else 'N/A'
        )
    
    console.print(summary_table)
    
    # Generate combined report
    console.print("\n[bold cyan]📊 Generating combined report...[/bold cyan]")
    try:
        combined_paths = CombinedReportGenerator.generate_combined_report(target, Config.OUTPUT_DIR)
        
        console.print(f"[bold green]✓ Combined report generated![/bold green]")
        console.print(f"\n[bold yellow]📄 Combined Reports:[/bold yellow]")
        console.print(f"  JSON: [cyan]{combined_paths['json']}[/cyan]")
        console.print(f"  HTML: [cyan]{combined_paths['html']}[/cyan]")
        console.print(f"\n[dim]💡 Open the HTML file in your browser to see all results in one place![/dim]")
    except Exception as e:
        console.print(f"[yellow]⚠ Warning: Could not generate combined report: {str(e)}[/yellow]")
    
    # Generate Professional Report
    console.print("\n[bold cyan]📑 Generating Professional Passive Reconnaissance Report...[/bold cyan]")
    try:
        from utils.professional_report import ProfessionalReportGenerator
        report_gen = ProfessionalReportGenerator(target, Config.OUTPUT_DIR)
        report_path = report_gen.generate_report()
        
        console.print(f"[bold green]✓ Professional report generated![/bold green]")
        console.print(f"\n[bold yellow]📑 Professional Report:[/bold yellow]")
        console.print(f"  PDF: [cyan]{report_path}[/cyan]")
        console.print(f"\n[dim]💼 This report includes: Executive Summary, Methodology, Findings, Analysis, and Recommendations[/dim]")
    except Exception as e:
        console.print(f"[yellow]⚠ Warning: Could not generate professional report: {str(e)}[/yellow]")
    
    console.print(f"\n[bold green]✓ Scan complete![/bold green]")
    console.print(f"[dim]Output directory: {Config.OUTPUT_DIR}[/dim]\n")

@cli.command()
def modules():
    """List all available modules"""
    print_banner()
    show_modules()

@cli.command()
def apikeys():
    """Show API keys configuration status"""
    print_banner()
    show_api_status()
    console.print("\n[dim]Configure API keys in .env file[/dim]")
    console.print("[dim]See .env.example for template[/dim]\n")

@cli.command()
@click.argument('target')
@click.option('--module', '-m', required=True, help='Module to run')
def run(target, module):
    """Run a single module against TARGET"""
    if module not in MODULES:
        console.print(f"[bold red]Error:[/bold red] Unknown module '{module}'")
        return
    
    # Clean and validate target
    original_target = target
    target = DomainParser.extract_domain(target)
    
    # Validate target is not empty
    if not target or not target.strip():
        console.print("[bold red]Error:[/bold red] Invalid or empty target")
        return
    
    if original_target != target:
        console.print(f"[dim]Cleaned target: {original_target} → {target}[/dim]\n")
    
    print_banner()
    Config.ensure_directories()
    
    console.print(f"[bold green]Target:[/bold green] {target}")
    console.print(f"[bold cyan]Module:[/bold cyan] {module}\n")
    
    try:
        module_class = MODULES[module]
        module_instance = module_class()
        
        output_paths = module_instance.run(target)
        
        if output_paths:
            console.print(f"\n[bold green]✓ Completed successfully![/bold green]")
            console.print(f"\n[cyan]Results saved to:[/cyan]")
            console.print(f"  JSON: {output_paths.get('json')}")
            console.print(f"  HTML: {output_paths.get('html')}\n")
        else:
            console.print(f"\n[yellow]⚠ No results found[/yellow]\n")
            
    except Exception as e:
        console.print(f"\n[bold red]Error:[/bold red] {str(e)}\n")
        sys.exit(1)

@cli.command()
def interactive():
    """Interactive mode - prompts for target and module selection"""
    print_banner()
    
    console.print("[bold cyan]Interactive Mode[/bold cyan]\n")
    
    # Get target
    console.print("[yellow]Enter target (domain or IP):[/yellow]")
    console.print("[dim]Examples: example.com, https://example.com, 93.184.216.34[/dim]")
    target = input("Target: ").strip()
    
    if not target:
        console.print("[red]Error: Target is required[/red]")
        sys.exit(1)
    
    # Clean target
    original_target = target
    target = DomainParser.extract_domain(target)
    
    # Validate target is not empty
    if not target or not target.strip():
        console.print("[red]Error: Invalid or empty target[/red]")
        sys.exit(1)
    
    if original_target != target:
        console.print(f"[dim]Cleaned: {original_target} → {target}[/dim]")
    
    console.print(f"\n[green]Target set to:[/green] {target}\n")
    
    # Show module options
    show_modules()
    
    # Get module choice
    console.print("[yellow]Choose an option:[/yellow]")
    console.print("  [cyan]1.[/cyan] Run ALL modules")
    console.print("  [cyan]2.[/cyan] Select specific module")
    console.print("  [cyan]3.[/cyan] Exit\n")
    
    choice = input("Your choice (1-3): ").strip()
    
    if choice == '1':
        # Run all modules
        console.print(f"\n[bold cyan]Running ALL modules on {target}...[/bold cyan]\n")
        ctx = click.get_current_context()
        ctx.invoke(scan, target=target, module=None, run_all=True, output=None)
        
    elif choice == '2':
        # Select specific module
        console.print(f"\n[yellow]Available modules:[/yellow]")
        module_list = list(MODULES.keys())
        for idx, mod in enumerate(module_list, 1):
            console.print(f"  [cyan]{idx}.[/cyan] {mod}")
        
        console.print()
        mod_choice = input("Enter module number or name: ").strip()
        
        # Parse choice
        selected_module = None
        if mod_choice.isdigit():
            idx = int(mod_choice) - 1
            if 0 <= idx < len(module_list):
                selected_module = module_list[idx]
        elif mod_choice in MODULES:
            selected_module = mod_choice
        
        if selected_module:
            console.print(f"\n[bold cyan]Running {selected_module} on {target}...[/bold cyan]\n")
            ctx = click.get_current_context()
            ctx.invoke(run, target=target, module=selected_module)
        else:
            console.print("[red]Invalid module selection[/red]")
            sys.exit(1)
            
    elif choice == '3':
        console.print("\n[dim]Goodbye![/dim]\n")
        sys.exit(0)
    else:
        console.print("[red]Invalid choice[/red]")
        sys.exit(1)

if __name__ == '__main__':
    cli()
