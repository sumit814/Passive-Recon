# 🎯 How to Provide Target - Complete Guide

## Overview

The Passive Recon Framework offers **3 different ways** to provide your target:

1. ✅ **Command Line (Direct)** - Fastest method
2. ✅ **Interactive Mode** - Guided prompts (NEW!)
3. ✅ **Batch Mode** - Multiple targets from file

---

## Method 1: Command Line (Direct) ⚡

**This is the FASTEST way** - you provide the target directly in the command.

### Syntax
```bash
python main.py <command> <TARGET> [options]
```

### Examples

#### Run Single Module
```bash
# DNS lookup (no API key needed)
python main.py run example.com -m dns

# Subdomain enumeration
python main.py run example.com -m subdomain

# GitHub intelligence
python main.py run github.com -m github

# Email harvesting
python main.py run company.com -m email
```

#### Run All Modules
```bash
# Scan with all modules
python main.py scan example.com --all

# With custom output directory
python main.py scan example.com --all -o ./my-scans/

# Full example
python main.py scan target.com --all --output ./results/target-$(date +%Y%m%d)
```

#### Run Specific Module
```bash
# Short form
python main.py scan example.com -m dns

# This also works
python main.py scan example.com --module subdomain
```

---

## Method 2: Interactive Mode 🎮 (NEW!)

**Perfect for beginners** - the framework will guide you step by step.

### How to Use

```bash
# Start interactive mode
python main.py interactive
```

### What Happens

1. **Banner displays** showing available modules
2. **Prompts for target**: Enter your domain or IP
3. **Shows options**:
   - Run ALL modules
   - Select specific module
   - Exit
4. **Executes scan** based on your choice

### Interactive Session Example

```bash
$ python main.py interactive

  ____                 _            ____                      
 |  _ \ __ _ ___ ___(_)_   _____  |  _ \ ___  ___ ___  _ __  
 | |_) / _` / __/ __| \ \ / / _ \ | |_) / _ \/ __/ _ \| '_ \ 
 |  __/ (_| \__ \__ \ |\ V /  __/ |  _ <  __/ (_| (_) | | | |
 |_|   \__,_|___/___/_| \_/ \___| |_| \_\___|\___\___/|_| |_|

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Passive Reconnaissance Framework v1.0
Gather maximum intelligence without touching the target

Interactive Mode

Enter target (domain or IP):
Target: example.com

Target set to: example.com

[Shows module table...]

Choose an option:
  1. Run ALL modules
  2. Select specific module
  3. Exit

Your choice (1-3): 1

Running ALL modules on example.com...
[Scan proceeds...]
```

---

## Method 3: Batch Mode 📝

**For scanning multiple targets** - provide targets in a file.

### Step 1: Create Targets File

Create a file called `targets.txt`:

```text
# My targets to scan
example.com
target1.org
company.net
another-domain.com
```

### Step 2: Run Batch Script

```bash
# Run batch scan
./batch_scan.sh targets.txt
```

### What It Does

- Reads each target from file (one per line)
- Scans each target with all modules
- Adds delay between scans (respect rate limits)
- Saves results to `batch_results/scan_DATETIME/`
- Generates HTML index page
- Shows summary at the end

### Batch Script Features

- ✅ Color-coded output
- ✅ Progress tracking (X/Total)
- ✅ Success/Failure counting
- ✅ Automatic delays between scans
- ✅ Combined results page
- ✅ Individual logs per target

---

## Quick Reference Card

| Method | Command | When to Use |
|--------|---------|-------------|
| **Direct** | `python main.py scan target.com --all` | Single target, quick scan |
| **Interactive** | `python main.py interactive` | Learning, guided usage |
| **Batch** | `./batch_scan.sh targets.txt` | Multiple targets |

---

## Common Usage Patterns

### Pattern 1: Quick Check
```bash
# Fast DNS + WHOIS check (no API needed)
python main.py run example.com -m dns
python main.py run example.com -m whois
```

### Pattern 2: Subdomain Discovery
```bash
# Free subdomain enumeration via crt.sh
python main.py run example.com -m subdomain
```

### Pattern 3: Full Reconnaissance
```bash
# Complete scan with all modules
python main.py scan example.com --all
```

### Pattern 4: Targeted Intelligence
```bash
# Just GitHub and email intel
python main.py run company.com -m github
python main.py run company.com -m email
```

### Pattern 5: Bug Bounty
```bash
# Asset discovery workflow
python main.py scan target.com --all -o ./bounty/target-recon/
```

---

## Understanding the Commands

### `python main.py` (No Arguments)
- Shows banner
- Lists all modules
- Displays quick start examples

### `python main.py modules`
- Shows detailed module table
- API requirements
- Descriptions

### `python main.py apikeys`
- Shows which API keys are configured
- Green checkmarks = configured
- Red crosses = not configured

### `python main.py scan <target> --all`
- Runs ALL 9 modules
- Takes 2-5 minutes
- Requires target as argument

### `python main.py run <target> -m <module>`
- Runs single module
- Faster (5-30 seconds)
- Requires target and module name

### `python main.py interactive`
- Guided mode with prompts
- Perfect for beginners
- Asks for target interactively

---

## Error Messages Explained

### "Error: Missing argument 'TARGET'"
**Problem**: You forgot to provide the target

**Solution**:
```bash
# Wrong
python main.py scan --all

# Correct
python main.py scan example.com --all

# Or use interactive mode
python main.py interactive
```

### "Error: Unknown module 'xyz'"
**Problem**: Module name is incorrect

**Solution**:
```bash
# Check available modules
python main.py modules

# Use correct name
python main.py run example.com -m dns
```

### "Error: No API key configured"
**Problem**: Module requires API key

**Solution**:
```bash
# Configure API key in .env file
nano .env

# Or use modules that don't need keys
python main.py run example.com -m dns
python main.py run example.com -m whois
```

---

## Target Format Examples

### Valid Targets

```bash
# Domains
python main.py run example.com -m dns
python main.py run subdomain.example.com -m dns
python main.py run my-site.co.uk -m dns

# IPs (for some modules)
python main.py run 93.184.216.34 -m shodan

# Organization names (for GitHub)
python main.py run "Microsoft" -m github
```

### Invalid Targets

```bash
# Don't include protocols
python main.py run https://example.com -m dns  # ❌ Wrong

# Just the domain
python main.py run example.com -m dns          # ✅ Correct

# Don't include paths
python main.py run example.com/page -m dns     # ❌ Wrong
python main.py run example.com -m dns          # ✅ Correct
```

---

## Tips & Tricks

### 1. Check Help for Any Command
```bash
python main.py --help
python main.py scan --help
python main.py run --help
```

### 2. Start with Free Modules
```bash
# No API keys needed
python main.py run example.com -m dns
python main.py run example.com -m whois
python main.py run example.com -m subdomain  # Uses free crt.sh
```

### 3. Use Tab Completion
```bash
# In bash/zsh (if configured)
python main.py run example.com -m <TAB>
# Shows: dns, whois, subdomain, etc.
```

### 4. Save Output to Custom Location
```bash
# Organize your scans
python main.py scan target.com --all -o ./scans/target-2025-12-16
python main.py scan target.com --all -o ./bounty-programs/target/
```

### 5. Chain Commands
```bash
# Run multiple scans
python main.py run target.com -m dns && \
python main.py run target.com -m whois && \
python main.py run target.com -m subdomain
```

---

## Complete Examples

### Example 1: Beginner (First Time User)
```bash
# Step 1: Check what's available
python main.py modules

# Step 2: Use interactive mode
python main.py interactive
# Enter target when prompted: example.com
# Choose option 1: Run ALL modules
```

### Example 2: Intermediate (Know What You Want)
```bash
# Direct command
python main.py scan example.com --all

# Or specific modules
python main.py run example.com -m subdomain
python main.py run example.com -m certificate
python main.py run example.com -m dns
```

### Example 3: Advanced (Multiple Targets)
```bash
# Create targets file
cat > targets.txt << EOF
target1.com
target2.com
target3.com
EOF

# Run batch scan
./batch_scan.sh targets.txt
```

### Example 4: Bug Bounty Hunter
```bash
# Organized scan with timestamped output
DATE=$(date +%Y%m%d)
TARGET="bugcrowd-target.com"

python main.py scan $TARGET --all -o ./bounty/$TARGET/$DATE

# View results
ls -la ./bounty/$TARGET/$DATE/
```

---

## Troubleshooting

### Q: It says "missing argument TARGET"
**A**: You need to provide the target in the command:
```bash
python main.py scan example.com --all
                    ↑ Add target here
```

### Q: How do I know what to type?
**A**: Use interactive mode:
```bash
python main.py interactive
# It will prompt you for everything!
```

### Q: Can I scan multiple targets at once?
**A**: Yes! Use batch mode:
```bash
./batch_scan.sh targets.txt
```

### Q: Where do I put the target?
**A**: Right after the command, before options:
```bash
python main.py <command> <TARGET> [options]
                         ↑ Here!
```

---

## Summary

### 3 Ways to Provide Target:

1. **Direct**: `python main.py run example.com -m dns`
   - ✅ Fastest
   - ✅ For experienced users
   - ✅ Scriptable

2. **Interactive**: `python main.py interactive`
   - ✅ Guided prompts
   - ✅ Perfect for beginners
   - ✅ No need to remember syntax

3. **Batch**: `./batch_scan.sh targets.txt`
   - ✅ Multiple targets
   - ✅ Automated
   - ✅ Scheduled scans

---

## Next Steps

1. **Try Interactive Mode**:
   ```bash
   python main.py interactive
   ```

2. **Learn the Modules**:
   ```bash
   python main.py modules
   ```

3. **Check API Status**:
   ```bash
   python main.py apikeys
   ```

4. **Run First Scan**:
   ```bash
   python main.py run example.com -m dns
   ```

**You're ready to start! 🚀**

For more details, see:
- [QUICKSTART.md](QUICKSTART.md) - Quick start guide
- [EXAMPLES.md](EXAMPLES.md) - More usage examples
- [README.md](README.md) - Full documentation
