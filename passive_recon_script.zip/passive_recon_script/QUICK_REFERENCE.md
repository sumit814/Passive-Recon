# 🚀 Quick Reference Card - Passive Recon Framework

## 📋 One-Page Cheat Sheet

### **Installation**
```bash
pip install -r requirements.txt
```

### **Quick Start**
```bash
# Interactive mode (easiest)
python main.py interactive

# Scan all modules
python main.py scan example.com --all

# Single module
python main.py scan example.com --module shodan
```

---

## 🎯 All 22 Modules

| Module | Command | API Required | Description |
|--------|---------|--------------|-------------|
| subdomain | `--module subdomain` | Optional | Find subdomains |
| certificate | `--module certificate` | No | SSL/TLS certificates |
| shodan | `--module shodan` | ✅ Yes | Internet assets + ports |
| github | `--module github` | ✅ Yes | Code & repo search |
| email | `--module email` | ✅ Yes | Email addresses |
| virustotal | `--module virustotal` | ✅ Yes | Domain reputation |
| urlscan | `--module urlscan` | Optional | Web scanning |
| dns | `--module dns` | No | DNS records |
| whois | `--module whois` | No | WHOIS info |
| zoomeye | `--module zoomeye` | ✅ Yes | ZoomEye search |
| leakix | `--module leakix` | ✅ Yes | Data leaks |
| greynoise | `--module greynoise` | ✅ Yes | Threat intel |
| vulners | `--module vulners` | ✅ Yes | Vulnerabilities |
| fullhunt | `--module fullhunt` | ✅ Yes | Attack surface |
| publicwww | `--module publicwww` | ✅ Yes | Source code search |
| wayback | `--module wayback` | No | Archive.org snapshots |
| dnslytics | `--module dnslytics` | No | Domain intel |
| builtwith | `--module builtwith` | ✅ Yes | Tech stack |
| otx | `--module otx` | No | AlienVault OTX |
| hackertarget | `--module hackertarget` | No | Multi-tools |
| **social** | `--module social` | Optional | **Social media profiles** |
| **ports** | `--module ports` | ✅ Yes | **Open ports aggregate** |

---

## 🔑 Essential API Keys

Add to `config.py`:

```python
SHODAN_API_KEY = "your_key_here"      # Critical
HUNTER_API_KEY = "your_key_here"       # Important
GITHUB_TOKEN = "your_token_here"       # Important
VIRUSTOTAL_API_KEY = "your_key_here"   # Important
SECURITYTRAILS_API_KEY = "your_key"    # Important
FULLHUNT_API_KEY = "your_key_here"     # Useful
LEAKIX_API_KEY = "your_key_here"       # Useful
```

---

## 📁 Output Locations

```
outputs/
├── subdomain_enumeration/
│   ├── data.json           # Machine-readable
│   └── report.html         # Human-readable
├── shodan_search/
├── port_enumeration/       # ← NEW
├── social_media_enumeration/  # ← NEW
└── combined_report/        # ← All results
    ├── all_results.json
    └── all_results.html    # Open this!
```

---

## 💡 Pro Tips

1. **Start with Interactive Mode** - Easiest for beginners
```bash
python main.py interactive
```

2. **View Combined Report** - See everything in one place
```bash
# After scan, open in browser:
outputs/combined_report/all_results.html
```

3. **Target Format** - All these work:
```
example.com
https://example.com
http://www.example.com/
```

4. **Check Module Status**
```bash
python main.py modules     # List all modules
python main.py apikeys     # Check API keys
```

5. **Test Single Module First**
```bash
python main.py scan example.com --module dns
```

---

## 🎨 CLI Commands Summary

```bash
# Interactive wizard
python main.py interactive

# Scan commands
python main.py scan <target> --all              # All modules
python main.py scan <target> --module <name>    # Single module
python main.py scan <target> -o /custom/path    # Custom output dir

# Info commands
python main.py modules      # List modules
python main.py apikeys      # Check API status

# Alternative run syntax
python main.py run <target> --module <name>
```

---

## 🐛 Quick Troubleshooting

| Issue | Solution |
|-------|----------|
| `API key not configured` | Add key to `config.py` |
| `Request failed 401/403` | Check API key validity |
| `No results found` | Target may not be indexed |
| `Module not found` | Check spelling with `modules` command |
| `Permission denied` | Run with appropriate permissions |

---

## 📊 Example Output

```
╔══════════════╦═════════╦═══════════════════╗
║ Module       ║ Results ║ Output Location   ║
╠══════════════╬═════════╬═══════════════════╣
║ Subdomain    ║      40 ║ outputs/...       ║
║ Shodan       ║      13 ║ outputs/...       ║
║ Social       ║      57 ║ outputs/...       ║
║ Ports        ║      11 ║ outputs/...       ║
╚══════════════╩═════════╩═══════════════════╝

📊 Combined Reports:
  JSON: outputs/combined_report/all_results.json
  HTML: outputs/combined_report/all_results.html
```

---

## 🎯 Common Use Cases

### **Quick Recon**
```bash
python main.py scan target.com --module dns
python main.py scan target.com --module whois
```

### **Deep Recon**
```bash
python main.py scan target.com --all
```

### **Port Discovery**
```bash
python main.py scan target.com --module ports
python main.py scan target.com --module shodan
```

### **Social Media Hunt**
```bash
python main.py scan company.com --module social
```

### **Email Collection**
```bash
python main.py scan company.com --module email
python main.py scan company.com --module github
```

---

## 📈 Performance Stats (c9lab.com)

- **Total Modules**: 22
- **Active Modules**: 16 (with results)
- **Total Intelligence Points**: 303+
- **Scan Time**: ~2-3 minutes
- **Output Files**: 44 (JSON + HTML per module)
- **Combined Report**: 1 comprehensive HTML + JSON

---

## 🆘 Need Help?

```bash
# Show help
python main.py --help
python main.py scan --help
python main.py run --help

# Check docs
cat README.md
cat HOW_TO_USE.md
cat TROUBLESHOOTING.md
```

---

## ⚡ Speed Tips

1. **Run specific modules** instead of `--all` for faster results
2. **Test with DNS/WHOIS first** (no API needed)
3. **Add API keys** to unlock more modules
4. **Use combined report** instead of checking each module

---

## 🎁 Bonus Features

- ✅ Auto domain extraction from URLs
- ✅ Deduplication across all modules
- ✅ Combined HTML report with all data
- ✅ Social media profile enumeration
- ✅ Multi-source port aggregation
- ✅ Beautiful terminal UI with colors
- ✅ Progress indicators
- ✅ Error handling & retries

---

## 🔥 Most Useful Modules

1. **subdomain** - Find attack surface
2. **shodan** - Discover exposed services
3. **ports** - Aggregate open ports
4. **github** - Find leaked secrets
5. **email** - Contact discovery
6. **social** - Social engineering intel
7. **wayback** - Historical data

---

**Framework Version**: 1.0  
**Status**: Production Ready ✅  
**Modules**: 22  
**Output Formats**: JSON + HTML  

**Print this page and keep it handy!** 📄
