# 📖 Usage Examples

Comprehensive examples for different use cases and scenarios.

## Table of Contents
1. [Basic Usage](#basic-usage)
2. [Bug Bounty Reconnaissance](#bug-bounty-reconnaissance)
3. [Corporate Asset Discovery](#corporate-asset-discovery)
4. [Threat Intelligence](#threat-intelligence)
5. [Automation & Scripting](#automation--scripting)
6. [Advanced Techniques](#advanced-techniques)

---

## Basic Usage

### List Available Modules
```bash
python main.py modules
```

### Check API Configuration
```bash
python main.py apikeys
```

### Run Single Module
```bash
# DNS enumeration (no API needed)
python main.py run example.com -m dns

# WHOIS lookup (no API needed)
python main.py run example.com -m whois

# Subdomain enumeration (uses free crt.sh)
python main.py run example.com -m subdomain
```

### Run All Modules
```bash
python main.py scan example.com --all
```

---

## Bug Bounty Reconnaissance

### Phase 1: Asset Discovery

**Step 1: Enumerate subdomains**
```bash
python main.py run target.com -m subdomain
```

Expected output: `outputs/subdomain_enumeration/`
- Find all subdomains associated with target
- Identify staging, dev, admin subdomains
- Discover forgotten/hidden subdomains

**Step 2: Certificate transparency**
```bash
python main.py run target.com -m certificate
```

Expected output: `outputs/certificate_search/`
- Historical SSL certificates
- Internal domain names leaked in certs
- Certificate issuers and validity

**Step 3: Internet-exposed assets**
```bash
python main.py run target.com -m shodan
```

Expected output: `outputs/shodan_search/`
- Open ports and services
- Server technologies
- Geographic distribution
- Vulnerable services

### Phase 2: Code Intelligence

**GitHub reconnaissance**
```bash
python main.py run target.com -m github
```

Look for:
- API keys in code
- Configuration files
- Internal documentation
- Employee repositories
- Sensitive paths

### Phase 3: Contact Discovery

**Email harvesting**
```bash
python main.py run target.com -m email
```

Use for:
- Social engineering assessments
- Password reset testing
- Account enumeration

### Phase 4: Technology Stack

**Combined scan**
```bash
python main.py scan target.com --all --output ./bounty/target-recon
```

Analyze:
- DNS records for technologies (MX, TXT, etc.)
- URLScan results for frameworks
- Shodan data for server software
- Certificate info for CDNs

---

## Corporate Asset Discovery

### Scenario: Map your company's external footprint

**Step 1: Comprehensive scan**
```bash
python main.py scan yourcompany.com --all -o ./corporate/footprint-$(date +%Y%m%d)
```

**Step 2: Verify internet-facing assets**
```bash
# Check DNS records
python main.py run yourcompany.com -m dns

# Verify with Shodan
python main.py run yourcompany.com -m shodan

# Check certificate transparency
python main.py run yourcompany.com -m certificate
```

**Step 3: Monitor GitHub exposure**
```bash
python main.py run yourcompany.com -m github
```

Review for:
- Leaked credentials
- Internal project names
- Architecture documentation
- API endpoints

**Step 4: Email security audit**
```bash
python main.py run yourcompany.com -m email
```

Verify:
- Employee email formats
- Departments exposed
- High-value targets for training

---

## Threat Intelligence

### Monitor Domain for Threats

**Daily monitoring script**
```bash
#!/bin/bash
DATE=$(date +%Y%m%d)
TARGET="monitored-domain.com"
OUTPUT_DIR="./monitoring/$TARGET/$DATE"

python main.py scan $TARGET --all -o $OUTPUT_DIR

# Compare with previous day
diff ./monitoring/$TARGET/$(date -d "yesterday" +%Y%m%d)/subdomain_enumeration/data.json \
     $OUTPUT_DIR/subdomain_enumeration/data.json
```

### Track New Subdomains
```bash
# Run daily and diff results
python main.py run target.com -m subdomain -o ./daily/$(date +%Y%m%d)

# Compare with yesterday
jq '.results[].subdomain' ./daily/$(date +%Y%m%d)/subdomain_enumeration/data.json > today.txt
jq '.results[].subdomain' ./daily/$(date -d "yesterday" +%Y%m%d)/subdomain_enumeration/data.json > yesterday.txt
diff yesterday.txt today.txt
```

### Monitor for Data Leaks
```bash
# Check for new GitHub mentions
python main.py run companyname -m github -o ./github-monitoring/$(date +%Y%m%d)
```

---

## Automation & Scripting

### Batch Scanning Multiple Targets

**Create target list**: `targets.txt`
```
target1.com
target2.com
target3.com
```

**Batch script**: `batch_scan.sh`
```bash
#!/bin/bash

while IFS= read -r target; do
    echo "Scanning $target..."
    python main.py scan "$target" --all -o "./results/$target"
    sleep 60  # Rate limiting
done < targets.txt

echo "Batch scan complete!"
```

### JSON Processing with jq

**Extract all subdomains**
```bash
jq -r '.results[].subdomain' outputs/subdomain_enumeration/data.json
```

**Count results by source**
```bash
jq -r '.results[] | .source' outputs/subdomain_enumeration/data.json | sort | uniq -c
```

**Filter high-confidence emails**
```bash
jq '.results[] | select(.confidence > 80)' outputs/email_harvesting/data.json
```

**Get all IPs from Shodan**
```bash
jq -r '.results[].ip' outputs/shodan_search/data.json | sort -u
```

### Python Integration

**Load and process results**
```python
import json

# Load JSON results
with open('outputs/subdomain_enumeration/data.json') as f:
    data = json.load(f)

# Extract subdomains
subdomains = [r['subdomain'] for r in data['results']]

# Save to file for other tools
with open('subdomains.txt', 'w') as f:
    f.write('\n'.join(subdomains))

# Use with other tools
import subprocess
for subdomain in subdomains:
    subprocess.run(['nmap', '-sV', subdomain])
```

---

## Advanced Techniques

### Combine with Active Scanning

**1. Passive discovery**
```bash
python main.py run target.com -m subdomain
```

**2. Extract subdomains**
```bash
jq -r '.results[].subdomain' outputs/subdomain_enumeration/data.json > subdomains.txt
```

**3. Active scanning**
```bash
# HTTP probing
cat subdomains.txt | httprobe > live-subdomains.txt

# Port scanning
cat live-subdomains.txt | while read host; do
    nmap -sV $host -oN "scans/$host.txt"
done

# Screenshot capture
cat live-subdomains.txt | aquatone
```

### Multi-Source Correlation

**Correlate data from multiple modules**
```python
import json

def load_module_results(module_name):
    with open(f'outputs/{module_name}/data.json') as f:
        return json.load(f)['results']

# Load data
subdomains = load_module_results('subdomain_enumeration')
shodan = load_module_results('shodan_search')
certs = load_module_results('certificate_search')

# Find subdomains with open services
subdomain_list = {r['subdomain'] for r in subdomains}
shodan_domains = {r['hostnames'] for r in shodan}

interesting = subdomain_list & shodan_domains
print(f"Subdomains with exposed services: {interesting}")
```

### Integration with CI/CD

**GitLab CI Example**: `.gitlab-ci.yml`
```yaml
recon:
  stage: security
  script:
    - pip install -r requirements.txt
    - python main.py scan $TARGET_DOMAIN --all -o ./recon-results
  artifacts:
    paths:
      - recon-results/
    expire_in: 30 days
  only:
    - schedules
```

**GitHub Actions Example**: `.github/workflows/recon.yml`
```yaml
name: Daily Recon Scan

on:
  schedule:
    - cron: '0 2 * * *'  # Daily at 2 AM

jobs:
  reconnaissance:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Setup Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.9'
      - name: Install dependencies
        run: pip install -r requirements.txt
      - name: Run reconnaissance
        env:
          SHODAN_API_KEY: ${{ secrets.SHODAN_API_KEY }}
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
        run: python main.py scan ${{ secrets.TARGET_DOMAIN }} --all
      - name: Upload results
        uses: actions/upload-artifact@v2
        with:
          name: recon-results
          path: outputs/
```

### Notification Integration

**Slack Webhook Script**
```bash
#!/bin/bash

# Run scan
python main.py scan target.com --all

# Count results
SUBDOMAIN_COUNT=$(jq '.metadata.record_count' outputs/subdomain_enumeration/data.json)

# Send to Slack
curl -X POST -H 'Content-type: application/json' \
    --data "{\"text\":\"Recon complete for target.com\n$SUBDOMAIN_COUNT subdomains found\"}" \
    $SLACK_WEBHOOK_URL
```

### Custom Report Generation

**Combine all results into single HTML**
```python
from utils.output_handler import OutputHandler
from utils.visualizer import HTMLVisualizer

# Load all results
all_results = OutputHandler.get_all_results()

# Create combined report
html = "<html><body>"
for module, results in all_results.items():
    html += f"<h2>{module.title()}</h2>"
    html += HTMLVisualizer.generate_html_report(
        data=results,
        title=module,
        module_name=module,
        target="target.com"
    )
html += "</body></html>"

# Save
with open('combined_report.html', 'w') as f:
    f.write(html)
```

---

## Performance Optimization

### Parallel Module Execution (Future Enhancement)

**Current** (Sequential):
```bash
python main.py scan target.com --all  # 3-5 minutes
```

**With async** (Planned):
```bash
python main.py scan target.com --all --parallel  # < 1 minute
```

### Selective Module Execution

**Focus on what matters**
```bash
# Quick scan (no API keys needed)
python main.py run target.com -m dns
python main.py run target.com -m whois

# Deep scan (requires API keys)
python main.py run target.com -m shodan
python main.py run target.com -m github
python main.py run target.com -m email
```

---

## Troubleshooting Examples

### API Rate Limits

**Problem**: Rate limited by Shodan
```
[!] Rate limited, waiting 60 seconds...
```

**Solution**: Upgrade API tier or add delay between scans
```bash
for target in $(cat targets.txt); do
    python main.py run $target -m shodan
    sleep 300  # 5 minute delay
done
```

### No Results Found

**Check target**
```bash
# Verify domain exists
python main.py run target.com -m dns

# Check with multiple sources
python main.py run target.com -m subdomain
python main.py run target.com -m certificate
```

### Parse Specific Data

**Extract only high-value information**
```bash
# High-confidence emails only
jq '.results[] | select(.confidence > 90) | .email' \
    outputs/email_harvesting/data.json

# Recently updated certificates
jq '.results[] | select(.not_after > "2025-01-01")' \
    outputs/certificate_search/data.json

# Services with known vulnerabilities
jq '.results[] | select(.product != "N/A")' \
    outputs/shodan_search/data.json
```

---

## Best Practices

1. **Start with free modules** to verify target
2. **Use custom output directories** for organization
3. **Process JSON with jq** for automation
4. **Combine passive + active** for complete picture
5. **Monitor changes** over time
6. **Respect rate limits** and ToS
7. **Secure API keys** (never commit .env)
8. **Review HTML reports** for human analysis
9. **Export to other tools** via JSON
10. **Automate regular scans** for monitoring

---

**Need more examples?** Check the [README.md](README.md) and [QUICKSTART.md](QUICKSTART.md)!
