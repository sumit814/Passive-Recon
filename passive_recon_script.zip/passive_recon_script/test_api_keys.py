#!/usr/bin/env python3
"""
API Key Validator
Tests all configured API keys to identify expired or invalid ones
"""

import requests
from config import Config
import sys

def test_api_key(service_name, test_func):
    """Test an API key"""
    try:
        result = test_func()
        if result:
            print(f"✅ {service_name}: VALID")
            return True
        else:
            print(f"❌ {service_name}: INVALID or EXPIRED")
            return False
    except Exception as e:
        print(f"⚠️  {service_name}: ERROR - {str(e)}")
        return False

def test_shodan():
    if not Config.SHODAN_API_KEY:
        return None
    url = f"https://api.shodan.io/api-info?key={Config.SHODAN_API_KEY}"
    response = requests.get(url, timeout=10)
    return response.status_code == 200

def test_censys():
    if not Config.CENSYS_API_ID or not Config.CENSYS_API_SECRET:
        return None
    url = "https://search.censys.io/api/v1/account"
    response = requests.get(url, auth=(Config.CENSYS_API_ID, Config.CENSYS_API_SECRET), timeout=10)
    return response.status_code == 200

def test_zoomeye():
    if not Config.ZOOMEYE_API_KEY:
        return None
    url = "https://api.zoomeye.org/resources-info"
    headers = {'API-KEY': Config.ZOOMEYE_API_KEY}
    response = requests.get(url, headers=headers, timeout=10)
    return response.status_code == 200

def test_leakix():
    if not Config.LEAKIX_API_KEY:
        return None
    url = "https://leakix.net/api/info"
    headers = {'api-key': Config.LEAKIX_API_KEY}
    response = requests.get(url, headers=headers, timeout=10)
    return response.status_code == 200

def test_greynoise():
    if not Config.GREYNOISE_API_KEY:
        return None
    url = "https://api.greynoise.io/ping"
    headers = {'key': Config.GREYNOISE_API_KEY}
    response = requests.get(url, headers=headers, timeout=10)
    return response.status_code == 200

def test_vulners():
    if not Config.VULNERS_API_KEY:
        return None
    url = "https://vulners.com/api/v3/burp/software/"
    data = {"software": "test", "version": "1.0", "apiKey": Config.VULNERS_API_KEY}
    response = requests.post(url, json=data, timeout=10)
    return response.status_code == 200

def test_fullhunt():
    if not Config.FULLHUNT_API_KEY:
        return None
    url = "https://fullhunt.io/api/v1/auth/status"
    headers = {'X-API-KEY': Config.FULLHUNT_API_KEY}
    response = requests.get(url, headers=headers, timeout=10)
    return response.status_code == 200

def test_securitytrails():
    if not Config.SECURITYTRAILS_API_KEY:
        return None
    url = "https://api.securitytrails.com/v1/ping"
    headers = {'APIKEY': Config.SECURITYTRAILS_API_KEY}
    response = requests.get(url, headers=headers, timeout=10)
    return response.status_code == 200

def test_virustotal():
    if not Config.VIRUSTOTAL_API_KEY:
        return None
    url = "https://www.virustotal.com/api/v3/users/" + Config.VIRUSTOTAL_API_KEY[:10]
    headers = {'x-apikey': Config.VIRUSTOTAL_API_KEY}
    response = requests.get(url, headers=headers, timeout=10)
    return response.status_code in [200, 404]  # 404 is ok, means API key works

def test_hunter():
    if not Config.HUNTER_API_KEY:
        return None
    url = f"https://api.hunter.io/v2/account?api_key={Config.HUNTER_API_KEY}"
    response = requests.get(url, timeout=10)
    return response.status_code == 200

def test_intelx():
    if not Config.INTELX_API_KEY:
        return None
    # IntelX doesn't have a simple ping endpoint
    return True  # Assume valid if configured

def test_github():
    if not Config.GITHUB_TOKEN:
        return None
    url = "https://api.github.com/user"
    headers = {'Authorization': f'token {Config.GITHUB_TOKEN}'}
    response = requests.get(url, headers=headers, timeout=10)
    return response.status_code == 200

def test_urlscan():
    if not Config.URLSCAN_API_KEY:
        return None
    # URLScan doesn't have a simple auth check
    return True  # Assume valid if configured

def test_abuseipdb():
    if not Config.ABUSEIPDB_API_KEY:
        return None
    url = "https://api.abuseipdb.com/api/v2/check"
    headers = {'Key': Config.ABUSEIPDB_API_KEY, 'Accept': 'application/json'}
    params = {'ipAddress': '8.8.8.8', 'maxAgeInDays': 90}
    response = requests.get(url, headers=headers, params=params, timeout=10)
    return response.status_code == 200

def main():
    print("="*70)
    print("API KEY VALIDATION REPORT")
    print("="*70)
    print()
    
    tests = [
        ("Shodan", test_shodan),
        ("Censys", test_censys),
        ("ZoomEye", test_zoomeye),
        ("LeakIX", test_leakix),
        ("GreyNoise", test_greynoise),
        ("Vulners", test_vulners),
        ("FullHunt", test_fullhunt),
        ("SecurityTrails", test_securitytrails),
        ("VirusTotal", test_virustotal),
        ("Hunter.io", test_hunter),
        ("IntelX", test_intelx),
        ("GitHub", test_github),
        ("URLScan", test_urlscan),
        ("AbuseIPDB", test_abuseipdb),
    ]
    
    valid_count = 0
    invalid_count = 0
    
    for service, test_func in tests:
        result = test_api_key(service, test_func)
        if result:
            valid_count += 1
        elif result is False:
            invalid_count += 1
    
    print()
    print("="*70)
    print(f"SUMMARY: {valid_count} Valid | {invalid_count} Invalid/Expired")
    print("="*70)
    print()
    
    if invalid_count > 0:
        print("⚠️  Some API keys are invalid or expired!")
        print("Please provide updated keys for the failed services.")
        return 1
    else:
        print("✅ All configured API keys are valid!")
        return 0

if __name__ == "__main__":
    sys.exit(main())
