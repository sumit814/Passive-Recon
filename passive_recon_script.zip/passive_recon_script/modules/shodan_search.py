"""
Shodan Internet Scanner Module
Uses: Shodan.io API
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config

class ShodanSearchModule(BaseModule):
    """Search Shodan for internet-exposed assets"""
    
    def __init__(self):
        super().__init__("shodan_search")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://api.shodan.io"
    
    def requires_api_key(self) -> bool:
        return True
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect data from Shodan"""
        if not self.check_api_key(Config.SHODAN_API_KEY, "Shodan"):
            return []
        
        results = []
        
        # Try DNS lookup first
        print("[*] Querying Shodan DNS...")
        dns_results = self._query_dns(target)
        
        # Search for the target
        print("[*] Querying Shodan search...")
        search_results = self._query_search(target)
        results.extend(search_results)
        
        return results
    
    def _query_dns(self, domain: str) -> Dict[str, Any]:
        """Query Shodan DNS for domain info"""
        url = f"https://api.shodan.io/dns/domain/{domain}"
        
        params = {
            'key': Config.SHODAN_API_KEY
        }
        
        try:
            response = self.make_request(url, params=params)
            if response:
                return response.json()
        except Exception as e:
            print(f"[!] Shodan DNS error: {str(e)}")
        
        return {}
    
    def _query_search(self, target: str) -> List[Dict[str, Any]]:
        """Search Shodan for target"""
        results = []
        
        # Method 1: Try hostname search
        url = "https://api.shodan.io/shodan/host/search"
        params = {
            'key': Config.SHODAN_API_KEY,
            'query': f'hostname:{target}',
            'minify': False
        }
        
        try:
            response = self.make_request(url, params=params)
            if response and response.json():
                data = response.json()
                
                for match in data.get('matches', []):
                    results.append({
                        'ip': match.get('ip_str', 'N/A'),
                        'port': match.get('port', 'N/A'),
                        'transport': match.get('transport', 'N/A'),
                        'service': match.get('product', 'N/A'),
                        'version': match.get('version', 'N/A'),
                        'os': match.get('os', 'N/A'),
                        'organization': match.get('org', 'N/A'),
                        'asn': match.get('asn', 'N/A'),
                        'hostnames': ', '.join(match.get('hostnames', [])),
                        'domains': ', '.join(match.get('domains', [])),
                        'country': match.get('location', {}).get('country_name', 'N/A'),
                        'city': match.get('location', {}).get('city', 'N/A'),
                        'banner': match.get('data', '')[:200],
                        'last_update': match.get('timestamp', 'N/A'),
                        'source': 'Shodan'
                    })
        except Exception as e:
            print(f"[!] Shodan hostname search error: {str(e)}")
        
        # Method 2: Try to resolve domain and query directly
        if not results:
            try:
                # Resolve domain to IP
                resolve_url = f"https://api.shodan.io/dns/resolve"
                resolve_params = {
                    'hostnames': target,
                    'key': Config.SHODAN_API_KEY
                }
                
                resolve_response = self.make_request(resolve_url, params=resolve_params)
                if resolve_response and resolve_response.json():
                    ips = resolve_response.json()
                    
                    # Query each IP
                    for hostname, ip in ips.items():
                        if ip and ip != 'N/A':
                            host_url = f"https://api.shodan.io/shodan/host/{ip}"
                            host_params = {'key': Config.SHODAN_API_KEY}
                            
                            host_response = self.make_request(host_url, params=host_params)
                            if host_response and host_response.json():
                                host_data = host_response.json()
                                
                                # Add summary entry
                                results.append({
                                    'ip': ip,
                                    'ports': ', '.join(map(str, host_data.get('ports', []))),
                                    'hostnames': ', '.join(host_data.get('hostnames', [])),
                                    'domains': ', '.join(host_data.get('domains', [])),
                                    'organization': host_data.get('org', 'N/A'),
                                    'asn': host_data.get('asn', 'N/A'),
                                    'country': host_data.get('country_name', 'N/A'),
                                    'city': host_data.get('city', 'N/A'),
                                    'os': host_data.get('os', 'N/A'),
                                    'last_update': host_data.get('last_update', 'N/A'),
                                    'source': 'Shodan (Direct)'
                                })
                                
                                # Add detailed service entries
                                for service in host_data.get('data', []):
                                    results.append({
                                        'ip': ip,
                                        'port': service.get('port', 'N/A'),
                                        'transport': service.get('transport', 'N/A'),
                                        'service': service.get('product', 'unknown'),
                                        'version': service.get('version', 'N/A'),
                                        'banner': service.get('data', '')[:200],
                                        'organization': service.get('org', 'N/A'),
                                        'os': service.get('os', 'N/A'),
                                        'timestamp': service.get('timestamp', 'N/A'),
                                        'source': 'Shodan (Service Detail)'
                                    })
            except Exception as e:
                print(f"[!] Shodan IP lookup error: {str(e)}")
        
        return results
