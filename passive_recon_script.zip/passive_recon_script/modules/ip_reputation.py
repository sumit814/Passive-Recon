"""
IP Reputation Analysis Module
Multi-source threat intelligence: VirusTotal, AbuseIPDB, GreyNoise
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config
import socket
import re

class IPReputationModule(BaseModule):
    """Analyze IP reputation using multiple threat intelligence sources"""
    
    def __init__(self):
        super().__init__("ip_reputation")
        self.ip_pattern = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')
    
    def get_api_endpoint(self) -> Optional[str]:
        return "Multiple sources"
    
    def requires_api_key(self) -> bool:
        return True
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect IP reputation from multiple sources"""
        results = []
        
        # Extract IPs from target domain
        ips = self._resolve_domain(target)
        
        if not ips:
            print("[!] No IPs found for target")
            return []
        
        for ip in ips:
            ip_data = {
                'ip': ip,
                'target': target,
                'reputation_status': 'Unknown',
                'threat_level': 'Unknown',
                'threat_sources': [],
                'clean_sources': [],
                'malicious_count': 0,
                'clean_count': 0,
                'details': {}
            }
            
            # Check VirusTotal
            if Config.VIRUSTOTAL_API_KEY:
                print(f"[*] Checking {ip} on VirusTotal...")
                vt_data = self._check_virustotal(ip)
                if vt_data:
                    ip_data['details']['virustotal'] = vt_data
                    if vt_data.get('malicious', 0) > 0:
                        ip_data['threat_sources'].append('VirusTotal')
                        ip_data['malicious_count'] += 1
                    else:
                        ip_data['clean_sources'].append('VirusTotal')
                        ip_data['clean_count'] += 1
            
            # Check AbuseIPDB
            if Config.ABUSEIPDB_API_KEY:
                print(f"[*] Checking {ip} on AbuseIPDB...")
                abuse_data = self._check_abuseipdb(ip)
                if abuse_data:
                    ip_data['details']['abuseipdb'] = abuse_data
                    if abuse_data.get('abuseConfidenceScore', 0) > 25:
                        ip_data['threat_sources'].append('AbuseIPDB')
                        ip_data['malicious_count'] += 1
                    else:
                        ip_data['clean_sources'].append('AbuseIPDB')
                        ip_data['clean_count'] += 1
            
            # Check GreyNoise
            if Config.GREYNOISE_API_KEY:
                print(f"[*] Checking {ip} on GreyNoise...")
                grey_data = self._check_greynoise(ip)
                if grey_data and grey_data.get('status') != 'rate_limited':
                    ip_data['details']['greynoise'] = grey_data
                    classification = grey_data.get('classification', '').lower()
                    if classification in ['malicious', 'suspicious']:
                        ip_data['threat_sources'].append('GreyNoise')
                        ip_data['malicious_count'] += 1
                    else:
                        ip_data['clean_sources'].append('GreyNoise')
                        ip_data['clean_count'] += 1
                elif grey_data and grey_data.get('status') == 'rate_limited':
                    print(f"  [!] GreyNoise rate limited, skipping...")
                    ip_data['details']['greynoise'] = {'status': 'rate_limited', 'note': 'API rate limit exceeded'}
            
            # Determine overall reputation status
            total_checks = ip_data['malicious_count'] + ip_data['clean_count']
            
            if total_checks == 0:
                ip_data['reputation_status'] = 'No reputation data found'
                ip_data['threat_level'] = 'Unknown'
            elif ip_data['malicious_count'] > 0:
                if ip_data['malicious_count'] >= 2:
                    ip_data['reputation_status'] = 'Malicious / Suspicious'
                    ip_data['threat_level'] = 'High'
                else:
                    ip_data['reputation_status'] = 'Potentially Suspicious'
                    ip_data['threat_level'] = 'Medium'
            else:
                ip_data['reputation_status'] = 'Clean - No negative reputation detected'
                ip_data['threat_level'] = 'Low'
            
            # Add alternative tools info
            ip_data['alternative_tools'] = self._get_alternative_tools()
            
            results.append(ip_data)
        
        return results
    
    def _resolve_domain(self, domain: str) -> List[str]:
        """Resolve domain to IP addresses"""
        ips = []
        
        # If already an IP, return it
        if self.ip_pattern.match(domain):
            return [domain]
        
        try:
            # Get A records
            addr_info = socket.getaddrinfo(domain, None, socket.AF_INET)
            for info in addr_info:
                ip = info[4][0]
                if ip not in ips:
                    ips.append(ip)
            
            print(f"[+] Resolved {domain} to {len(ips)} IP(s): {', '.join(ips)}")
        except Exception as e:
            print(f"[!] DNS resolution error: {str(e)}")
        
        return ips
    
    def _check_virustotal(self, ip: str) -> Dict[str, Any]:
        """Check IP reputation on VirusTotal"""
        url = f"https://www.virustotal.com/api/v3/ip_addresses/{ip}"
        headers = {'x-apikey': Config.VIRUSTOTAL_API_KEY}
        
        try:
            response = self.make_request(url, headers=headers)
            if response and response.json():
                data = response.json().get('data', {})
                attrs = data.get('attributes', {})
                stats = attrs.get('last_analysis_stats', {})
                
                return {
                    'malicious': stats.get('malicious', 0),
                    'suspicious': stats.get('suspicious', 0),
                    'harmless': stats.get('harmless', 0),
                    'undetected': stats.get('undetected', 0),
                    'reputation': attrs.get('reputation', 0),
                    'country': attrs.get('country', 'Unknown'),
                    'asn': attrs.get('asn', 'Unknown'),
                    'as_owner': attrs.get('as_owner', 'Unknown')
                }
        except Exception as e:
            print(f"[!] VirusTotal error: {str(e)}")
        
        return {}
    
    def _check_abuseipdb(self, ip: str) -> Dict[str, Any]:
        """Check IP reputation on AbuseIPDB"""
        url = "https://api.abuseipdb.com/api/v2/check"
        headers = {
            'Key': Config.ABUSEIPDB_API_KEY,
            'Accept': 'application/json'
        }
        params = {
            'ipAddress': ip,
            'maxAgeInDays': 90,
            'verbose': ''
        }
        
        try:
            response = self.make_request(url, params=params, headers=headers)
            if response and response.json():
                data = response.json().get('data', {})
                
                return {
                    'abuseConfidenceScore': data.get('abuseConfidenceScore', 0),
                    'usageType': data.get('usageType', 'Unknown'),
                    'isp': data.get('isp', 'Unknown'),
                    'domain': data.get('domain', 'Unknown'),
                    'countryCode': data.get('countryCode', 'Unknown'),
                    'isWhitelisted': data.get('isWhitelisted', False),
                    'totalReports': data.get('totalReports', 0),
                    'numDistinctUsers': data.get('numDistinctUsers', 0),
                    'lastReportedAt': data.get('lastReportedAt', 'Never')
                }
        except Exception as e:
            print(f"[!] AbuseIPDB error: {str(e)}")
        
        return {}
    
    def _check_greynoise(self, ip: str) -> Dict[str, Any]:
        """Check IP reputation on GreyNoise"""
        url = f"https://api.greynoise.io/v3/community/{ip}"
        headers = {'key': Config.GREYNOISE_API_KEY}
        
        try:
            response = self.make_request(url, headers=headers, timeout=10)
            if response and response.json():
                data = response.json()
                
                return {
                    'classification': data.get('classification', 'Unknown'),
                    'name': data.get('name', 'Unknown'),
                    'riot': data.get('riot', False),
                    'last_seen': data.get('last_seen', 'Never'),
                    'message': data.get('message', 'No additional info')
                }
            elif response is None:
                return {'status': 'rate_limited'}
        except Exception as e:
            print(f"[!] GreyNoise error: {str(e)}")
            return {'status': 'error', 'message': str(e)}
        
        return {'status': 'no_data'}
    
    def _get_alternative_tools(self) -> Dict[str, List[str]]:
        """List alternative tools for IP reputation checks"""
        return {
            'primary_tools': ['VirusTotal', 'AbuseIPDB', 'GreyNoise'],
            'alternatives': [
                'IPVoid - https://www.ipvoid.com/',
                'Cisco Talos Intelligence - https://talosintelligence.com/',
                'IBM X-Force Exchange - https://exchange.xforce.ibmcloud.com/',
                'AlienVault OTX - https://otx.alienvault.com/',
                'Shodan - https://www.shodan.io/',
                'IPQualityScore - https://www.ipqualityscore.com/',
                'Threat Crowd - https://www.threatcrowd.org/',
                'Hybrid Analysis - https://www.hybrid-analysis.com/'
            ]
        }
