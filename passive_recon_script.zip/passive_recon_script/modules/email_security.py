"""
Email Security Analysis Module - DMARC / SPF / DKIM
Comprehensive email security configuration analysis for domains and IPs
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
import dns.resolver
import re
import socket

class EmailSecurityModule(BaseModule):
    """Analyze DMARC, SPF, DKIM, and other email security records"""
    
    def __init__(self):
        super().__init__("email_security")
        self.resolver = dns.resolver.Resolver()
        self.resolver.timeout = 5
        self.resolver.lifetime = 5
    
    def get_api_endpoint(self) -> Optional[str]:
        return "DNS TXT Records (Direct Query)"
    
    def requires_api_key(self) -> bool:
        return False
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect email security configuration for target domain/IP"""
        results = []
        
        print(f"[*] Analyzing email security configuration for {target}...")
        
        # Determine if target is IP or domain
        is_ip = self._is_ip(target)
        
        if is_ip:
            # For IP, get PTR record and analyze that domain
            print(f"  [*] Target is IP, resolving PTR record...")
            domain = self._get_ptr_record(target)
            if domain:
                print(f"  [+] PTR: {domain}")
                results.extend(self._analyze_domain(domain, is_ptr=True, source_ip=target))
            else:
                print(f"  [!] No PTR record found for {target}")
                results.append({
                    'target': target,
                    'type': 'ip',
                    'ptr_record': None,
                    'status': 'No PTR record found',
                    'security_score': 0,
                    'recommendation': 'Configure reverse DNS (PTR) record for this IP'
                })
        else:
            # Analyze domain directly
            results.extend(self._analyze_domain(target))
            
            # Also check IPs for this domain
            ips = self._resolve_domain_ips(target)
            if ips:
                print(f"  [+] Resolved {len(ips)} IP(s)")
                for ip in ips:
                    print(f"  [*] Analyzing email security for IP {ip}...")
                    ptr_domain = self._get_ptr_record(ip)
                    if ptr_domain and ptr_domain != target:
                        results.extend(self._analyze_domain(ptr_domain, is_ptr=True, source_ip=ip))
        
        return results
    
    def _analyze_domain(self, domain: str, is_ptr: bool = False, source_ip: str = None) -> List[Dict[str, Any]]:
        """Comprehensive email security analysis for a domain"""
        results = []
        
        from datetime import datetime
        
        analysis = {
            'domain': domain,
            'type': 'ptr_domain' if is_ptr else 'primary_domain',
            'source_ip': source_ip if is_ptr else None,
            'timestamp': datetime.now().isoformat(),
            'spf': {},
            'dmarc': {},
            'dkim': {},
            'mx': {},
            'additional_records': {},
            'security_score': 0,
            'max_score': 100,
            'security_status': 'Unknown',
            'recommendations': [],
            'alternative_tools': self._get_alternative_tools()
        }
        
        # 1. Check SPF Record (25 points)
        print(f"  [1/6] Checking SPF record...")
        spf_data = self._check_spf(domain)
        analysis['spf'] = spf_data
        if spf_data.get('status') == 'valid':
            analysis['security_score'] += 25
            print(f"    ✅ SPF record found and valid")
        else:
            print(f"    ❌ SPF: {spf_data.get('status', 'Not found')}")
            analysis['recommendations'].append('Configure SPF record to prevent email spoofing')
        
        # 2. Check DMARC Record (30 points)
        print(f"  [2/6] Checking DMARC record...")
        dmarc_data = self._check_dmarc(domain)
        analysis['dmarc'] = dmarc_data
        if dmarc_data.get('status') == 'valid':
            score = 30
            policy = dmarc_data.get('policy', '')
            if policy in ['quarantine', 'reject']:
                score = 30
            elif policy == 'none':
                score = 15
            analysis['security_score'] += score
            print(f"    ✅ DMARC record found (policy: {policy})")
        else:
            print(f"    ❌ DMARC: {dmarc_data.get('status', 'Not found')}")
            analysis['recommendations'].append('Implement DMARC policy to protect domain reputation')
        
        # 3. Check DKIM Selector Records (20 points)
        print(f"  [3/6] Checking common DKIM selectors...")
        dkim_data = self._check_dkim(domain)
        analysis['dkim'] = dkim_data
        if dkim_data.get('selectors_found'):
            analysis['security_score'] += 20
            print(f"    ✅ DKIM found ({len(dkim_data['selectors_found'])} selector(s))")
        else:
            print(f"    ⚠️  DKIM: No common selectors found")
            analysis['recommendations'].append('Configure DKIM signing for email authentication')
        
        # 4. Check MX Records (10 points)
        print(f"  [4/6] Checking MX records...")
        mx_data = self._check_mx(domain)
        analysis['mx'] = mx_data
        if mx_data.get('records'):
            analysis['security_score'] += 10
            print(f"    ✅ MX records found ({len(mx_data['records'])} server(s))")
        else:
            print(f"    ⚠️  No MX records found")
        
        # 5. Check Additional Security Records (10 points)
        print(f"  [5/6] Checking additional email security records...")
        additional = self._check_additional_records(domain)
        analysis['additional_records'] = additional
        if additional.get('bimi') or additional.get('mta_sts') or additional.get('tls_rpt'):
            analysis['security_score'] += 10
            print(f"    ✅ Advanced email security configured")
        else:
            print(f"    ℹ️  No advanced security records (optional)")
        
        # 6. Check for Email-Related DNS Records (5 points)
        print(f"  [6/6] Checking email service indicators...")
        email_services = self._detect_email_services(domain)
        if email_services:
            analysis['security_score'] += 5
            analysis['email_services'] = email_services
            print(f"    ℹ️  Email service: {', '.join(email_services)}")
        
        # Calculate security status
        score = analysis['security_score']
        if score >= 80:
            analysis['security_status'] = 'Excellent'
        elif score >= 60:
            analysis['security_status'] = 'Good'
        elif score >= 40:
            analysis['security_status'] = 'Fair'
        elif score >= 20:
            analysis['security_status'] = 'Poor'
        else:
            analysis['security_status'] = 'Critical'
        
        print(f"  [+] Security Score: {score}/100 ({analysis['security_status']})")
        
        # Add summary recommendations
        if not analysis['recommendations']:
            analysis['recommendations'].append('Email security configuration is properly implemented')
        
        results.append(analysis)
        return results
    
    def _check_spf(self, domain: str) -> Dict[str, Any]:
        """Check SPF record"""
        spf_data = {
            'status': 'not_found',
            'record': None,
            'version': None,
            'mechanisms': [],
            'all_mechanism': None,
            'include_count': 0,
            'dns_lookups': 0,
            'valid': False,
            'warnings': []
        }
        
        try:
            answers = self.resolver.resolve(domain, 'TXT')
            for rdata in answers:
                txt = str(rdata).strip('"')
                if txt.startswith('v=spf1'):
                    spf_data['status'] = 'valid'
                    spf_data['record'] = txt
                    spf_data['valid'] = True
                    
                    # Parse SPF record
                    parts = txt.split()
                    spf_data['version'] = parts[0]
                    
                    for part in parts[1:]:
                        if part.startswith('include:'):
                            spf_data['mechanisms'].append(part)
                            spf_data['include_count'] += 1
                            spf_data['dns_lookups'] += 1
                        elif part.startswith('a') or part.startswith('mx'):
                            spf_data['mechanisms'].append(part)
                            spf_data['dns_lookups'] += 1
                        elif part.startswith('ip4:') or part.startswith('ip6:'):
                            spf_data['mechanisms'].append(part)
                        elif part.startswith('~all') or part.startswith('-all') or part.startswith('?all') or part.startswith('+all'):
                            spf_data['all_mechanism'] = part
                    
                    # Check for issues
                    if spf_data['dns_lookups'] > 10:
                        spf_data['warnings'].append('Exceeds 10 DNS lookups (RFC limit)')
                    
                    if spf_data['all_mechanism'] == '+all':
                        spf_data['warnings'].append('Allows all senders (+all) - insecure')
                    elif spf_data['all_mechanism'] == '?all':
                        spf_data['warnings'].append('Neutral policy (?all) - not recommended')
                    
                    break
        
        except dns.resolver.NoAnswer:
            spf_data['status'] = 'no_txt_records'
        except dns.resolver.NXDOMAIN:
            spf_data['status'] = 'domain_not_found'
        except Exception as e:
            spf_data['status'] = f'error: {str(e)}'
        
        return spf_data
    
    def _check_dmarc(self, domain: str) -> Dict[str, Any]:
        """Check DMARC record"""
        dmarc_data = {
            'status': 'not_found',
            'record': None,
            'policy': None,
            'subdomain_policy': None,
            'percentage': None,
            'rua': [],
            'ruf': [],
            'valid': False,
            'warnings': []
        }
        
        try:
            dmarc_domain = f"_dmarc.{domain}"
            answers = self.resolver.resolve(dmarc_domain, 'TXT')
            
            for rdata in answers:
                txt = str(rdata).strip('"')
                if txt.startswith('v=DMARC1'):
                    dmarc_data['status'] = 'valid'
                    dmarc_data['record'] = txt
                    dmarc_data['valid'] = True
                    
                    # Parse DMARC tags
                    tags = txt.split(';')
                    for tag in tags:
                        tag = tag.strip()
                        if tag.startswith('p='):
                            dmarc_data['policy'] = tag.split('=')[1]
                        elif tag.startswith('sp='):
                            dmarc_data['subdomain_policy'] = tag.split('=')[1]
                        elif tag.startswith('pct='):
                            dmarc_data['percentage'] = tag.split('=')[1]
                        elif tag.startswith('rua='):
                            dmarc_data['rua'] = tag.split('=')[1].split(',')
                        elif tag.startswith('ruf='):
                            dmarc_data['ruf'] = tag.split('=')[1].split(',')
                    
                    # Check for issues
                    if dmarc_data['policy'] == 'none':
                        dmarc_data['warnings'].append('Policy is "none" - monitoring only, not enforcing')
                    
                    if not dmarc_data['rua']:
                        dmarc_data['warnings'].append('No aggregate reports configured (rua)')
                    
                    break
        
        except dns.resolver.NoAnswer:
            dmarc_data['status'] = 'no_txt_records'
        except dns.resolver.NXDOMAIN:
            dmarc_data['status'] = 'not_configured'
        except Exception as e:
            dmarc_data['status'] = f'error: {str(e)}'
        
        return dmarc_data
    
    def _check_dkim(self, domain: str) -> Dict[str, Any]:
        """Check common DKIM selectors"""
        dkim_data = {
            'status': 'checked',
            'selectors_found': [],
            'selectors_checked': [],
            'records': {}
        }
        
        # Common DKIM selectors
        common_selectors = [
            'default', 'google', 'k1', 's1', 's2', 'selector1', 'selector2',
            'dkim', 'mail', 'smtp', 'email', 'mx', 'mandrill', 'mailgun',
            'sendgrid', 'amazonses', 'postmark', 'sparkpost', 'mailjet',
            'ses', 'mg', 'pm', 'k2', 'k3', 'everlytickey1', 'everlytickey2',
            'm1', 'mxvault', 'cm', 'zendesk1', 'zendesk2'
        ]
        
        for selector in common_selectors[:15]:  # Limit to first 15 to avoid too many queries
            dkim_data['selectors_checked'].append(selector)
            try:
                dkim_domain = f"{selector}._domainkey.{domain}"
                answers = self.resolver.resolve(dkim_domain, 'TXT')
                
                for rdata in answers:
                    txt = str(rdata).strip('"')
                    if 'v=DKIM1' in txt or 'p=' in txt:
                        dkim_data['selectors_found'].append(selector)
                        dkim_data['records'][selector] = txt[:100] + '...' if len(txt) > 100 else txt
                        break
            
            except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
                continue
            except Exception:
                continue
        
        return dkim_data
    
    def _check_mx(self, domain: str) -> Dict[str, Any]:
        """Check MX records"""
        mx_data = {
            'status': 'not_found',
            'records': [],
            'count': 0
        }
        
        try:
            answers = self.resolver.resolve(domain, 'MX')
            for rdata in answers:
                mx_data['records'].append({
                    'priority': rdata.preference,
                    'server': str(rdata.exchange).rstrip('.')
                })
            
            mx_data['count'] = len(mx_data['records'])
            mx_data['status'] = 'found'
            mx_data['records'].sort(key=lambda x: x['priority'])
        
        except Exception as e:
            mx_data['status'] = f'error: {str(e)}'
        
        return mx_data
    
    def _check_additional_records(self, domain: str) -> Dict[str, Any]:
        """Check additional email security records"""
        additional = {
            'bimi': None,
            'mta_sts': None,
            'tls_rpt': None,
            'dnsbl': []
        }
        
        # Check BIMI (Brand Indicators for Message Identification)
        try:
            bimi_domain = f"default._bimi.{domain}"
            answers = self.resolver.resolve(bimi_domain, 'TXT')
            for rdata in answers:
                txt = str(rdata).strip('"')
                if 'v=BIMI1' in txt:
                    additional['bimi'] = txt
                    break
        except:
            pass
        
        # Check MTA-STS
        try:
            mta_sts_domain = f"_mta-sts.{domain}"
            answers = self.resolver.resolve(mta_sts_domain, 'TXT')
            for rdata in answers:
                txt = str(rdata).strip('"')
                if 'v=STSv1' in txt:
                    additional['mta_sts'] = txt
                    break
        except:
            pass
        
        # Check TLS-RPT
        try:
            tls_rpt_domain = f"_smtp._tls.{domain}"
            answers = self.resolver.resolve(tls_rpt_domain, 'TXT')
            for rdata in answers:
                txt = str(rdata).strip('"')
                if 'v=TLSRPTv1' in txt:
                    additional['tls_rpt'] = txt
                    break
        except:
            pass
        
        return additional
    
    def _detect_email_services(self, domain: str) -> List[str]:
        """Detect email service providers"""
        services = []
        
        try:
            # Check MX records for known providers
            answers = self.resolver.resolve(domain, 'MX')
            for rdata in answers:
                mx = str(rdata.exchange).lower()
                
                if 'google' in mx or 'gmail' in mx:
                    services.append('Google Workspace')
                elif 'outlook' in mx or 'office365' in mx or 'microsoft' in mx:
                    services.append('Microsoft 365')
                elif 'zoho' in mx:
                    services.append('Zoho Mail')
                elif 'protonmail' in mx:
                    services.append('ProtonMail')
                elif 'mailgun' in mx:
                    services.append('Mailgun')
                elif 'sendgrid' in mx:
                    services.append('SendGrid')
                elif 'amazonses' in mx:
                    services.append('Amazon SES')
        except:
            pass
        
        return list(set(services))
    
    def _get_ptr_record(self, ip: str) -> Optional[str]:
        """Get PTR (reverse DNS) record for IP"""
        try:
            hostname = socket.gethostbyaddr(ip)[0]
            return hostname
        except:
            return None
    
    def _resolve_domain_ips(self, domain: str) -> List[str]:
        """Resolve domain to IPs"""
        ips = []
        try:
            answers = self.resolver.resolve(domain, 'A')
            for rdata in answers:
                ips.append(str(rdata))
        except:
            pass
        
        return ips
    
    def _is_ip(self, target: str) -> bool:
        """Check if target is an IP address"""
        import re
        ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
        return bool(re.match(ip_pattern, target))
    
    def _get_alternative_tools(self) -> Dict[str, Any]:
        """List alternative tools for email security analysis"""
        return {
            'online_tools': [
                'MXToolbox - https://mxtoolbox.com/SuperTool.aspx',
                'DMARCian - https://dmarcian.com/dmarc-inspector/',
                'DMARC Analyzer - https://www.dmarcanalyzer.com/dmarc/dmarc-record-check/',
                'Mail-Tester - https://www.mail-tester.com/',
                'Google Admin Toolbox - https://toolbox.googleapps.com/apps/checkmx/',
                'DKIM Validator - https://dkimvalidator.com/',
                'SPF Record Check - https://mxtoolbox.com/spf.aspx',
                'Postmark DMARC - https://dmarc.postmarkapp.com/',
                'EasyDMARC - https://easydmarc.com/tools/dmarc-lookup',
                'PowerDMARC - https://powerdmarc.com/dmarc-lookup/'
            ],
            'command_line_tools': [
                'dig (DNS queries)',
                'nslookup (DNS lookups)',
                'host (DNS lookups)',
                'dmarcian/dmarc-tester (CLI)',
                'swaks (SMTP testing)'
            ],
            'python_libraries': [
                'dnspython (DNS queries)',
                'checkdmarc (DMARC/SPF validation)',
                'dmarc-metrics-exporter',
                'pyspf (SPF validation)'
            ]
        }
