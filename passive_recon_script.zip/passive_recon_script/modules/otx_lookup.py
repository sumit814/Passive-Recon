"""
AlienVault OTX Lookup Module
Uses: AlienVault Open Threat Exchange (Free API)
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule

class OTXLookupModule(BaseModule):
    """Lookup threat intelligence from AlienVault OTX"""
    
    def __init__(self):
        super().__init__("otx_lookup")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://otx.alienvault.com/api/v1"
    
    def requires_api_key(self) -> bool:
        return False  # OTX has public endpoints
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect threat intelligence from OTX"""
        results = []
        
        print("[*] Querying AlienVault OTX...")
        otx_data = self._lookup_domain(target)
        results.extend(otx_data)
        
        return results
    
    def _lookup_domain(self, target: str) -> List[Dict[str, Any]]:
        """Lookup domain in OTX"""
        results = []
        url = f"https://otx.alienvault.com/api/v1/indicators/domain/{target}/general"
        
        try:
            response = self.make_request(url, timeout=30)
            if response and response.json():
                data = response.json()
                
                # General info
                pulse_info = data.get('pulse_info', {})
                
                if pulse_info.get('count', 0) > 0:
                    for pulse in pulse_info.get('pulses', [])[:10]:
                        results.append({
                            'pulse_name': pulse.get('name', 'N/A')[:100],
                            'description': pulse.get('description', 'N/A')[:200],
                            'tags': ', '.join(pulse.get('tags', []))[:100],
                            'created': pulse.get('created', 'N/A'),
                            'modified': pulse.get('modified', 'N/A'),
                            'references': ', '.join(pulse.get('references', []))[:200],
                            'malware_families': ', '.join([m.get('display_name', '') for m in pulse.get('malware_families', [])])[:100],
                            'source': 'AlienVault OTX'
                        })
                
                # If no pulses, add general info
                if not results:
                    results.append({
                        'pulse_name': 'No threats found',
                        'description': 'Domain is not associated with known threats',
                        'tags': 'N/A',
                        'created': 'N/A',
                        'modified': 'N/A',
                        'references': 'N/A',
                        'malware_families': 'N/A',
                        'source': 'AlienVault OTX'
                    })
        except Exception as e:
            print(f"[!] OTX error: {str(e)}")
        
        return results
