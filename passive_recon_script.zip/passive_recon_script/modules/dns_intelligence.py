"""
DNS Intelligence Module
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
import dns.resolver

class DNSIntelligenceModule(BaseModule):
    
    def __init__(self):
        super().__init__("dns_intelligence")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "DNS Resolver"
    
    def requires_api_key(self) -> bool:
        return False
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        results = []
        record_types = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'SOA', 'CNAME']
        
        for record_type in record_types:
            try:
                answers = dns.resolver.resolve(target, record_type)
                for rdata in answers:
                    results.append({
                        'domain': target,
                        'type': record_type,
                        'value': str(rdata),
                        'ttl': answers.rrset.ttl,
                        'source': 'DNS Resolver'
                    })
            except dns.resolver.NoAnswer:
                continue
            except dns.resolver.NXDOMAIN:
                print(f"[!] Domain {target} does not exist")
                break
            except Exception as e:
                continue
        
        return results
