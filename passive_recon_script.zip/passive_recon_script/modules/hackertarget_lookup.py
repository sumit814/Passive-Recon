"""
HackerTarget Lookup Module
Uses: HackerTarget free API (No key needed)
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule

class HackerTargetLookupModule(BaseModule):
    """Multiple reconnaissance tools from HackerTarget"""
    
    def __init__(self):
        super().__init__("hackertarget_lookup")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://api.hackertarget.com"
    
    def requires_api_key(self) -> bool:
        return False
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect data from HackerTarget"""
        results = []
        
        print("[*] Querying HackerTarget DNS...")
        dns_results = self._dns_lookup(target)
        results.extend(dns_results)
        
        print("[*] Querying HackerTarget Reverse DNS...")
        reverse_results = self._reverse_dns(target)
        results.extend(reverse_results)
        
        print("[*] Querying HackerTarget Zone Transfer...")
        zone_results = self._zone_transfer(target)
        results.extend(zone_results)
        
        return results
    
    def _dns_lookup(self, target: str) -> List[Dict[str, Any]]:
        """DNS lookup"""
        results = []
        url = f"https://api.hackertarget.com/dnslookup/?q={target}"
        
        try:
            response = self.make_request(url, timeout=30)
            if response:
                lines = response.text.strip().split('\n')
                for line in lines:
                    if line and not line.startswith('error') and not line.startswith('API'):
                        results.append({
                            'type': 'dns_record',
                            'value': line,
                            'source': 'HackerTarget DNS'
                        })
        except Exception as e:
            print(f"[!] HackerTarget DNS error: {str(e)}")
        
        return results
    
    def _reverse_dns(self, target: str) -> List[Dict[str, Any]]:
        """Reverse DNS lookup"""
        results = []
        url = f"https://api.hackertarget.com/reversedns/?q={target}"
        
        try:
            response = self.make_request(url, timeout=30)
            if response:
                lines = response.text.strip().split('\n')
                for line in lines:
                    if line and not line.startswith('error') and not line.startswith('API'):
                        results.append({
                            'type': 'reverse_dns',
                            'value': line,
                            'source': 'HackerTarget Reverse DNS'
                        })
        except Exception as e:
            print(f"[!] HackerTarget Reverse DNS error: {str(e)}")
        
        return results
    
    def _zone_transfer(self, target: str) -> List[Dict[str, Any]]:
        """Zone transfer attempt"""
        results = []
        url = f"https://api.hackertarget.com/zonetransfer/?q={target}"
        
        try:
            response = self.make_request(url, timeout=30)
            if response:
                lines = response.text.strip().split('\n')
                for line in lines:
                    if line and not line.startswith('error') and not line.startswith('API'):
                        results.append({
                            'type': 'zone_transfer',
                            'value': line,
                            'source': 'HackerTarget Zone Transfer'
                        })
        except Exception as e:
            print(f"[!] HackerTarget Zone Transfer error: {str(e)}")
        
        return results
