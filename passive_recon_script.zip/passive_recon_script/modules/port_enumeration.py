"""
Port Enumeration Module
Discover open ports from passive sources (Shodan, Censys, etc.)
"""

import requests
from typing import List, Dict, Any, Optional
import json
from .base_module import BaseModule

class PortEnumerationModule(BaseModule):
    """Enumerate open ports from passive intelligence sources"""
    
    def __init__(self):
        super().__init__("port_enumeration")
        self.description = "Discover open ports from Shodan, Censys, and other sources"
    
    def get_api_endpoint(self) -> Optional[str]:
        return None
    
    def requires_api_key(self) -> bool:
        return True
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """
        Enumerate open ports for target
        
        Args:
            target: Domain name or IP address
        
        Returns:
            List of open ports with service information
        """
        results = []
        
        # Method 1: Query Shodan for open ports
        from config import Config
        if Config.SHODAN_API_KEY:
            print(f"[*] Querying Shodan for open ports...")
            shodan_results = self._query_shodan_ports(target)
            results.extend(shodan_results)
        
        # Method 2: Query Censys for open ports
        if Config.CENSYS_API_ID and Config.CENSYS_API_SECRET:
            print(f"[*] Querying Censys for open ports...")
            censys_results = self._query_censys_ports(target)
            results.extend(censys_results)
        
        # Method 3: Query LeakIX for open ports
        if Config.LEAKIX_API_KEY:
            print(f"[*] Querying LeakIX for open ports...")
            leakix_results = self._query_leakix_ports(target)
            results.extend(leakix_results)
        
        # Method 4: Query ZoomEye for open ports
        if Config.ZOOMEYE_API_KEY:
            print(f"[*] Querying ZoomEye for open ports...")
            zoomeye_results = self._query_zoomeye_ports(target)
            results.extend(zoomeye_results)
        
        # Method 5: Query GreyNoise for port information
        if Config.GREYNOISE_API_KEY:
            print(f"[*] Querying GreyNoise for port info...")
            greynoise_results = self._query_greynoise_ports(target)
            results.extend(greynoise_results)
        
        # Deduplicate and summarize
        results = self._deduplicate_ports(results)
        
        return results
    
    def _query_shodan_ports(self, target: str) -> List[Dict]:
        """Query Shodan API for open ports"""
        from config import Config
        results = []
        
        try:
            # Shodan host lookup
            url = f"https://api.shodan.io/shodan/host/{target}"
            params = {'key': Config.SHODAN_API_KEY}
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                # Extract ports from data
                if 'ports' in data:
                    for port in data['ports']:
                        results.append({
                            'port': port,
                            'ip': target,
                            'protocol': 'tcp',
                            'source': 'Shodan',
                            'state': 'open'
                        })
                
                # Extract detailed service info
                for service in data.get('data', []):
                    port = service.get('port')
                    results.append({
                        'port': port,
                        'ip': service.get('ip_str', target),
                        'protocol': service.get('transport', 'tcp'),
                        'service': service.get('product', 'unknown'),
                        'version': service.get('version', ''),
                        'banner': service.get('data', '')[:200],
                        'org': service.get('org', ''),
                        'os': service.get('os', ''),
                        'timestamp': service.get('timestamp', ''),
                        'source': 'Shodan',
                        'state': 'open'
                    })
            
            elif response.status_code == 404:
                # Try domain search instead
                url = f"https://api.shodan.io/dns/resolve"
                params = {
                    'hostnames': target,
                    'key': Config.SHODAN_API_KEY
                }
                
                response = requests.get(url, params=params, timeout=10)
                if response.status_code == 200:
                    ips = response.json()
                    for hostname, ip in ips.items():
                        # Recursively get ports for resolved IP
                        if ip:
                            return self._query_shodan_ports(ip)
        
        except Exception as e:
            print(f"[!] Shodan error: {str(e)}")
        
        return results
    
    def _query_censys_ports(self, target: str) -> List[Dict]:
        """Query Censys API for open ports"""
        from config import Config
        results = []
        
        try:
            url = f"https://search.censys.io/api/v2/hosts/{target}"
            auth = (Config.CENSYS_API_ID, Config.CENSYS_API_SECRET)
            
            response = requests.get(url, auth=auth, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                result = data.get('result', {})
                
                # Extract services
                for service in result.get('services', []):
                    port = service.get('port')
                    results.append({
                        'port': port,
                        'ip': target,
                        'protocol': service.get('transport_protocol', 'tcp'),
                        'service': service.get('service_name', 'unknown'),
                        'banner': str(service.get('banner', ''))[:200],
                        'software': str(service.get('software', [])),
                        'timestamp': service.get('observed_at', ''),
                        'source': 'Censys',
                        'state': 'open'
                    })
        
        except Exception as e:
            print(f"[!] Censys error: {str(e)}")
        
        return results
    
    def _query_leakix_ports(self, target: str) -> List[Dict]:
        """Query LeakIX API for open ports"""
        from config import Config
        results = []
        
        try:
            url = f"https://leakix.net/api/subdomains/{target}"
            headers = {'api-key': Config.LEAKIX_API_KEY}
            
            response = requests.get(url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                if not isinstance(data, list):
                    data = []
                
                for item in data:
                    if 'port' in item:
                        results.append({
                            'port': item.get('port'),
                            'ip': item.get('ip', target),
                            'protocol': item.get('protocol', 'tcp'),
                            'service': item.get('service', 'unknown'),
                            'subdomain': item.get('subdomain', ''),
                            'timestamp': item.get('time', ''),
                            'source': 'LeakIX',
                            'state': 'open'
                        })
        
        except Exception as e:
            print(f"[!] LeakIX error: {str(e)}")
        
        return results
    
    def _query_zoomeye_ports(self, target: str) -> List[Dict]:
        """Query ZoomEye API for open ports"""
        from config import Config
        results = []
        
        try:
            # Search for target
            url = f"https://api.zoomeye.org/host/search"
            headers = {'API-KEY': Config.ZOOMEYE_API_KEY}
            params = {'query': target, 'page': 1}
            
            response = requests.get(url, headers=headers, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                for match in data.get('matches', []):
                    port = match.get('portinfo', {}).get('port')
                    if port:
                        results.append({
                            'port': port,
                            'ip': match.get('ip', target),
                            'protocol': match.get('portinfo', {}).get('service', 'tcp'),
                            'service': match.get('portinfo', {}).get('app', 'unknown'),
                            'version': match.get('portinfo', {}).get('version', ''),
                            'banner': match.get('portinfo', {}).get('banner', '')[:200],
                            'os': match.get('system', ''),
                            'country': match.get('geoinfo', {}).get('country', {}).get('code', ''),
                            'timestamp': match.get('timestamp', ''),
                            'source': 'ZoomEye',
                            'state': 'open'
                        })
        
        except Exception as e:
            print(f"[!] ZoomEye error: {str(e)}")
        
        return results
    
    def _query_greynoise_ports(self, target: str) -> List[Dict]:
        """Query GreyNoise API for port information"""
        from config import Config
        results = []
        
        try:
            url = f"https://api.greynoise.io/v3/community/{target}"
            headers = {'key': Config.GREYNOISE_API_KEY}
            
            response = requests.get(url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                # GreyNoise provides metadata about scanning activity
                if data.get('seen', False):
                    results.append({
                        'ip': target,
                        'classification': data.get('classification', ''),
                        'name': data.get('name', ''),
                        'last_seen': data.get('last_seen', ''),
                        'message': data.get('message', ''),
                        'source': 'GreyNoise',
                        'info': 'Scanning activity detected'
                    })
        
        except Exception as e:
            print(f"[!] GreyNoise error: {str(e)}")
        
        return results
    
    def _deduplicate_ports(self, results: List[Dict]) -> List[Dict]:
        """Deduplicate port entries and merge information"""
        port_map = {}
        
        for result in results:
            port = result.get('port')
            ip = result.get('ip', '')
            
            if not port:
                continue
            
            key = f"{ip}:{port}"
            
            if key not in port_map:
                port_map[key] = result
            else:
                # Merge additional information
                existing = port_map[key]
                
                # Update with more detailed info if available
                if 'service' in result and result['service'] != 'unknown':
                    existing['service'] = result['service']
                
                if 'banner' in result and result['banner']:
                    existing['banner'] = result['banner']
                
                if 'version' in result and result['version']:
                    existing['version'] = result['version']
                
                # Add multiple sources
                if 'sources' not in existing:
                    existing['sources'] = [existing.get('source', '')]
                
                existing['sources'].append(result.get('source', ''))
                existing['sources'] = list(set(existing['sources']))
        
        return list(port_map.values())
