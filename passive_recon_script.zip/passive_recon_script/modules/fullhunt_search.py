"""
FullHunt Search Module
Uses: FullHunt API for attack surface discovery
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config

class FullHuntSearchModule(BaseModule):
    """Search FullHunt for attack surface"""
    
    def __init__(self):
        super().__init__("fullhunt_search")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://fullhunt.io/api/v1"
    
    def requires_api_key(self) -> bool:
        return True
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect data from FullHunt"""
        if not self.check_api_key(Config.FULLHUNT_API_KEY, "FullHunt"):
            return []
        
        results = []
        
        # Search for domain details
        print("[*] Querying FullHunt...")
        domain_results = self._search_domain(target)
        results.extend(domain_results)
        
        return results
    
    def _search_domain(self, target: str) -> List[Dict[str, Any]]:
        """Search FullHunt for domain"""
        results = []
        url = f"https://fullhunt.io/api/v1/domain/{target}/details"
        
        headers = {
            'X-API-KEY': Config.FULLHUNT_API_KEY
        }
        
        try:
            response = self.make_request(url, headers=headers)
            if response and response.json():
                data = response.json()
                
                # Process hosts
                for host in data.get('hosts', []):
                    results.append({
                        'host': host.get('host', 'N/A'),
                        'ip': host.get('ip', 'N/A'),
                        'port': host.get('port', 'N/A'),
                        'protocol': host.get('protocol', 'N/A'),
                        'service': host.get('service', 'N/A'),
                        'status': host.get('status_code', 'N/A'),
                        'title': host.get('title', 'N/A')[:100],
                        'technology': ', '.join(host.get('technologies', []))[:100],
                        'cdn': host.get('cdn', 'N/A'),
                        'cloud': host.get('cloud_provider', 'N/A'),
                        'source': 'FullHunt'
                    })
        except Exception as e:
            print(f"[!] FullHunt error: {str(e)}")
        
        return results
