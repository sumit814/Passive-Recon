"""
Email Harvesting Module
Uses: Hunter.io, IntelX
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config

class EmailHarvestingModule(BaseModule):
    """Harvest emails associated with target domain"""
    
    def __init__(self):
        super().__init__("email_harvesting")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "Multiple sources"
    
    def requires_api_key(self) -> bool:
        return True
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect emails from multiple sources"""
        results = []
        
        # Hunter.io
        if Config.HUNTER_API_KEY:
            print("[*] Querying Hunter.io...")
            hunter_results = self._query_hunter(target)
            results.extend(hunter_results)
        
        # IntelX
        if Config.INTELX_API_KEY:
            print("[*] Querying IntelX...")
            intelx_results = self._query_intelx(target)
            results.extend(intelx_results)
        
        if not results:
            print("[!] No API keys configured for email harvesting")
        
        return results
    
    def _query_hunter(self, domain: str) -> List[Dict[str, Any]]:
        """Query Hunter.io for emails"""
        results = []
        url = "https://api.hunter.io/v2/domain-search"
        
        params = {
            'domain': domain,
            'api_key': Config.HUNTER_API_KEY
        }
        
        try:
            response = self.make_request(url, params=params)
            if response and response.json():
                data = response.json()
                
                for email in data.get('data', {}).get('emails', []):
                    results.append({
                        'email': email.get('value', 'N/A'),
                        'first_name': email.get('first_name', 'N/A'),
                        'last_name': email.get('last_name', 'N/A'),
                        'position': email.get('position', 'N/A'),
                        'department': email.get('department', 'N/A'),
                        'type': email.get('type', 'N/A'),
                        'confidence': email.get('confidence', 0),
                        'sources': len(email.get('sources', [])),
                        'source': 'Hunter.io'
                    })
        except Exception as e:
            print(f"[!] Hunter.io error: {str(e)}")
        
        return results
    
    def _query_intelx(self, domain: str) -> List[Dict[str, Any]]:
        """Query IntelX for emails"""
        results = []
        url = "https://2.intelx.io/phonebook/search"
        
        headers = {
            'x-key': Config.INTELX_API_KEY
        }
        
        payload = {
            'term': domain,
            'maxresults': 100,
            'media': 0,
            'target': 1
        }
        
        try:
            response = self.make_request(url, method='POST', json_data=payload, headers=headers)
            if response and response.json():
                data = response.json()
                search_id = data.get('id')
                
                if search_id:
                    # Get results
                    results_url = f"https://2.intelx.io/phonebook/search/result"
                    params = {'id': search_id}
                    
                    result_response = self.make_request(results_url, params=params, headers=headers)
                    if result_response and result_response.json():
                        for item in result_response.json().get('selectors', []):
                            email = item.get('selectorvalue', '')
                            if '@' in email:
                                results.append({
                                    'email': email,
                                    'first_name': 'N/A',
                                    'last_name': 'N/A',
                                    'position': 'N/A',
                                    'department': 'N/A',
                                    'type': 'N/A',
                                    'confidence': 0,
                                    'sources': 0,
                                    'source': 'IntelX'
                                })
        except Exception as e:
            print(f"[!] IntelX error: {str(e)}")
        
        return results
    
    def filter_data(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Filter emails using formatter"""
        return self.formatter.filter_false_positives(data, "email")
