"""
Subdomain Enumeration Module
Uses: crt.sh, SecurityTrails, VirusTotal
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config
import re

class SubdomainEnumModule(BaseModule):
    """Enumerate subdomains from multiple sources"""
    
    def __init__(self):
        super().__init__("subdomain_enumeration")
        self.sources = []
    
    def get_api_endpoint(self) -> Optional[str]:
        return "Multiple sources"
    
    def requires_api_key(self) -> bool:
        return False  # crt.sh works without API key
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect subdomains from all available sources"""
        all_subdomains = []
        
        # Source 1: crt.sh (Certificate Transparency Logs)
        print("[*] Querying crt.sh...")
        crtsh_results = self._query_crtsh(target)
        all_subdomains.extend(crtsh_results)
        
        # Source 2: SecurityTrails (if API key available)
        if Config.SECURITYTRAILS_API_KEY:
            print("[*] Querying SecurityTrails...")
            st_results = self._query_securitytrails(target)
            all_subdomains.extend(st_results)
        
        # Source 3: VirusTotal (if API key available)
        if Config.VIRUSTOTAL_API_KEY:
            print("[*] Querying VirusTotal...")
            vt_results = self._query_virustotal(target)
            all_subdomains.extend(vt_results)
        
        return all_subdomains
    
    def _query_crtsh(self, domain: str) -> List[Dict[str, Any]]:
        """Query crt.sh for subdomains"""
        results = []
        url = "https://crt.sh/"
        
        params = {
            'q': f'%.{domain}',
            'output': 'json'
        }
        
        try:
            response = self.make_request(url, params=params)
            if response and response.json():
                data = response.json()
                seen = set()
                
                for entry in data:
                    name_value = entry.get('name_value', '')
                    # Split by newlines (crt.sh can return multiple domains)
                    subdomains = name_value.split('\n')
                    
                    for subdomain in subdomains:
                        subdomain = subdomain.strip().lower()
                        # Skip wildcards
                        if '*' not in subdomain and subdomain not in seen:
                            seen.add(subdomain)
                            results.append({
                                'subdomain': subdomain,
                                'source': 'crt.sh',
                                'issuer': entry.get('issuer_name', 'N/A')[:50]
                            })
        except Exception as e:
            print(f"[!] crt.sh error: {str(e)}")
        
        return results
    
    def _query_securitytrails(self, domain: str) -> List[Dict[str, Any]]:
        """Query SecurityTrails API for subdomains"""
        results = []
        url = f"https://api.securitytrails.com/v1/domain/{domain}/subdomains"
        
        headers = {
            'APIKEY': Config.SECURITYTRAILS_API_KEY
        }
        
        try:
            response = self.make_request(url, headers=headers)
            if response and response.json():
                data = response.json()
                subdomains = data.get('subdomains', [])
                
                for sub in subdomains:
                    full_domain = f"{sub}.{domain}" if sub else domain
                    results.append({
                        'subdomain': full_domain,
                        'source': 'SecurityTrails',
                        'issuer': 'N/A'
                    })
        except Exception as e:
            print(f"[!] SecurityTrails error: {str(e)}")
        
        return results
    
    def _query_virustotal(self, domain: str) -> List[Dict[str, Any]]:
        """Query VirusTotal API for subdomains"""
        results = []
        url = f"https://www.virustotal.com/api/v3/domains/{domain}/subdomains"
        
        headers = {
            'x-apikey': Config.VIRUSTOTAL_API_KEY
        }
        
        try:
            response = self.make_request(url, headers=headers)
            if response and response.json():
                data = response.json()
                subdomains = data.get('data', [])
                
                for entry in subdomains:
                    subdomain = entry.get('id', '')
                    if subdomain:
                        results.append({
                            'subdomain': subdomain,
                            'source': 'VirusTotal',
                            'issuer': 'N/A'
                        })
        except Exception as e:
            print(f"[!] VirusTotal error: {str(e)}")
        
        return results
    
    def filter_data(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Filter subdomains using formatter"""
        return self.formatter.filter_false_positives(data, "subdomain")
