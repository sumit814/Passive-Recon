"""
GreyNoise Lookup Module
Uses: GreyNoise API for internet noise analysis
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config
import socket

class GreyNoiseLookupModule(BaseModule):
    """Lookup IPs in GreyNoise for threat intelligence"""
    
    def __init__(self):
        super().__init__("greynoise_lookup")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://api.greynoise.io"
    
    def requires_api_key(self) -> bool:
        return True
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect data from GreyNoise"""
        if not self.check_api_key(Config.GREYNOISE_API_KEY, "GreyNoise"):
            return []
        
        results = []
        
        # Resolve domain to IP
        ips = self._resolve_domain(target)
        
        if not ips:
            print(f"[!] Could not resolve {target} to IP addresses")
            return []
        
        # Lookup each IP
        for ip in ips:
            print(f"[*] Querying GreyNoise for {ip}...")
            noise_data = self._lookup_ip(ip)
            if noise_data:
                results.append(noise_data)
        
        return results
    
    def _resolve_domain(self, domain: str) -> List[str]:
        """Resolve domain to IPs"""
        ips = []
        try:
            # Check if already IP
            socket.inet_aton(domain)
            return [domain]
        except:
            pass
        
        try:
            ip_info = socket.getaddrinfo(domain, None)
            for info in ip_info:
                ip = info[4][0]
                if ip not in ips:
                    ips.append(ip)
        except Exception as e:
            print(f"[!] DNS resolution error: {str(e)}")
        
        return ips
    
    def _lookup_ip(self, ip: str) -> Optional[Dict[str, Any]]:
        """Lookup IP in GreyNoise"""
        url = f"https://api.greynoise.io/v3/community/{ip}"
        
        headers = {
            'key': Config.GREYNOISE_API_KEY
        }
        
        try:
            response = self.make_request(url, headers=headers)
            if response:
                try:
                    data = response.json()
                    
                    return {
                        'ip': data.get('ip', ip),
                        'noise': data.get('noise', False),
                        'riot': data.get('riot', False),
                        'classification': data.get('classification', 'N/A'),
                        'name': data.get('name', 'N/A'),
                        'link': data.get('link', 'N/A'),
                        'last_seen': data.get('last_seen', 'N/A'),
                        'message': data.get('message', 'N/A'),
                        'source': 'GreyNoise'
                    }
                except ValueError:
                    print(f"[!] Invalid JSON response from GreyNoise for {ip}")
            else:
                print(f"[!] No response from GreyNoise for {ip}")
        except Exception as e:
            print(f"[!] GreyNoise error for {ip}: {str(e)}")
        
        return None
