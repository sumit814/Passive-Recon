"""
DNSlytics Lookup Module
Uses: Web scraping (No API key needed)
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from bs4 import BeautifulSoup

class DNSlyticsLookupModule(BaseModule):
    """Lookup domain information from DNSlytics"""
    
    def __init__(self):
        super().__init__("dnslytics_lookup")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://dnslytics.com"
    
    def requires_api_key(self) -> bool:
        return False
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect data from DNSlytics"""
        results = []
        
        print("[*] Querying DNSlytics...")
        info = self._get_domain_info(target)
        if info:
            results.append(info)
        
        return results
    
    def _get_domain_info(self, target: str) -> Optional[Dict[str, Any]]:
        """Get domain information"""
        url = f"https://dnslytics.com/domain/{target}"
        
        try:
            response = self.make_request(url, timeout=30)
            if response:
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Extract available information
                info = {
                    'domain': target,
                    'source': 'DNSlytics'
                }
                
                # Try to extract IP addresses
                ip_section = soup.find('div', class_='ip-addresses')
                if ip_section:
                    ips = [ip.text.strip() for ip in ip_section.find_all('a')]
                    info['ip_addresses'] = ', '.join(ips[:5])
                else:
                    info['ip_addresses'] = 'N/A'
                
                # Try to extract nameservers
                ns_section = soup.find('div', text='Nameservers')
                if ns_section:
                    ns_list = ns_section.find_next('div')
                    if ns_list:
                        nameservers = [ns.text.strip() for ns in ns_list.find_all('a')]
                        info['nameservers'] = ', '.join(nameservers[:5])
                else:
                    info['nameservers'] = 'N/A'
                
                # Hosting provider
                info['hosting'] = 'N/A'  # Would need more parsing
                
                return info
        except Exception as e:
            print(f"[!] DNSlytics error: {str(e)}")
        
        return None
