"""
GitHub Intelligence Module
Uses: GitHub API for code search, repos, and sensitive data
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config

class GitHubIntelModule(BaseModule):
    """Search GitHub for code and repositories related to target"""
    
    def __init__(self):
        super().__init__("github_intelligence")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://api.github.com"
    
    def requires_api_key(self) -> bool:
        return True
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect GitHub intelligence"""
        if not self.check_api_key(Config.GITHUB_TOKEN, "GitHub"):
            return []
        
        results = []
        
        # Search code
        print("[*] Searching GitHub code...")
        code_results = self._search_code(target)
        results.extend(code_results)
        
        # Search repositories
        print("[*] Searching GitHub repositories...")
        repo_results = self._search_repos(target)
        results.extend(repo_results)
        
        return results
    
    def _search_code(self, target: str) -> List[Dict[str, Any]]:
        """Search GitHub code for target"""
        results = []
        url = "https://api.github.com/search/code"
        
        headers = {
            'Authorization': f'token {Config.GITHUB_TOKEN}',
            'Accept': 'application/vnd.github.v3+json'
        }
        
        # Search for domain in code
        params = {
            'q': f'{target}',
            'per_page': 100
        }
        
        try:
            response = self.make_request(url, params=params, headers=headers)
            if response and response.json():
                data = response.json()
                
                for item in data.get('items', [])[:50]:  # Limit to 50 results
                    results.append({
                        'type': 'code',
                        'name': item.get('name', 'N/A'),
                        'path': item.get('path', 'N/A'),
                        'repository': item.get('repository', {}).get('full_name', 'N/A'),
                        'url': item.get('html_url', 'N/A'),
                        'score': item.get('score', 0),
                        'source': 'GitHub Code Search'
                    })
        except Exception as e:
            print(f"[!] GitHub code search error: {str(e)}")
        
        return results
    
    def _search_repos(self, target: str) -> List[Dict[str, Any]]:
        """Search GitHub repositories"""
        results = []
        url = "https://api.github.com/search/repositories"
        
        headers = {
            'Authorization': f'token {Config.GITHUB_TOKEN}',
            'Accept': 'application/vnd.github.v3+json'
        }
        
        params = {
            'q': target,
            'per_page': 50
        }
        
        try:
            response = self.make_request(url, params=params, headers=headers)
            if response and response.json():
                data = response.json()
                
                for repo in data.get('items', []):
                    results.append({
                        'type': 'repository',
                        'name': repo.get('full_name', 'N/A'),
                        'description': (repo.get('description', 'N/A') or 'N/A')[:100],
                        'url': repo.get('html_url', 'N/A'),
                        'stars': repo.get('stargazers_count', 0),
                        'forks': repo.get('forks_count', 0),
                        'language': repo.get('language', 'N/A'),
                        'last_updated': repo.get('updated_at', 'N/A'),
                        'source': 'GitHub Repository Search'
                    })
        except Exception as e:
            print(f"[!] GitHub repo search error: {str(e)}")
        
        return results
