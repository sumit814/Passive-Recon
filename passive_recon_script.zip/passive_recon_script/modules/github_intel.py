"""
GitHub Intelligence Module - Enhanced with CAPTCHA Avoidance
Uses: GitHub API for code search, repos, and sensitive data
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config
import time
import random
import hashlib

class GitHubIntelModule(BaseModule):
    """Search GitHub for code and repositories - CAPTCHA aware"""
    
    def __init__(self):
        super().__init__("github_intelligence")
        self.last_request_time = 0
        self.request_count = 0
        self.search_cache = {}
        
        # CAPTCHA avoidance settings
        self.min_delay = 2  # Minimum seconds between requests
        self.max_delay = 5  # Maximum seconds between requests
        self.requests_per_batch = 10  # Requests before taking a longer break
        self.batch_cooldown = 10  # Seconds to wait after a batch
        
        # User agents rotation for API requests
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
        ]
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://api.github.com"
    
    def requires_api_key(self) -> bool:
        return True
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect GitHub intelligence using native API (CAPTCHA-free)"""
        if not self.check_api_key(Config.GITHUB_TOKEN, "GitHub"):
            print("[!] GitHub API token not configured")
            print("[!] Without API token, web scraping will trigger CAPTCHA")
            return self._fallback_results(target)
        
        results = []
        
        print("[*] Using GitHub native API (CAPTCHA-free method)")
        
        # Search code with smart delays
        print("[*] Searching GitHub code...")
        self._smart_delay()
        code_results = self._search_code(target)
        results.extend(code_results)
        
        # Batch cooldown between different search types
        if len(code_results) > 0:
            print(f"[*] Batch cooldown: {self.batch_cooldown}s...")
            time.sleep(self.batch_cooldown)
        
        # Search repositories
        print("[*] Searching GitHub repositories...")
        self._smart_delay()
        repo_results = self._search_repos(target)
        results.extend(repo_results)
        
        # Add metadata
        if results:
            results[0]['search_method'] = 'GitHub Native API'
            results[0]['captcha_encountered'] = False
            results[0]['rate_limiting'] = 'Intelligent delays applied'
            results[0]['alternative_tools'] = self._get_alternative_tools()
        else:
            # No results but still return metadata
            results.append({
                'target': target,
                'search_method': 'GitHub Native API',
                'status': 'No results found',
                'captcha_encountered': False,
                'alternative_tools': self._get_alternative_tools()
            })
        
        return results
    
    def _smart_delay(self):
        """Implement intelligent delay to avoid rate limiting"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        # Calculate required delay with jitter for human-like behavior
        required_delay = random.uniform(self.min_delay, self.max_delay)
        
        if time_since_last < required_delay:
            sleep_time = required_delay - time_since_last
            jitter = random.uniform(0, 0.5)
            sleep_time += jitter
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
        self.request_count += 1
        
        # Periodic longer cooldown
        if self.request_count % self.requests_per_batch == 0:
            print(f"[*] Periodic cooldown after {self.requests_per_batch} requests...")
            time.sleep(self.batch_cooldown)
    
    def _search_code(self, target: str) -> List[Dict[str, Any]]:
        """Search GitHub code for target using native API"""
        results = []
        
        # Check cache
        cache_key = hashlib.md5(f"code_{target}".encode()).hexdigest()
        if cache_key in self.search_cache:
            print(f"  [*] Using cached results")
            return self.search_cache[cache_key]
        
        url = "https://api.github.com/search/code"
        
        headers = {
            'Authorization': f'token {Config.GITHUB_TOKEN}',
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': random.choice(self.user_agents)
        }
        
        # Optimized query to reduce API calls
        params = {
            'q': f'{target}',
            'per_page': 30,  # Reduced to avoid rate limits
            'sort': 'indexed'
        }
        
        try:
            response = self.make_request(url, params=params, headers=headers, timeout=15)
            
            if response and response.status_code == 200:
                data = response.json()
                
                for item in data.get('items', []):
                    results.append({
                        'type': 'code',
                        'name': item.get('name', 'N/A'),
                        'path': item.get('path', 'N/A'),
                        'repository': item.get('repository', {}).get('full_name', 'N/A'),
                        'url': item.get('html_url', 'N/A'),
                        'score': item.get('score', 0),
                        'source': 'GitHub Code Search (API)'
                    })
                
                # Cache results
                self.search_cache[cache_key] = results
                print(f"  [+] Found {len(results)} code results")
                
            elif response and response.status_code == 403:
                print(f"  [!] Rate limit hit - GitHub API limit reached")
                print(f"  [!] Waiting 60s before retry...")
                time.sleep(60)
                
            elif response and response.status_code == 422:
                print(f"  [!] Query too broad or invalid")
                
        except Exception as e:
            print(f"[!] GitHub code search error: {str(e)}")
        
        return results
    
    def _search_repos(self, target: str) -> List[Dict[str, Any]]:
        """Search GitHub repositories using native API"""
        results = []
        
        # Check cache
        cache_key = hashlib.md5(f"repo_{target}".encode()).hexdigest()
        if cache_key in self.search_cache:
            print(f"  [*] Using cached results")
            return self.search_cache[cache_key]
        
        url = "https://api.github.com/search/repositories"
        
        headers = {
            'Authorization': f'token {Config.GITHUB_TOKEN}',
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': random.choice(self.user_agents)
        }
        
        params = {
            'q': target,
            'per_page': 30,  # Reduced to avoid rate limits
            'sort': 'updated'
        }
        
        try:
            response = self.make_request(url, params=params, headers=headers, timeout=15)
            
            if response and response.status_code == 200:
                data = response.json()
                
                for repo in data.get('items', []):
                    results.append({
                        'type': 'repository',
                        'name': repo.get('full_name', 'N/A'),
                        'description': (repo.get('description', 'N/A') or 'N/A')[:100],
                        'url': repo.get('html_url', 'N/A'),
                        'stars': repo.get('stargazers_count', 0),
                        'forks': repo.get('forks_count', 0),
                        'language': repo.get('language', 'N/A'),
                        'last_updated': repo.get('updated_at', 'N/A'),
                        'source': 'GitHub Repository Search (API)'
                    })
                
                # Cache results
                self.search_cache[cache_key] = results
                print(f"  [+] Found {len(results)} repository results")
                
            elif response and response.status_code == 403:
                print(f"  [!] Rate limit hit - GitHub API limit reached")
                
        except Exception as e:
            print(f"[!] GitHub repo search error: {str(e)}")
        
        return results
    
    def _fallback_results(self, target: str) -> List[Dict[str, Any]]:
        """Return guidance when API key is not available"""
        return [{
            'target': target,
            'status': 'API key required',
            'message': 'GitHub API token is required to avoid CAPTCHA',
            'recommendation': 'Configure GITHUB_TOKEN in .env file',
            'how_to_get_token': [
                '1. Go to https://github.com/settings/tokens',
                '2. Click "Generate new token (classic)"',
                '3. Select scopes: public_repo, read:org',
                '4. Generate and copy the token',
                '5. Add to .env: GITHUB_TOKEN=your_token_here'
            ],
            'alternative_tools': self._get_alternative_tools(),
            'captcha_risk': 'HIGH - Web scraping will trigger CAPTCHA',
            'note': 'Always use GitHub API with authentication token'
        }]
    
    def _get_alternative_tools(self) -> Dict[str, List[str]]:
        """List alternative tools for GitHub intelligence"""
        return {
            'primary_tool': 'GitHub Native API (Recommended - CAPTCHA-free)',
            'alternatives': [
                'GitLeaks - https://github.com/zricethezav/gitleaks',
                'TruffleHog - https://github.com/trufflesecurity/trufflehog',
                'Gitrob - https://github.com/michenriksen/gitrob',
                'GitDorker - https://github.com/obheda12/GitDorker',
                'GitHub Advanced Search - https://github.com/search/advanced',
                'GitHound - https://github.com/tillson/git-hound',
                'Shhgit - https://github.com/eth0izzle/shhgit',
                'GitAllSecrets - https://github.com/anshumanbh/git-all-secrets'
            ],
            'best_practices': [
                'Always use authenticated API requests',
                'Implement request throttling (2-5s delays)',
                'Use result caching to minimize API calls',
                'Rotate User-Agent headers',
                'Never scrape GitHub web pages (triggers CAPTCHA)'
            ]
        }
