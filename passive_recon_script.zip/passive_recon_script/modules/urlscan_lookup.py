"""
URLScan.io Module
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config
import time

class URLScanModule(BaseModule):
    
    def __init__(self):
        super().__init__("urlscan_lookup")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://urlscan.io/api/v1"
    
    def requires_api_key(self) -> bool:
        return False
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        results = []
        url = "https://urlscan.io/api/v1/search/"
        
        params = {'q': f'domain:{target}'}
        headers = {}
        
        if Config.URLSCAN_API_KEY:
            headers['API-Key'] = Config.URLSCAN_API_KEY
        
        try:
            response = self.make_request(url, params=params, headers=headers)
            if response and response.json():
                data = response.json()
                
                for result in data.get('results', [])[:50]:
                    results.append({
                        'url': result.get('page', {}).get('url', 'N/A'),
                        'domain': result.get('page', {}).get('domain', 'N/A'),
                        'ip': result.get('page', {}).get('ip', 'N/A'),
                        'asn': result.get('page', {}).get('asn', 'N/A'),
                        'server': result.get('page', {}).get('server', 'N/A'),
                        'country': result.get('page', {}).get('country', 'N/A'),
                        'scan_date': result.get('task', {}).get('time', 'N/A'),
                        'source': 'URLScan.io'
                    })
        except Exception as e:
            print(f"[!] URLScan error: {str(e)}")
        
        return results
