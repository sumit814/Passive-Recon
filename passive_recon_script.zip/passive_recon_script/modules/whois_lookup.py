"""
WHOIS Lookup Module
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
import subprocess

class WhoisModule(BaseModule):
    
    def __init__(self):
        super().__init__("whois_lookup")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "WHOIS"
    
    def requires_api_key(self) -> bool:
        return False
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        results = []
        
        try:
            result = subprocess.run(
                ['whois', target],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                whois_data = result.stdout
                
                # Parse key information
                info = {
                    'domain': target,
                    'registrar': 'N/A',
                    'creation_date': 'N/A',
                    'expiration_date': 'N/A',
                    'updated_date': 'N/A',
                    'name_servers': 'N/A',
                    'status': 'N/A',
                    'source': 'WHOIS'
                }
                
                for line in whois_data.split('\n'):
                    line = line.strip()
                    if 'Registrar:' in line:
                        info['registrar'] = line.split(':', 1)[1].strip()
                    elif 'Creation Date:' in line or 'Created:' in line:
                        info['creation_date'] = line.split(':', 1)[1].strip()
                    elif 'Expiration Date:' in line or 'Expires:' in line:
                        info['expiration_date'] = line.split(':', 1)[1].strip()
                    elif 'Updated Date:' in line or 'Updated:' in line:
                        info['updated_date'] = line.split(':', 1)[1].strip()
                    elif 'Name Server:' in line:
                        if info['name_servers'] == 'N/A':
                            info['name_servers'] = line.split(':', 1)[1].strip()
                        else:
                            info['name_servers'] += ', ' + line.split(':', 1)[1].strip()
                    elif 'Status:' in line:
                        info['status'] = line.split(':', 1)[1].strip()
                
                results.append(info)
        except Exception as e:
            print(f"[!] WHOIS error: {str(e)}")
        
        return results
