"""
SSL Certificate Search Module
Uses: crt.sh, Censys
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config
import base64

class CertificateSearchModule(BaseModule):
    """Search for SSL certificates"""
    
    def __init__(self):
        super().__init__("certificate_search")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://crt.sh"
    
    def requires_api_key(self) -> bool:
        return False
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect SSL certificate information"""
        all_certs = []
        
        # crt.sh
        print("[*] Querying crt.sh for certificates...")
        crtsh_certs = self._query_crtsh(target)
        all_certs.extend(crtsh_certs)
        
        # Censys (if API key available)
        if Config.CENSYS_API_ID and Config.CENSYS_API_SECRET:
            print("[*] Querying Censys for certificates...")
            censys_certs = self._query_censys(target)
            all_certs.extend(censys_certs)
        
        return all_certs
    
    def _query_crtsh(self, domain: str) -> List[Dict[str, Any]]:
        """Query crt.sh for certificates"""
        results = []
        url = "https://crt.sh/"
        
        params = {
            'q': domain,
            'output': 'json'
        }
        
        try:
            response = self.make_request(url, params=params)
            if response and response.json():
                data = response.json()
                
                for cert in data:
                    results.append({
                        'id': cert.get('id', 'N/A'),
                        'logged_at': cert.get('entry_timestamp', 'N/A'),
                        'not_before': cert.get('not_before', 'N/A'),
                        'not_after': cert.get('not_after', 'N/A'),
                        'common_name': cert.get('common_name', 'N/A'),
                        'matching_identities': cert.get('name_value', 'N/A')[:100],
                        'issuer': cert.get('issuer_name', 'N/A')[:80],
                        'source': 'crt.sh'
                    })
        except Exception as e:
            print(f"[!] crt.sh error: {str(e)}")
        
        return results
    
    def _query_censys(self, domain: str) -> List[Dict[str, Any]]:
        """Query Censys for certificates"""
        results = []
        url = "https://search.censys.io/api/v2/certificates/search"
        
        auth = base64.b64encode(
            f"{Config.CENSYS_API_ID}:{Config.CENSYS_API_SECRET}".encode()
        ).decode()
        
        headers = {
            'Authorization': f'Basic {auth}'
        }
        
        params = {
            'q': f'names: {domain}',
            'per_page': 100
        }
        
        try:
            response = self.make_request(url, params=params, headers=headers)
            if response and response.json():
                data = response.json()
                
                for cert in data.get('result', {}).get('hits', []):
                    results.append({
                        'id': cert.get('fingerprint_sha256', 'N/A')[:16],
                        'logged_at': 'N/A',
                        'not_before': cert.get('parsed', {}).get('validity', {}).get('start', 'N/A'),
                        'not_after': cert.get('parsed', {}).get('validity', {}).get('end', 'N/A'),
                        'common_name': cert.get('parsed', {}).get('subject', {}).get('common_name', ['N/A'])[0],
                        'matching_identities': ', '.join(cert.get('names', []))[:100],
                        'issuer': cert.get('parsed', {}).get('issuer', {}).get('common_name', ['N/A'])[0],
                        'source': 'Censys'
                    })
        except Exception as e:
            print(f"[!] Censys error: {str(e)}")
        
        return results
