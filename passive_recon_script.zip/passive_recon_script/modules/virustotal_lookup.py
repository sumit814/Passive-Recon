"""
VirusTotal Lookup Module
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config

class VirusTotalModule(BaseModule):
    
    def __init__(self):
        super().__init__("virustotal_lookup")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://www.virustotal.com/api/v3"
    
    def requires_api_key(self) -> bool:
        return True
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        if not self.check_api_key(Config.VIRUSTOTAL_API_KEY, "VirusTotal"):
            return []
        
        results = []
        url = f"https://www.virustotal.com/api/v3/domains/{target}"
        
        headers = {'x-apikey': Config.VIRUSTOTAL_API_KEY}
        
        try:
            response = self.make_request(url, headers=headers)
            if response and response.json():
                data = response.json().get('data', {})
                attrs = data.get('attributes', {})
                
                results.append({
                    'domain': target,
                    'reputation': attrs.get('reputation', 0),
                    'categories': ', '.join(attrs.get('categories', {}).values())[:100],
                    'last_analysis_stats': str(attrs.get('last_analysis_stats', {})),
                    'popularity_ranks': str(attrs.get('popularity_ranks', {}))[:100],
                    'creation_date': attrs.get('creation_date', 'N/A'),
                    'last_update': attrs.get('last_modification_date', 'N/A'),
                    'source': 'VirusTotal'
                })
        except Exception as e:
            print(f"[!] VirusTotal error: {str(e)}")
        
        return results
