"""
Social Media Enumeration Module
Find social media profiles and handles associated with a domain
"""

import requests
from typing import List, Dict, Any, Optional
import time
from bs4 import BeautifulSoup
from .base_module import BaseModule

class SocialMediaEnumModule(BaseModule):
    """Enumerate social media profiles for target domain"""
    
    def __init__(self):
        super().__init__("social_media_enumeration")
        self.description = "Discover social media profiles and handles"
        
        # Social media platforms to check
        self.platforms = {
            'twitter': {
                'url': 'https://twitter.com/{}',
                'check_url': 'https://twitter.com/{}',
                'icon': '🐦'
            },
            'facebook': {
                'url': 'https://facebook.com/{}',
                'check_url': 'https://facebook.com/{}',
                'icon': '📘'
            },
            'instagram': {
                'url': 'https://instagram.com/{}',
                'check_url': 'https://instagram.com/{}',
                'icon': '📷'
            },
            'linkedin': {
                'url': 'https://linkedin.com/company/{}',
                'check_url': 'https://linkedin.com/company/{}',
                'icon': '💼'
            },
            'github': {
                'url': 'https://github.com/{}',
                'check_url': 'https://api.github.com/users/{}',
                'icon': '🐙'
            },
            'youtube': {
                'url': 'https://youtube.com/@{}',
                'check_url': 'https://youtube.com/@{}',
                'icon': '📺'
            },
            'reddit': {
                'url': 'https://reddit.com/user/{}',
                'check_url': 'https://reddit.com/user/{}',
                'icon': '🤖'
            },
            'pinterest': {
                'url': 'https://pinterest.com/{}',
                'check_url': 'https://pinterest.com/{}',
                'icon': '📌'
            },
            'tiktok': {
                'url': 'https://tiktok.com/@{}',
                'check_url': 'https://tiktok.com/@{}',
                'icon': '🎵'
            },
            'medium': {
                'url': 'https://medium.com/@{}',
                'check_url': 'https://medium.com/@{}',
                'icon': '📝'
            },
            'telegram': {
                'url': 'https://t.me/{}',
                'check_url': 'https://t.me/{}',
                'icon': '✈️'
            },
            'discord': {
                'url': 'https://discord.gg/{}',
                'check_url': 'https://discord.gg/{}',
                'icon': '🎮'
            }
        }
    
    def get_api_endpoint(self) -> Optional[str]:
        return None
    
    def requires_api_key(self) -> bool:
        return False
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """
        Enumerate social media profiles
        
        Args:
            target: Domain name
        
        Returns:
            List of found social media profiles
        """
        results = []
        
        # Generate potential handles from domain
        handles = self._generate_handles(target)
        
        # Method 1: Check common social media platforms
        print(f"[*] Checking social media platforms...")
        social_results = self._check_social_platforms(handles)
        results.extend(social_results)
        
        # Method 2: Search via Hunter.io (emails can reveal social profiles)
        from config import Config
        if Config.HUNTER_API_KEY:
            print(f"[*] Checking Hunter.io for social links...")
            hunter_socials = self._check_hunter_socials(target)
            results.extend(hunter_socials)
        
        # Method 3: Check FullHunt for social media mentions
        if Config.FULLHUNT_API_KEY:
            print(f"[*] Checking FullHunt for social mentions...")
            fullhunt_socials = self._check_fullhunt_socials(target)
            results.extend(fullhunt_socials)
        
        # Method 4: Check website directly for social links
        print(f"[*] Scanning website for social links...")
        website_socials = self._scan_website_socials(target)
        results.extend(website_socials)
        
        # Method 5: Check GitHub organization
        print(f"[*] Checking GitHub organization...")
        github_socials = self._check_github_org(handles)
        results.extend(github_socials)
        
        # Remove duplicates
        results = self._deduplicate_results(results)
        
        return results
    
    def _generate_handles(self, domain: str) -> List[str]:
        """Generate potential social media handles from domain"""
        handles = []
        
        # Remove common TLDs
        base = domain.replace('.com', '').replace('.org', '').replace('.net', '')
        base = base.replace('.io', '').replace('.co', '').replace('.ai', '')
        
        # Add variations
        handles.append(base)  # example
        handles.append(base.replace('-', ''))  # remove hyphens
        handles.append(base.replace('.', ''))  # remove dots
        handles.append(base + 'official')  # exampleofficial
        handles.append(base + 'hq')  # examplehq
        handles.append('official' + base)  # officialexample
        
        # Add company name variations
        parts = base.split('.')
        if len(parts) > 1:
            handles.append(parts[0])
        
        return list(set(handles))
    
    def _check_social_platforms(self, handles: List[str]) -> List[Dict]:
        """Check if handles exist on various social platforms"""
        results = []
        
        for handle in handles[:3]:  # Check first 3 handles to avoid rate limits
            for platform, info in self.platforms.items():
                try:
                    # For GitHub, use API
                    if platform == 'github':
                        url = info['check_url'].format(handle)
                        response = requests.get(url, timeout=5)
                        if response.status_code == 200:
                            data = response.json()
                            results.append({
                                'platform': platform,
                                'handle': handle,
                                'url': info['url'].format(handle),
                                'verified': True,
                                'followers': data.get('followers', 'N/A'),
                                'public_repos': data.get('public_repos', 'N/A'),
                                'icon': info['icon'],
                                'source': 'GitHub API'
                            })
                    else:
                        # For others, check HTTP status
                        url = info['check_url'].format(handle)
                        response = requests.get(
                            url, 
                            timeout=5,
                            allow_redirects=True,
                            headers={'User-Agent': 'Mozilla/5.0'}
                        )
                        
                        # Consider 200 as found (some platforms always return 200)
                        if response.status_code == 200:
                            results.append({
                                'platform': platform,
                                'handle': handle,
                                'url': info['url'].format(handle),
                                'verified': True,
                                'icon': info['icon'],
                                'source': 'Direct check'
                            })
                    
                    time.sleep(0.5)  # Rate limiting
                    
                except Exception as e:
                    continue
        
        return results
    
    def _check_hunter_socials(self, domain: str) -> List[Dict]:
        """Check Hunter.io for social media links"""
        from config import Config
        results = []
        
        try:
            url = f"https://api.hunter.io/v2/domain-search"
            params = {
                'domain': domain,
                'api_key': Config.HUNTER_API_KEY
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                meta = data.get('data', {}).get('meta', {})
                
                # Hunter.io provides social links
                social_links = {
                    'twitter': meta.get('twitter'),
                    'facebook': meta.get('facebook'),
                    'linkedin': meta.get('linkedin')
                }
                
                for platform, link in social_links.items():
                    if link:
                        results.append({
                            'platform': platform,
                            'url': link,
                            'verified': True,
                            'icon': self.platforms.get(platform, {}).get('icon', '🔗'),
                            'source': 'Hunter.io'
                        })
        
        except Exception as e:
            pass
        
        return results
    
    def _check_fullhunt_socials(self, domain: str) -> List[Dict]:
        """Check FullHunt for social media mentions"""
        from config import Config
        results = []
        
        try:
            url = f"https://fullhunt.io/api/v1/domain/{domain}/details"
            headers = {'X-API-KEY': Config.FULLHUNT_API_KEY}
            
            response = requests.get(url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                # FullHunt might have social links in metadata
                metadata = data.get('metadata', {})
                
                for key, value in metadata.items():
                    if any(platform in key.lower() for platform in self.platforms.keys()):
                        if isinstance(value, str) and value.startswith('http'):
                            results.append({
                                'platform': key,
                                'url': value,
                                'verified': True,
                                'icon': '🔗',
                                'source': 'FullHunt'
                            })
        
        except Exception as e:
            pass
        
        return results
    
    def _scan_website_socials(self, domain: str) -> List[Dict]:
        """Scan the actual website for social media links"""
        results = []
        
        try:
            # Try both http and https
            for protocol in ['https', 'http']:
                try:
                    url = f"{protocol}://{domain}"
                    response = requests.get(
                        url, 
                        timeout=10,
                        headers={'User-Agent': 'Mozilla/5.0'},
                        verify=False
                    )
                    
                    if response.status_code == 200:
                        soup = BeautifulSoup(response.text, 'html.parser')
                        
                        # Find all links
                        for link in soup.find_all('a', href=True):
                            href = link['href']
                            
                            # Check if it's a social media link
                            for platform, info in self.platforms.items():
                                platform_domains = [
                                    'twitter.com', 'facebook.com', 'instagram.com',
                                    'linkedin.com', 'github.com', 'youtube.com',
                                    'reddit.com', 'pinterest.com', 'tiktok.com',
                                    'medium.com', 't.me', 'discord.gg'
                                ]
                                
                                if any(pd in href for pd in platform_domains):
                                    # Extract handle from URL
                                    handle = href.split('/')[-1] if '/' in href else 'N/A'
                                    
                                    results.append({
                                        'platform': platform,
                                        'url': href,
                                        'handle': handle,
                                        'verified': True,
                                        'icon': info.get('icon', '🔗'),
                                        'source': f'Website ({domain})'
                                    })
                        
                        break  # Success, don't try http
                    
                except Exception as e:
                    continue
        
        except Exception as e:
            pass
        
        return results
    
    def _check_github_org(self, handles: List[str]) -> List[Dict]:
        """Check for GitHub organization"""
        from config import Config
        results = []
        
        for handle in handles[:3]:
            try:
                # Check organization
                url = f"https://api.github.com/orgs/{handle}"
                headers = {}
                if Config.GITHUB_TOKEN:
                    headers['Authorization'] = f'token {Config.GITHUB_TOKEN}'
                
                response = requests.get(url, headers=headers, timeout=5)
                
                if response.status_code == 200:
                    data = response.json()
                    results.append({
                        'platform': 'github',
                        'type': 'organization',
                        'handle': handle,
                        'url': f"https://github.com/{handle}",
                        'verified': True,
                        'followers': data.get('followers', 'N/A'),
                        'public_repos': data.get('public_repos', 'N/A'),
                        'icon': '🐙',
                        'source': 'GitHub API (org)'
                    })
            
            except Exception as e:
                continue
        
        return results
    
    def _deduplicate_results(self, results: List[Dict]) -> List[Dict]:
        """Remove duplicate social media profiles"""
        seen = set()
        unique_results = []
        
        for result in results:
            # Create unique key based on platform and URL
            key = (result.get('platform'), result.get('url'))
            
            if key not in seen:
                seen.add(key)
                unique_results.append(result)
        
        return unique_results
