"""
Vulners Vulnerability Lookup Module
Uses: Vulners API for vulnerability intelligence
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config

class VulnersLookupModule(BaseModule):
    """Search Vulners for vulnerabilities"""
    
    def __init__(self):
        super().__init__("vulners_lookup")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://vulners.com/api/v3"
    
    def requires_api_key(self) -> bool:
        return True
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect vulnerability data from Vulners"""
        if not self.check_api_key(Config.VULNERS_API_KEY, "Vulners"):
            return []
        
        results = []
        
        # Search for target in vulnerabilities
        print("[*] Querying Vulners for vulnerabilities...")
        vuln_results = self._search_vulnerabilities(target)
        results.extend(vuln_results)
        
        return results
    
    def _search_vulnerabilities(self, target: str) -> List[Dict[str, Any]]:
        """Search for vulnerabilities related to target"""
        results = []
        url = "https://vulners.com/api/v3/search/lucene/"
        
        params = {
            'apiKey': Config.VULNERS_API_KEY,
            'query': target,
            'size': 50
        }
        
        try:
            response = self.make_request(url, params=params)
            if response and response.json():
                data = response.json()
                
                if data.get('result') == 'OK':
                    for item in data.get('data', {}).get('search', []):
                        results.append({
                            'id': item.get('_id', 'N/A'),
                            'title': item.get('_source', {}).get('title', 'N/A')[:100],
                            'description': item.get('_source', {}).get('description', 'N/A')[:200],
                            'type': item.get('_source', {}).get('type', 'N/A'),
                            'cvss_score': item.get('_source', {}).get('cvss', {}).get('score', 'N/A'),
                            'published': item.get('_source', {}).get('published', 'N/A'),
                            'modified': item.get('_source', {}).get('modified', 'N/A'),
                            'href': item.get('_source', {}).get('href', 'N/A'),
                            'source': 'Vulners'
                        })
        except Exception as e:
            print(f"[!] Vulners error: {str(e)}")
        
        return results
