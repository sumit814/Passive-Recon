"""
ZoomEye Search Module
Uses: ZoomEye API for cyberspace search
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config

class ZoomEyeSearchModule(BaseModule):
    """Search ZoomEye for internet-exposed assets"""
    
    def __init__(self):
        super().__init__("zoomeye_search")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://api.zoomeye.org"
    
    def requires_api_key(self) -> bool:
        return True
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect data from ZoomEye"""
        if not self.check_api_key(Config.ZOOMEYE_API_KEY, "ZoomEye"):
            return []
        
        results = []
        
        # Search for domain/IP
        print("[*] Querying ZoomEye...")
        search_results = self._search_host(target)
        results.extend(search_results)
        
        return results
    
    def _search_host(self, target: str) -> List[Dict[str, Any]]:
        """Search ZoomEye for target"""
        results = []
        url = "https://api.zoomeye.org/host/search"
        
        headers = {
            'API-KEY': Config.ZOOMEYE_API_KEY
        }
        
        params = {
            'query': f'hostname:{target}',
            'page': 1
        }
        
        try:
            response = self.make_request(url, params=params, headers=headers)
            if response and response.json():
                data = response.json()
                
                for match in data.get('matches', []):
                    results.append({
                        'ip': match.get('ip', 'N/A'),
                        'port': match.get('portinfo', {}).get('port', 'N/A'),
                        'service': match.get('portinfo', {}).get('service', 'N/A'),
                        'app': match.get('portinfo', {}).get('app', 'N/A'),
                        'version': match.get('portinfo', {}).get('version', 'N/A'),
                        'os': match.get('portinfo', {}).get('os', 'N/A'),
                        'country': match.get('geoinfo', {}).get('country', {}).get('names', {}).get('en', 'N/A'),
                        'city': match.get('geoinfo', {}).get('city', {}).get('names', {}).get('en', 'N/A'),
                        'organization': match.get('geoinfo', {}).get('organization', 'N/A'),
                        'timestamp': match.get('timestamp', 'N/A'),
                        'source': 'ZoomEye'
                    })
        except Exception as e:
            print(f"[!] ZoomEye error: {str(e)}")
        
        return results
