"""
BuiltWith Technology Lookup Module
Uses: BuiltWith API for technology detection
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config

class BuiltWithLookupModule(BaseModule):
    """Detect technologies used by target website"""
    
    def __init__(self):
        super().__init__("builtwith_lookup")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://api.builtwith.com"
    
    def requires_api_key(self) -> bool:
        return True
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect technology stack from BuiltWith"""
        if not hasattr(Config, 'BUILTWITH_API_KEY') or not Config.BUILTWITH_API_KEY:
            print("[!] BuiltWith API key not configured (optional)")
            return []
        
        results = []
        
        print("[*] Querying BuiltWith...")
        tech_data = self._get_technologies(target)
        results.extend(tech_data)
        
        return results
    
    def _get_technologies(self, target: str) -> List[Dict[str, Any]]:
        """Get technology stack"""
        results = []
        url = "https://api.builtwith.com/v20/api.json"
        
        params = {
            'KEY': Config.BUILTWITH_API_KEY if hasattr(Config, 'BUILTWITH_API_KEY') else '',
            'LOOKUP': target
        }
        
        try:
            response = self.make_request(url, params=params)
            if response and response.json():
                data = response.json()
                
                if 'Results' in data and len(data['Results']) > 0:
                    result = data['Results'][0]
                    
                    # Process technology groups
                    for tech_group in result.get('Result', {}).get('Paths', []):
                        for tech in tech_group.get('Technologies', []):
                            results.append({
                                'technology': tech.get('Name', 'N/A'),
                                'category': tech_group.get('Name', 'N/A'),
                                'description': tech.get('Description', 'N/A')[:200],
                                'first_detected': tech.get('FirstDetected', 'N/A'),
                                'last_detected': tech.get('LastDetected', 'N/A'),
                                'source': 'BuiltWith'
                            })
        except Exception as e:
            print(f"[!] BuiltWith error: {str(e)}")
        
        return results
