"""
PublicWWW Search Module
Uses: PublicWWW API for source code search
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config

class PublicWWWSearchModule(BaseModule):
    """Search PublicWWW for source code"""
    
    def __init__(self):
        super().__init__("publicwww_search")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://publicwww.com/api"
    
    def requires_api_key(self) -> bool:
        return True
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect data from PublicWWW"""
        if not self.check_api_key(Config.PUBLICWWW_API_KEY, "PublicWWW"):
            return []
        
        results = []
        
        # Search for domain in source code
        print("[*] Querying PublicWWW...")
        search_results = self._search_source(target)
        results.extend(search_results)
        
        return results
    
    def _search_source(self, target: str) -> List[Dict[str, Any]]:
        """Search for target in website source code"""
        results = []
        url = "https://publicwww.com/api/search"
        
        params = {
            'key': Config.PUBLICWWW_API_KEY,
            'q': f'"{target}"',
            'format': 'json',
            'limit': 50
        }
        
        try:
            response = self.make_request(url, params=params)
            if response and response.json():
                data = response.json()
                
                for result in data.get('results', []):
                    results.append({
                        'url': result.get('url', 'N/A'),
                        'domain': result.get('domain', 'N/A'),
                        'title': result.get('title', 'N/A')[:100],
                        'snippet': result.get('snippet', 'N/A')[:200],
                        'rank': result.get('rank', 'N/A'),
                        'last_seen': result.get('last_seen', 'N/A'),
                        'source': 'PublicWWW'
                    })
        except Exception as e:
            print(f"[!] PublicWWW error: {str(e)}")
        
        return results
