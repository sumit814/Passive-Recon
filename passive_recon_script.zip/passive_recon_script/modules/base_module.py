"""
Base Module - Parent class for all reconnaissance modules
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
import requests
from pathlib import Path
from utils import OutputHandler, DataFormatter
from config import Config
import time

class BaseModule(ABC):
    """Base class for all reconnaissance modules"""
    
    def __init__(self, module_name: str):
        """
        Initialize base module
        
        Args:
            module_name: Unique identifier for the module
        """
        self.module_name = module_name
        self.output_handler = OutputHandler(module_name)
        self.formatter = DataFormatter()
        self.results: List[Dict[str, Any]] = []
        
        # HTTP session with retry logic
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': Config.USER_AGENT
        })
    
    @abstractmethod
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """
        Collect data from the source
        
        Args:
            target: Target domain/IP/identifier
            **kwargs: Additional parameters
        
        Returns:
            List of dictionaries containing collected data
        """
        pass
    
    @abstractmethod
    def get_api_endpoint(self) -> Optional[str]:
        """Return the API endpoint URL or None if no API is used"""
        pass
    
    @abstractmethod
    def requires_api_key(self) -> bool:
        """Return True if module requires API key"""
        pass
    
    def run(self, target: str, **kwargs) -> Dict[str, Path]:
        """
        Main execution method
        
        Args:
            target: Target to investigate
            **kwargs: Additional parameters
        
        Returns:
            Dictionary with paths to output files
        """
        print(f"[*] Running {self.module_name} for target: {target}")
        
        try:
            # Collect raw data
            raw_data = self.collect(target, **kwargs)
            
            if not raw_data:
                print(f"[!] No data collected by {self.module_name}")
                self.results = []
            else:
                # Process data
                self.results = self.process_data(raw_data)
                print(f"[+] {self.module_name} found {len(self.results)} results")
            
            # Save outputs
            output_paths = self.save_results(target)
            
            return output_paths
            
        except Exception as e:
            print(f"[!] Error in {self.module_name}: {str(e)}")
            return {}
    
    def process_data(self, raw_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Process and clean raw data
        
        Args:
            raw_data: Raw collected data
        
        Returns:
            Processed data
        """
        # Deduplicate
        processed = self.formatter.deduplicate(raw_data)
        
        # Apply custom filtering if implemented
        if hasattr(self, 'filter_data'):
            processed = self.filter_data(processed)
        
        return processed
    
    def save_results(self, target: str) -> Dict[str, Path]:
        """
        Save results to JSON and HTML
        
        Args:
            target: Target identifier
        
        Returns:
            Dictionary with paths to saved files
        """
        return self.output_handler.save(
            data=self.results,
            target=target,
            title=self.get_title()
        )
    
    def get_title(self) -> str:
        """Get human-readable title for the module"""
        return self.module_name.replace('_', ' ').title()
    
    def make_request(
        self, 
        url: str, 
        method: str = 'GET',
        params: Dict = None,
        headers: Dict = None,
        data: Dict = None,
        json_data: Dict = None,
        timeout: int = None
    ) -> Optional[requests.Response]:
        """
        Make HTTP request with error handling and retries
        
        Args:
            url: URL to request
            method: HTTP method
            params: Query parameters
            headers: Additional headers
            data: Form data
            json_data: JSON data
            timeout: Request timeout
        
        Returns:
            Response object or None on failure
        """
        if timeout is None:
            timeout = Config.TIMEOUT
        
        if headers:
            request_headers = {**self.session.headers, **headers}
        else:
            request_headers = self.session.headers
        
        # Reduce retries to 2 for faster execution
        max_retries = min(Config.MAX_RETRIES, 2)
        
        for attempt in range(max_retries):
            try:
                response = self.session.request(
                    method=method,
                    url=url,
                    params=params,
                    headers=request_headers,
                    data=data,
                    json=json_data,
                    timeout=timeout
                )
                
                if response.status_code == 200:
                    return response
                elif response.status_code == 429:
                    # Rate limited - don't retry extensively
                    if attempt < max_retries - 1:
                        wait_time = 5  # Reduced from 30
                        print(f"[!] Rate limited, waiting {wait_time}s (attempt {attempt + 1}/{max_retries})")
                        time.sleep(wait_time)
                        continue
                    else:
                        print(f"[!] Rate limit exceeded after {max_retries} attempts")
                        return None
                elif response.status_code == 401 or response.status_code == 403:
                    # Authentication error - don't retry
                    print(f"[!] Authentication failed (status {response.status_code}) - check API key")
                    return None
                elif response.status_code >= 500:
                    # Server error, retry
                    if attempt < max_retries - 1:
                        time.sleep(2 ** attempt)
                        continue
                else:
                    print(f"[!] Request failed with status {response.status_code}")
                    return None
                    
            except requests.exceptions.Timeout:
                print(f"[!] Request timeout (attempt {attempt + 1}/{max_retries})")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
                    continue
                    
            except requests.exceptions.RequestException as e:
                print(f"[!] Request error: {str(e)}")
                return None
        
        return None
    
    def check_api_key(self, api_key: str, api_name: str = None) -> bool:
        """
        Check if API key is configured
        
        Args:
            api_key: API key to check
            api_name: Name of the API
        
        Returns:
            True if API key is set
        """
        if not api_key:
            if api_name:
                print(f"[!] {api_name} API key not configured")
            else:
                print(f"[!] API key not configured for {self.module_name}")
            return False
        return True
