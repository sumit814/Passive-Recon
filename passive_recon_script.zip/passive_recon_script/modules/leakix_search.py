"""
LeakIX Search Module
Uses: LeakIX API for leak detection and services
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config

class LeakIXSearchModule(BaseModule):
    """Search LeakIX for leaks and exposed services"""
    
    def __init__(self):
        super().__init__("leakix_search")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://leakix.net/api"
    
    def requires_api_key(self) -> bool:
        return True
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect data from LeakIX"""
        if not self.check_api_key(Config.LEAKIX_API_KEY, "LeakIX"):
            return []
        
        results = []
        
        # Search for domain
        print("[*] Querying LeakIX for services...")
        service_results = self._search_services(target)
        results.extend(service_results)
        
        # Search for leaks
        print("[*] Querying LeakIX for leaks...")
        leak_results = self._search_leaks(target)
        results.extend(leak_results)
        
        return results
    
    def _search_services(self, target: str) -> List[Dict[str, Any]]:
        """Search for services"""
        results = []
        url = f"https://leakix.net/api/subdomains/{target}"
        
        headers = {
            'api-key': Config.LEAKIX_API_KEY
        }
        
        try:
            response = self.make_request(url, headers=headers)
            if response and response.json():
                data = response.json()
                
                for item in data:
                    results.append({
                        'type': 'service',
                        'subdomain': item.get('subdomain', 'N/A'),
                        'ip': item.get('ip', 'N/A'),
                        'port': item.get('port', 'N/A'),
                        'protocol': item.get('protocol', 'N/A'),
                        'service': item.get('service_name', 'N/A'),
                        'first_seen': item.get('time', 'N/A'),
                        'source': 'LeakIX Services'
                    })
        except Exception as e:
            print(f"[!] LeakIX services error: {str(e)}")
        
        return results
    
    def _search_leaks(self, target: str) -> List[Dict[str, Any]]:
        """Search for data leaks"""
        results = []
        url = f"https://leakix.net/api/search"
        
        headers = {
            'api-key': Config.LEAKIX_API_KEY
        }
        
        params = {
            'q': f'+host:{target}'
        }
        
        try:
            response = self.make_request(url, params=params, headers=headers)
            if response and response.json():
                data = response.json()
                
                for leak in data:
                    results.append({
                        'type': 'leak',
                        'subdomain': leak.get('host', 'N/A'),
                        'ip': leak.get('ip', 'N/A'),
                        'port': leak.get('port', 'N/A'),
                        'protocol': leak.get('protocol', 'N/A'),
                        'service': leak.get('leak_type', 'N/A'),
                        'first_seen': leak.get('time', 'N/A'),
                        'source': 'LeakIX Leaks'
                    })
        except Exception as e:
            print(f"[!] LeakIX leaks error: {str(e)}")
        
        return results
