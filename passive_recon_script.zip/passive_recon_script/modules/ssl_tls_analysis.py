"""
SSL/TLS Certificate Analysis Module
Enhanced certificate validation and security analysis
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config
import ssl
import socket
from datetime import datetime, timedelta
import OpenSSL
from urllib.parse import urlparse

class SSLTLSAnalysisModule(BaseModule):
    """Comprehensive SSL/TLS certificate and security analysis"""
    
    def __init__(self):
        super().__init__("ssl_tls_analysis")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "Direct TLS connection + crt.sh"
    
    def requires_api_key(self) -> bool:
        return False
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect SSL/TLS certificate and configuration details"""
        results = []
        
        # Clean target to domain only
        if target.startswith('http://') or target.startswith('https://'):
            parsed = urlparse(target)
            domain = parsed.netloc or parsed.path
        else:
            domain = target.replace('www.', '')
        
        print(f"[*] Analyzing SSL/TLS configuration for {domain}...")
        
        # Get certificate details
        cert_data = self._get_certificate_details(domain)
        
        if not cert_data:
            print("[!] Could not retrieve SSL/TLS certificate")
            results.append({
                'domain': domain,
                'status': 'No SSL/TLS certificate found',
                'certificate': 'Not available or site not using HTTPS',
                'security_analysis': 'N/A',
                'recommendations': ['Enable HTTPS/SSL for this domain'],
                'alternative_tools': self._get_alternative_tools()
            })
            return results
        
        # Analyze certificate
        analysis = self._analyze_certificate(cert_data, domain)
        
        # Get cipher suite and TLS version info
        cipher_info = self._check_cipher_suites(domain)
        
        # Combine all data
        result = {
            'domain': domain,
            'certificate_details': cert_data,
            'security_analysis': analysis,
            'cipher_info': cipher_info,
            'overall_status': analysis.get('overall_status', 'Unknown'),
            'issues_found': analysis.get('issues', []),
            'recommendations': analysis.get('recommendations', []),
            'alternative_tools': self._get_alternative_tools()
        }
        
        results.append(result)
        
        return results
    
    def _get_certificate_details(self, domain: str, port: int = 443) -> Dict[str, Any]:
        """Retrieve SSL certificate details"""
        try:
            context = ssl.create_default_context()
            
            with socket.create_connection((domain, port), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=domain) as ssock:
                    cert_bin = ssock.getpeercert(binary_form=True)
                    cert_dict = ssock.getpeercert()
                    
                    # Parse with PyOpenSSL for more details
                    x509 = OpenSSL.crypto.load_certificate(
                        OpenSSL.crypto.FILETYPE_ASN1, cert_bin
                    )
                    
                    # Extract key information
                    cert_data = {
                        'subject': dict(x[0] for x in cert_dict.get('subject', [])),
                        'issuer': dict(x[0] for x in cert_dict.get('issuer', [])),
                        'version': x509.get_version() + 1,
                        'serial_number': hex(x509.get_serial_number()),
                        'not_before': cert_dict.get('notBefore', ''),
                        'not_after': cert_dict.get('notAfter', ''),
                        'signature_algorithm': x509.get_signature_algorithm().decode(),
                        'subject_alt_names': self._extract_san(cert_dict),
                        'public_key_bits': x509.get_pubkey().bits(),
                        'public_key_type': self._get_key_type(x509.get_pubkey().type()),
                        'extensions': self._extract_extensions(x509)
                    }
                    
                    return cert_data
                    
        except ssl.SSLError as e:
            print(f"[!] SSL error: {str(e)}")
        except socket.timeout:
            print(f"[!] Connection timeout for {domain}")
        except Exception as e:
            print(f"[!] Error retrieving certificate: {str(e)}")
        
        return {}
    
    def _extract_san(self, cert_dict: Dict) -> List[str]:
        """Extract Subject Alternative Names"""
        san_list = []
        for san_type, san_value in cert_dict.get('subjectAltName', []):
            if san_type == 'DNS':
                san_list.append(san_value)
        return san_list
    
    def _get_key_type(self, key_type: int) -> str:
        """Convert key type to readable format"""
        types = {
            6: 'RSA',
            116: 'EC',
            408: 'DSA'
        }
        return types.get(key_type, f'Unknown ({key_type})')
    
    def _extract_extensions(self, x509) -> Dict[str, Any]:
        """Extract certificate extensions"""
        extensions = {}
        
        try:
            for i in range(x509.get_extension_count()):
                ext = x509.get_extension(i)
                ext_name = ext.get_short_name().decode()
                extensions[ext_name] = {
                    'critical': ext.get_critical(),
                    'value': str(ext)
                }
        except:
            pass
        
        return extensions
    
    def _analyze_certificate(self, cert_data: Dict[str, Any], domain: str) -> Dict[str, Any]:
        """Analyze certificate for security issues"""
        issues = []
        recommendations = []
        warnings = []
        
        # Parse dates
        try:
            not_before = datetime.strptime(cert_data['not_before'], '%b %d %H:%M:%S %Y %Z')
            not_after = datetime.strptime(cert_data['not_after'], '%b %d %H:%M:%S %Y %Z')
            now = datetime.now()
            
            days_until_expiry = (not_after - now).days
            
            # Check expiration
            if now > not_after:
                issues.append('CRITICAL: Certificate has expired!')
                recommendations.append('Renew certificate immediately')
            elif days_until_expiry < 30:
                warnings.append(f'Certificate expires in {days_until_expiry} days')
                recommendations.append('Plan certificate renewal soon')
            elif days_until_expiry < 90:
                warnings.append(f'Certificate expires in {days_until_expiry} days')
            
            cert_data['days_until_expiry'] = days_until_expiry
            cert_data['expiry_status'] = 'Expired' if now > not_after else 'Valid'
            
        except Exception as e:
            print(f"[!] Date parsing error: {str(e)}")
            cert_data['days_until_expiry'] = 'Unknown'
            cert_data['expiry_status'] = 'Unknown'
        
        # Check key strength
        key_bits = cert_data.get('public_key_bits', 0)
        key_type = cert_data.get('public_key_type', '')
        
        if key_type == 'RSA':
            if key_bits < 2048:
                issues.append(f'Weak RSA key: {key_bits} bits (should be >= 2048)')
                recommendations.append('Use at least 2048-bit RSA keys')
            elif key_bits == 2048:
                warnings.append('RSA 2048-bit key (consider upgrading to 4096-bit)')
        elif key_type == 'EC':
            if key_bits < 256:
                issues.append(f'Weak EC key: {key_bits} bits')
        
        # Check signature algorithm
        sig_algo = cert_data.get('signature_algorithm', '').lower()
        if 'sha1' in sig_algo:
            issues.append('Using deprecated SHA-1 signature algorithm')
            recommendations.append('Upgrade to SHA-256 or better')
        elif 'md5' in sig_algo:
            issues.append('CRITICAL: Using insecure MD5 signature algorithm')
            recommendations.append('Immediately upgrade to SHA-256 or better')
        
        # Check issuer
        issuer = cert_data.get('issuer', {})
        issuer_cn = issuer.get('commonName', 'Unknown')
        
        if issuer_cn == cert_data.get('subject', {}).get('commonName'):
            warnings.append('Self-signed certificate detected')
            recommendations.append('Consider using a trusted CA-signed certificate')
        
        # Check SAN
        san_list = cert_data.get('subject_alt_names', [])
        if not san_list or domain not in san_list:
            warnings.append(f'Domain {domain} not found in Subject Alternative Names')
        
        # Determine overall status
        if issues:
            overall_status = 'CRITICAL - SSL/TLS misconfigurations identified'
        elif warnings:
            overall_status = 'WARNING - Minor issues detected'
        else:
            overall_status = 'SECURE - No SSL/TLS misconfiguration identified'
        
        return {
            'overall_status': overall_status,
            'issues': issues,
            'warnings': warnings,
            'recommendations': recommendations if recommendations else ['No immediate actions required'],
            'issuer': issuer_cn,
            'validity_period': f"{cert_data.get('not_before', 'Unknown')} to {cert_data.get('not_after', 'Unknown')}",
            'expiry_status': cert_data.get('expiry_status', 'Unknown'),
            'days_until_expiry': cert_data.get('days_until_expiry', 'Unknown')
        }
    
    def _check_cipher_suites(self, domain: str, port: int = 443) -> Dict[str, Any]:
        """Check supported TLS versions and cipher suites"""
        cipher_info = {
            'supported_protocols': [],
            'cipher_suite': 'Unknown',
            'weak_ciphers': [],
            'protocol_issues': []
        }
        
        # Test TLS versions
        protocols_to_test = [
            ('TLS 1.3', ssl.PROTOCOL_TLS),
            ('TLS 1.2', ssl.PROTOCOL_TLSv1_2),
            ('TLS 1.1', ssl.PROTOCOL_TLSv1_1),
            ('TLS 1.0', ssl.PROTOCOL_TLSv1),
        ]
        
        for protocol_name, protocol in protocols_to_test:
            try:
                context = ssl.SSLContext(protocol)
                with socket.create_connection((domain, port), timeout=5) as sock:
                    with context.wrap_socket(sock, server_hostname=domain) as ssock:
                        cipher_info['supported_protocols'].append(protocol_name)
                        if protocol_name == 'TLS 1.3':
                            cipher_info['cipher_suite'] = ssock.cipher()[0]
            except:
                pass
        
        # Check for weak protocols
        if 'TLS 1.0' in cipher_info['supported_protocols']:
            cipher_info['protocol_issues'].append('TLS 1.0 is deprecated and should be disabled')
        if 'TLS 1.1' in cipher_info['supported_protocols']:
            cipher_info['protocol_issues'].append('TLS 1.1 is deprecated and should be disabled')
        
        if not cipher_info['protocol_issues']:
            cipher_info['protocol_issues'].append('TLS configuration appears secure')
        
        return cipher_info
    
    def _get_alternative_tools(self) -> Dict[str, List[str]]:
        """List alternative tools for SSL/TLS analysis"""
        return {
            'primary_tool': 'Python SSL/OpenSSL',
            'alternatives': [
                'SSL Labs (Qualys) - https://www.ssllabs.com/ssltest/',
                'testssl.sh - https://testssl.sh/',
                'SSLyze - https://github.com/nabla-c0d3/sslyze',
                'OpenSSL CLI - openssl s_client -connect',
                'Mozilla Observatory - https://observatory.mozilla.org/',
                'ImmuniWeb SSL Test - https://www.immuniweb.com/ssl/',
                'DigiCert SSL Checker - https://www.digicert.com/help/',
                'Censys - https://censys.io/'
            ]
        }
