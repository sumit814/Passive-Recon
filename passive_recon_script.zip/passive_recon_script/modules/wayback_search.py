"""
Wayback Machine Search Module
Uses: Internet Archive Wayback Machine (No API key needed)
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
import json

class WaybackSearchModule(BaseModule):
    """Search Wayback Machine for historical snapshots"""
    
    def __init__(self):
        super().__init__("wayback_search")
    
    def get_api_endpoint(self) -> Optional[str]:
        return "https://web.archive.org"
    
    def requires_api_key(self) -> bool:
        return False
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """Collect historical snapshots from Wayback Machine"""
        results = []
        
        print("[*] Querying Wayback Machine...")
        snapshots = self._get_snapshots(target)
        results.extend(snapshots)
        
        return results
    
    def _get_snapshots(self, target: str) -> List[Dict[str, Any]]:
        """Get archived snapshots"""
        results = []
        url = f"https://web.archive.org/cdx/search/cdx"
        
        params = {
            'url': target,
            'output': 'json',
            'fl': 'timestamp,original,statuscode,mimetype',
            'limit': 100
        }
        
        try:
            response = self.make_request(url, params=params, timeout=60)
            if response and response.text:
                data = json.loads(response.text)
                
                # Skip header
                for entry in data[1:]:
                    if len(entry) >= 4:
                        timestamp, original, statuscode, mimetype = entry[:4]
                        
                        # Format timestamp
                        year = timestamp[:4]
                        month = timestamp[4:6]
                        day = timestamp[6:8]
                        time = timestamp[8:14]
                        
                        results.append({
                            'url': original,
                            'timestamp': f"{year}-{month}-{day} {time[:2]}:{time[2:4]}:{time[4:6]}",
                            'status_code': statuscode,
                            'mime_type': mimetype,
                            'archive_url': f"https://web.archive.org/web/{timestamp}/{original}",
                            'source': 'Wayback Machine'
                        })
        except Exception as e:
            print(f"[!] Wayback Machine error: {str(e)}")
        
        return results
