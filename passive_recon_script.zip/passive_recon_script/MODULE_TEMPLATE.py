"""
Module Template - Copy this to create new reconnaissance modules

INSTRUCTIONS:
1. Copy this file to modules/your_module_name.py
2. Replace all TODO comments with your implementation
3. Update the class name and module_name
4. Add API configuration to config.py if needed
5. Register in modules/__init__.py
6. Add to MODULES dict in main.py
"""

from typing import List, Dict, Any, Optional
from .base_module import BaseModule
from config import Config

class YourModule(BaseModule):  # TODO: Rename class
    """
    TODO: Add module description
    
    Sources:
    - TODO: List data sources (e.g., "Example API", "Public Database")
    
    Requirements:
    - TODO: List requirements (e.g., "API Key required", "No authentication needed")
    
    Output Schema:
    - TODO: Document output fields
      {
          'field1': 'Description of field1',
          'field2': 'Description of field2',
          'source': 'Source name'
      }
    """
    
    def __init__(self):
        # TODO: Change module_name to your unique identifier (lowercase, underscore-separated)
        super().__init__("your_module_name")
    
    def get_api_endpoint(self) -> Optional[str]:
        """
        Return the primary API endpoint URL
        
        Returns:
            API endpoint URL or None if no API is used
        """
        # TODO: Return your API endpoint
        return "https://api.example.com"
    
    def requires_api_key(self) -> bool:
        """
        Indicate if this module requires an API key
        
        Returns:
            True if API key is required, False otherwise
        """
        # TODO: Set to True if API key is required
        return True
    
    def collect(self, target: str, **kwargs) -> List[Dict[str, Any]]:
        """
        Collect reconnaissance data from source(s)
        
        Args:
            target: Target domain/IP/identifier
            **kwargs: Additional parameters (optional)
        
        Returns:
            List of dictionaries containing collected data
        """
        # TODO: Implement your data collection logic
        
        # Check for required API key (if needed)
        # if not self.check_api_key(Config.YOUR_API_KEY, "YourService"):
        #     return []
        
        results = []
        
        # Example: Single API endpoint
        # results.extend(self._query_single_source(target))
        
        # Example: Multiple sources
        # if Config.SOURCE1_API_KEY:
        #     results.extend(self._query_source1(target))
        # if Config.SOURCE2_API_KEY:
        #     results.extend(self._query_source2(target))
        
        # TODO: Replace with your implementation
        url = "https://api.example.com/search"
        
        headers = {
            'Authorization': f'Bearer {Config.YOUR_API_KEY}',  # TODO: Update
            'Accept': 'application/json'
        }
        
        params = {
            'query': target,
            'limit': 100
        }
        
        try:
            print(f"[*] Querying {self.get_api_endpoint()}...")
            
            response = self.make_request(
                url=url,
                method='GET',  # or 'POST'
                params=params,
                headers=headers,
                timeout=30
            )
            
            if response and response.json():
                data = response.json()
                
                # TODO: Parse response and extract relevant data
                for item in data.get('results', []):
                    results.append({
                        'field1': item.get('key1', 'N/A'),
                        'field2': item.get('key2', 'N/A'),
                        'field3': item.get('key3', 'N/A'),
                        'source': 'YourSource'  # TODO: Update source name
                    })
                    
                print(f"[+] Found {len(results)} results")
            else:
                print("[!] No data received or invalid response")
                
        except Exception as e:
            print(f"[!] Error querying {self.get_api_endpoint()}: {str(e)}")
        
        return results
    
    # Optional: Add helper methods for different sources
    def _query_source1(self, target: str) -> List[Dict[str, Any]]:
        """
        Query first data source
        
        Args:
            target: Target identifier
        
        Returns:
            List of results from source1
        """
        # TODO: Implement source1 query
        results = []
        return results
    
    def _query_source2(self, target: str) -> List[Dict[str, Any]]:
        """
        Query second data source
        
        Args:
            target: Target identifier
        
        Returns:
            List of results from source2
        """
        # TODO: Implement source2 query
        results = []
        return results
    
    # Optional: Add custom data filtering
    def filter_data(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Apply custom filtering to collected data
        
        Args:
            data: Raw collected data
        
        Returns:
            Filtered data
        """
        # TODO: Implement custom filtering logic if needed
        
        # Example: Filter out entries with specific pattern
        # filtered = [item for item in data if 'unwanted' not in item.get('field1', '')]
        
        # Example: Use built-in formatter
        # filtered = self.formatter.filter_false_positives(data, "subdomain")
        
        # If no custom filtering needed, just return data
        return data
    
    # Optional: Override title if needed
    def get_title(self) -> str:
        """
        Get human-readable title for reports
        
        Returns:
            Module title
        """
        # TODO: Customize title if default is not suitable
        # Default converts "your_module_name" to "Your Module Name"
        return "Your Custom Title"  # or use: super().get_title()


# ============================================
# CONFIGURATION CHECKLIST
# ============================================
"""
After creating your module:

1. ADD API KEY TO config.py:
   ```python
   YOUR_API_KEY = os.getenv("YOUR_API_KEY", "")
   ```

2. ADD TO .env.example:
   ```
   YOUR_API_KEY=your_key_here
   ```

3. REGISTER IN modules/__init__.py:
   ```python
   from .your_module_name import YourModule
   __all__ = [..., 'YourModule']
   ```

4. ADD TO main.py MODULES DICT:
   ```python
   MODULES = {
       'yourmodule': YourModule,
       ...
   }
   ```

5. ADD TO main.py MODULE INFO:
   ```python
   modules_info = [
       ("yourmodule", "Your Module", "Description", "Yes/No"),
       ...
   ]
   ```

6. TEST YOUR MODULE:
   ```bash
   python main.py run example.com -m yourmodule
   ```

7. CHECK OUTPUT:
   - outputs/your_module_name/data.json
   - outputs/your_module_name/report.html
"""


# ============================================
# TESTING TEMPLATE
# ============================================
"""
Create test_your_module.py:

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from modules.your_module_name import YourModule

def test_module():
    module = YourModule()
    results = module.run("example.com")
    
    assert results is not None
    assert 'json' in results
    assert 'html' in results
    
    print("✓ Module test passed")

if __name__ == '__main__':
    test_module()
"""


# ============================================
# BEST PRACTICES
# ============================================
"""
1. ERROR HANDLING:
   - Always wrap API calls in try-except
   - Return empty list on error (don't raise)
   - Print user-friendly error messages

2. DATA CONSISTENCY:
   - Always include 'source' field
   - Use 'N/A' for missing data (not None or empty string)
   - Keep field names consistent across records

3. PERFORMANCE:
   - Implement pagination for large result sets
   - Respect API rate limits
   - Add configurable timeouts

4. SECURITY:
   - Never log or print API keys
   - Validate user input
   - Use HTTPS for all requests

5. DOCUMENTATION:
   - Document all public methods
   - Explain API requirements
   - Provide usage examples

6. CODE QUALITY:
   - Follow PEP 8 style guide
   - Use type hints
   - Keep methods focused and small
"""
