"""
Professional Passive Reconnaissance Report Generator
Generates comprehensive PDF reports following standard business report structure
"""

from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle,
    ListFlowable, ListItem, KeepTogether
)
from reportlab.pdfgen import canvas
from datetime import datetime
import json
import os
import glob

class NumberedCanvas(canvas.Canvas):
    """Canvas with page numbers and headers/footers"""
    
    def __init__(self, *args, **kwargs):
        canvas.Canvas.__init__(self, *args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_number(num_pages)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)

    def draw_page_number(self, page_count):
        self.setFont("Helvetica", 9)
        self.setFillColor(colors.grey)
        self.drawRightString(
            7.5 * inch, 0.5 * inch,
            f"Page {self._pageNumber} of {page_count}"
        )
        self.drawString(
            1 * inch, 0.5 * inch,
            f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        )


class ProfessionalReportGenerator:
    """Professional Passive Reconnaissance Report Generator"""
    
    def __init__(self, target, output_dir):
        self.target = target
        self.output_dir = output_dir
        self.report_date = datetime.now()
        self.combined_data = self._load_combined_data()
        
    def _load_combined_data(self):
        """Load the combined JSON data"""
        pattern = os.path.join(self.output_dir, f"Combined_Report_{self.target}_*.json")
        files = glob.glob(pattern)
        
        if not files:
            return {}
        
        # Get the most recent file
        latest_file = max(files, key=os.path.getctime)
        
        try:
            with open(latest_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"[!] Error loading combined data: {e}")
            return {}
    
    def generate_report(self):
        """Generate the complete professional report"""
        filename = os.path.join(
            self.output_dir,
            f"Professional_Report_{self.target}_{self.report_date.strftime('%Y%m%d_%H%M%S')}.pdf"
        )
        
        doc = SimpleDocTemplate(
            filename,
            pagesize=letter,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=50,
        )
        
        # Build the story (content)
        story = []
        styles = self._create_styles()
        
        # 1. Title Page
        story.extend(self._create_title_page(styles))
        story.append(PageBreak())
        
        # 2. Table of Contents
        story.extend(self._create_toc(styles))
        story.append(PageBreak())
        
        # 3. Executive Summary
        story.extend(self._create_executive_summary(styles))
        story.append(PageBreak())
        
        # 4. Introduction
        story.extend(self._create_introduction(styles))
        story.append(PageBreak())
        
        # 5. Methodology
        story.extend(self._create_methodology(styles))
        story.append(PageBreak())
        
        # 6. Findings/Results
        story.extend(self._create_findings(styles))
        story.append(PageBreak())
        
        # 7. Analysis/Discussion
        story.extend(self._create_analysis(styles))
        story.append(PageBreak())
        
        # 8. Conclusion
        story.extend(self._create_conclusion(styles))
        story.append(PageBreak())
        
        # 9. Recommendations
        story.extend(self._create_recommendations(styles))
        story.append(PageBreak())
        
        # 10. References
        story.extend(self._create_references(styles))
        story.append(PageBreak())
        
        # 11. Appendices
        story.extend(self._create_appendices(styles))
        
        # Build PDF
        doc.build(story, canvasmaker=NumberedCanvas)
        
        return filename
    
    def _create_styles(self):
        """Create custom paragraph styles"""
        styles = getSampleStyleSheet()
        
        styles.add(ParagraphStyle(
            name='CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#1a365d'),
            spaceAfter=30,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        ))
        
        styles.add(ParagraphStyle(
            name='SectionHeading',
            parent=styles['Heading1'],
            fontSize=16,
            textColor=colors.HexColor('#2c5282'),
            spaceAfter=12,
            spaceBefore=12,
            fontName='Helvetica-Bold'
        ))
        
        styles.add(ParagraphStyle(
            name='SubHeading',
            parent=styles['Heading2'],
            fontSize=14,
            textColor=colors.HexColor('#2d3748'),
            spaceAfter=10,
            spaceBefore=10,
            fontName='Helvetica-Bold'
        ))
        
        styles.add(ParagraphStyle(
            name='BodyJustified',
            parent=styles['BodyText'],
            alignment=TA_JUSTIFY,
            spaceAfter=12,
            fontSize=11
        ))
        
        return styles
    
    def _create_title_page(self, styles):
        """Create title page"""
        content = []
        
        content.append(Spacer(1, 2*inch))
        
        content.append(Paragraph(
            "PASSIVE RECONNAISSANCE REPORT",
            styles['CustomTitle']
        ))
        
        content.append(Spacer(1, 0.5*inch))
        
        content.append(Paragraph(
            f"Target: <b>{self.target}</b>",
            ParagraphStyle(
                'TargetStyle',
                parent=styles['Normal'],
                fontSize=14,
                alignment=TA_CENTER,
                textColor=colors.HexColor('#2d3748')
            )
        ))
        
        content.append(Spacer(1, 1*inch))
        
        # Report metadata table
        meta_data = [
            ['Report Date:', self.report_date.strftime('%B %d, %Y')],
            ['Report Time:', self.report_date.strftime('%H:%M:%S')],
            ['Assessment Type:', 'Passive Reconnaissance'],
            ['Target Domain:', self.target],
            ['Report Classification:', 'Confidential'],
        ]
        
        meta_table = Table(meta_data, colWidths=[2*inch, 3*inch])
        meta_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 11),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#2d3748')),
            ('ROWBACKGROUNDS', (0, 0), (-1, -1), [colors.white, colors.HexColor('#f7fafc')]),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        
        content.append(meta_table)
        
        content.append(Spacer(1, 1.5*inch))
        
        content.append(Paragraph(
            "Generated by: Passive Reconnaissance Automation Tool",
            ParagraphStyle(
                'FooterStyle',
                parent=styles['Normal'],
                fontSize=10,
                alignment=TA_CENTER,
                textColor=colors.grey
            )
        ))
        
        return content
    
    def _create_toc(self, styles):
        """Create table of contents"""
        content = []
        
        content.append(Paragraph("TABLE OF CONTENTS", styles['SectionHeading']))
        content.append(Spacer(1, 0.3*inch))
        
        toc_items = [
            "1. Executive Summary",
            "2. Introduction",
            "   2.1 Purpose",
            "   2.2 Scope",
            "   2.3 Report Structure",
            "3. Methodology",
            "   3.1 Reconnaissance Approach",
            "   3.2 Tools and Techniques",
            "   3.3 Data Collection Methods",
            "4. Findings and Results",
            "   4.1 Domain Intelligence",
            "   4.2 Infrastructure Discovery",
            "   4.3 Security Assessment",
            "   4.4 Email and Breach Analysis",
            "   4.5 Social Media Intelligence",
            "5. Analysis and Discussion",
            "   5.1 Attack Surface Analysis",
            "   5.2 Security Posture Evaluation",
            "   5.3 Risk Assessment",
            "6. Conclusion",
            "7. Recommendations",
            "   7.1 High Priority",
            "   7.2 Medium Priority",
            "   7.3 Low Priority",
            "8. References",
            "9. Appendices",
            "   Appendix A: Technical Data",
            "   Appendix B: Tool Alternatives",
            "   Appendix C: Glossary",
        ]
        
        for item in toc_items:
            content.append(Paragraph(item, styles['Normal']))
            content.append(Spacer(1, 0.1*inch))
        
        return content
    
    def _create_executive_summary(self, styles):
        """Create executive summary"""
        content = []
        
        content.append(Paragraph("1. EXECUTIVE SUMMARY", styles['SectionHeading']))
        content.append(Spacer(1, 0.2*inch))
        
        # Calculate summary statistics
        total_findings = sum(len(v.get('results', [])) for v in self.combined_data.values() if isinstance(v, dict))
        modules_executed = len([k for k, v in self.combined_data.items() if isinstance(v, dict) and v.get('results')])
        
        summary_text = f"""
        This report presents the findings of a comprehensive passive reconnaissance assessment 
        conducted on the target domain <b>{self.target}</b>. The assessment was performed using 
        automated intelligence gathering techniques that do not directly interact with the target 
        infrastructure, ensuring a non-intrusive approach.
        <br/><br/>
        <b>Key Statistics:</b><br/>
        • Total Modules Executed: {modules_executed}<br/>
        • Total Data Points Collected: {total_findings}<br/>
        • Assessment Date: {self.report_date.strftime('%B %d, %Y')}<br/>
        • Assessment Duration: Automated<br/>
        <br/>
        The reconnaissance revealed significant information about the target's digital footprint, 
        including subdomain enumeration, IP infrastructure, SSL/TLS configurations, email security 
        posture, potential data breaches, and publicly exposed information.
        <br/><br/>
        <b>Critical Findings:</b><br/>
        This summary provides an overview of the most significant discoveries that require immediate 
        attention from the security team.
        """
        
        content.append(Paragraph(summary_text, styles['BodyJustified']))
        
        # Key findings table
        content.append(Spacer(1, 0.3*inch))
        content.append(Paragraph("Key Metrics", styles['SubHeading']))
        
        metrics = self._calculate_key_metrics()
        
        metrics_data = [
            ['Category', 'Count', 'Status'],
            ['Subdomains Discovered', metrics['subdomains'], self._get_status_indicator(metrics['subdomains'])],
            ['IP Addresses Identified', metrics['ips'], self._get_status_indicator(metrics['ips'])],
            ['Open Ports Found', metrics['ports'], self._get_status_indicator(metrics['ports'])],
            ['Emails Discovered', metrics['emails'], self._get_status_indicator(metrics['emails'])],
            ['Breached Emails', metrics['breached_emails'], self._get_severity_indicator(metrics['breached_emails'])],
            ['SSL/TLS Issues', metrics['ssl_issues'], self._get_severity_indicator(metrics['ssl_issues'])],
        ]
        
        metrics_table = Table(metrics_data, colWidths=[3*inch, 1.5*inch, 1.5*inch])
        metrics_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2c5282')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f7fafc')]),
        ]))
        
        content.append(metrics_table)
        
        return content
    
    def _create_introduction(self, styles):
        """Create introduction section"""
        content = []
        
        content.append(Paragraph("2. INTRODUCTION", styles['SectionHeading']))
        content.append(Spacer(1, 0.2*inch))
        
        content.append(Paragraph("2.1 Purpose", styles['SubHeading']))
        purpose_text = f"""
        The purpose of this passive reconnaissance assessment is to identify and document the 
        publicly available information about <b>{self.target}</b> without directly interacting 
        with the target's infrastructure. This assessment helps in:
        <br/><br/>
        • Understanding the organization's external digital footprint<br/>
        • Identifying potential security vulnerabilities from an attacker's perspective<br/>
        • Evaluating the effectiveness of current security measures<br/>
        • Providing actionable recommendations for improving security posture<br/>
        • Assessing exposure to data breaches and information leaks
        """
        content.append(Paragraph(purpose_text, styles['BodyJustified']))
        content.append(Spacer(1, 0.2*inch))
        
        content.append(Paragraph("2.2 Scope", styles['SubHeading']))
        scope_text = f"""
        The scope of this assessment is limited to passive reconnaissance techniques that gather 
        information from publicly available sources. The assessment includes:
        <br/><br/>
        <b>In Scope:</b><br/>
        • Subdomain enumeration and DNS intelligence<br/>
        • IP address identification and reputation analysis<br/>
        • SSL/TLS certificate analysis<br/>
        • Email harvesting and breach detection<br/>
        • Open-source intelligence (OSINT) gathering<br/>
        • Social media and public platform enumeration<br/>
        • Historical data analysis via archive services<br/>
        • Port and service discovery via passive databases<br/>
        <br/>
        <b>Out of Scope:</b><br/>
        • Active scanning or penetration testing<br/>
        • Direct interaction with target infrastructure<br/>
        • Social engineering or phishing attempts<br/>
        • Exploitation of identified vulnerabilities<br/>
        • Access to internal systems or networks
        """
        content.append(Paragraph(scope_text, styles['BodyJustified']))
        content.append(Spacer(1, 0.2*inch))
        
        content.append(Paragraph("2.3 Report Structure", styles['SubHeading']))
        structure_text = """
        This report follows a standard business report structure designed to provide clear, 
        actionable intelligence. Each section builds upon the previous to present a comprehensive 
        view of the target's security posture from a passive reconnaissance perspective.
        """
        content.append(Paragraph(structure_text, styles['BodyJustified']))
        
        return content
    
    def _create_methodology(self, styles):
        """Create methodology section"""
        content = []
        
        content.append(Paragraph("3. METHODOLOGY", styles['SectionHeading']))
        content.append(Spacer(1, 0.2*inch))
        
        content.append(Paragraph("3.1 Reconnaissance Approach", styles['SubHeading']))
        approach_text = """
        The passive reconnaissance approach utilized in this assessment follows industry best 
        practices and OSINT methodologies. The assessment employs a layered approach to gather 
        intelligence from multiple independent sources to ensure accuracy and reduce false positives.
        <br/><br/>
        All data collection was performed using legitimate, publicly accessible sources and APIs. 
        The methodology emphasizes:
        <br/><br/>
        • Non-intrusive data gathering techniques<br/>
        • Multi-source validation to ensure accuracy<br/>
        • Automated deduplication to eliminate redundant data<br/>
        • False positive filtering through cross-verification<br/>
        • CAPTCHA avoidance through proper rate limiting and request throttling
        """
        content.append(Paragraph(approach_text, styles['BodyJustified']))
        content.append(Spacer(1, 0.2*inch))
        
        content.append(Paragraph("3.2 Tools and Techniques", styles['SubHeading']))
        
        tools_data = [
            ['Module', 'Primary Tools', 'Alternative Tools', 'Purpose'],
            ['Subdomain Enumeration', 'crt.sh, SecurityTrails', 'Sublist3r, Amass', 'Discover subdomains'],
            ['Certificate Intelligence', 'crt.sh, Censys', 'Certificate Transparency', 'SSL/TLS analysis'],
            ['DNS Intelligence', 'DNS queries, Zone info', 'DNSdumpster, DNSrecon', 'DNS records'],
            ['IP Reputation', 'VirusTotal, AbuseIPDB', 'GreyNoise, IPVoid', 'Threat intelligence'],
            ['Email Analysis', 'Hunter.io, IntelX', 'theHarvester, EmailRep', 'Email discovery'],
            ['Breach Detection', 'HaveIBeenPwned', 'LeakCheck, Dehashed', 'Data breach checks'],
            ['Email Security', 'DNS TXT records', 'MXToolbox, DMARCian', 'DMARC/SPF/DKIM'],
            ['Social Media', 'Platform APIs', 'Sherlock, Social-Searcher', 'Social presence'],
            ['Historical Data', 'Wayback Machine', 'Archive.today', 'Historical snapshots'],
            ['Port Intelligence', 'Shodan, Censys', 'ZoomEye, LeakIX', 'Service discovery'],
        ]
        
        tools_table = Table(tools_data, colWidths=[1.5*inch, 1.5*inch, 1.5*inch, 1.5*inch])
        tools_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2c5282')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f7fafc')]),
        ]))
        
        content.append(tools_table)
        content.append(Spacer(1, 0.2*inch))
        
        content.append(Paragraph("3.3 Data Collection Methods", styles['SubHeading']))
        methods_text = """
        Data collection was performed using the following methods:
        <br/><br/>
        <b>1. API-Based Queries:</b> Legitimate API calls to public intelligence platforms<br/>
        <b>2. DNS Interrogation:</b> Standard DNS queries for publicly available records<br/>
        <b>3. Certificate Transparency Logs:</b> Analysis of public SSL/TLS certificate databases<br/>
        <b>4. Search Engine Intelligence:</b> GitHub API and CAPTCHA-aware search techniques<br/>
        <b>5. Breach Database Queries:</b> Cross-referencing against 5+ free breach databases<br/>
        <b>6. Historical Archive Analysis:</b> Examination of cached and archived web content<br/>
        <br/>
        All methods comply with the terms of service of respective platforms and employ proper 
        rate limiting to avoid triggering anti-automation measures.
        """
        content.append(Paragraph(methods_text, styles['BodyJustified']))
        
        return content
    
    def _create_findings(self, styles):
        """Create findings section with actual data"""
        content = []
        
        content.append(Paragraph("4. FINDINGS AND RESULTS", styles['SectionHeading']))
        content.append(Spacer(1, 0.2*inch))
        
        # 4.1 Domain Intelligence
        content.append(Paragraph("4.1 Domain Intelligence", styles['SubHeading']))
        content.extend(self._create_domain_findings(styles))
        content.append(Spacer(1, 0.2*inch))
        
        # 4.2 Infrastructure Discovery
        content.append(Paragraph("4.2 Infrastructure Discovery", styles['SubHeading']))
        content.extend(self._create_infrastructure_findings(styles))
        content.append(Spacer(1, 0.2*inch))
        
        # 4.3 Security Assessment
        content.append(Paragraph("4.3 Security Assessment", styles['SubHeading']))
        content.extend(self._create_security_findings(styles))
        content.append(Spacer(1, 0.2*inch))
        
        # 4.4 Email and Breach Analysis
        content.append(Paragraph("4.4 Email and Breach Analysis", styles['SubHeading']))
        content.extend(self._create_email_findings(styles))
        content.append(Spacer(1, 0.2*inch))
        
        # 4.5 Social Media Intelligence
        content.append(Paragraph("4.5 Social Media Intelligence", styles['SubHeading']))
        content.extend(self._create_social_findings(styles))
        
        return content
    
    def _create_domain_findings(self, styles):
        """Create domain-related findings"""
        content = []
        
        subdomains = self.combined_data.get('subdomain_enumeration', {}).get('results', [])
        dns_data = self.combined_data.get('dns_intelligence', {}).get('results', [])
        whois_data = self.combined_data.get('whois_lookup', {}).get('results', [])
        
        findings_text = f"""
        The domain intelligence gathering phase revealed the following information about 
        <b>{self.target}</b>:
        <br/><br/>
        <b>Subdomains Discovered:</b> {len(subdomains)} unique subdomains<br/>
        <b>DNS Records Analyzed:</b> {len(dns_data)} records<br/>
        <b>WHOIS Information:</b> {'Available' if whois_data else 'Limited'}<br/>
        <br/>
        """
        
        if subdomains:
            findings_text += "<b>Notable Subdomains:</b><br/>"
            for subdomain in subdomains[:10]:
                if isinstance(subdomain, dict):
                    findings_text += f"• {subdomain.get('subdomain', 'N/A')}<br/>"
                else:
                    findings_text += f"• {subdomain}<br/>"
        else:
            findings_text += "<b>Result:</b> No subdomains discovered through passive sources.<br/>"
        
        content.append(Paragraph(findings_text, styles['BodyJustified']))
        
        return content
    
    def _create_infrastructure_findings(self, styles):
        """Create infrastructure-related findings"""
        content = []
        
        ip_reputation = self.combined_data.get('ip_reputation', {}).get('results', [])
        ports = self.combined_data.get('port_enumeration', {}).get('results', [])
        ssl_data = self.combined_data.get('ssl_tls_analysis', {}).get('results', [])
        
        findings_text = f"""
        Infrastructure analysis identified the following components:
        <br/><br/>
        <b>IP Addresses Analyzed:</b> {len(ip_reputation)}<br/>
        <b>Open Ports Discovered:</b> {len(ports)}<br/>
        <b>SSL/TLS Certificates:</b> {len(ssl_data)} analyzed<br/>
        <br/>
        """
        
        if ip_reputation:
            findings_text += "<b>IP Reputation Analysis:</b><br/>"
            for ip_data in ip_reputation[:5]:
                if isinstance(ip_data, dict):
                    ip = ip_data.get('ip', 'Unknown')
                    status = ip_data.get('reputation_status', 'Unknown')
                    findings_text += f"• {ip}: {status}<br/>"
        else:
            findings_text += "<b>IP Analysis:</b> No reputation issues detected.<br/>"
        
        if ports:
            findings_text += "<br/><b>Open Ports (Top 10):</b><br/>"
            port_list = []
            for port in ports[:10]:
                if isinstance(port, dict):
                    port_num = port.get('port', 'N/A')
                    service = port.get('service', 'Unknown')
                    port_list.append(f"{port_num}/{service}")
            findings_text += f"• {', '.join(port_list[:10])}<br/>"
        else:
            findings_text += "<br/><b>Port Analysis:</b> No open ports discovered via passive sources.<br/>"
        
        content.append(Paragraph(findings_text, styles['BodyJustified']))
        
        return content
    
    def _create_security_findings(self, styles):
        """Create security-related findings"""
        content = []
        
        ssl_data = self.combined_data.get('ssl_tls_analysis', {}).get('results', [])
        email_security = self.combined_data.get('email_security_analysis', {}).get('results', [])
        
        findings_text = """
        Security assessment findings:
        <br/><br/>
        """
        
        # SSL/TLS Analysis
        if ssl_data:
            ssl_info = ssl_data[0] if isinstance(ssl_data[0], dict) else {}
            findings_text += "<b>SSL/TLS Configuration:</b><br/>"
            findings_text += f"• Certificate Validity: {ssl_info.get('is_valid', 'Unknown')}<br/>"
            findings_text += f"• Issuer: {ssl_info.get('issuer', 'Unknown')}<br/>"
            findings_text += f"• Issues Detected: {ssl_info.get('issues_found', 0)}<br/>"
        else:
            findings_text += "<b>SSL/TLS:</b> No misconfiguration identified.<br/>"
        
        # Email Security
        if email_security:
            email_sec = email_security[0] if isinstance(email_security[0], dict) else {}
            findings_text += "<br/><b>Email Security Posture:</b><br/>"
            findings_text += f"• SPF Record: {email_sec.get('spf_status', 'Not checked')}<br/>"
            findings_text += f"• DMARC Policy: {email_sec.get('dmarc_status', 'Not checked')}<br/>"
            findings_text += f"• DKIM Selectors: {email_sec.get('dkim_selectors_found', 0)} found<br/>"
        else:
            findings_text += "<br/><b>Email Security:</b> Configuration requires verification.<br/>"
        
        content.append(Paragraph(findings_text, styles['BodyJustified']))
        
        return content
    
    def _create_email_findings(self, styles):
        """Create email and breach findings"""
        content = []
        
        emails = self.combined_data.get('email_harvesting', {}).get('results', [])
        breaches = self.combined_data.get('email_leak_check', {}).get('results', [])
        
        findings_text = f"""
        Email intelligence and breach analysis:
        <br/><br/>
        <b>Emails Discovered:</b> {len(emails)}<br/>
        <b>Breach Checks Performed:</b> {'Yes' if breaches else 'No'}<br/>
        <br/>
        """
        
        if emails:
            findings_text += "<b>Discovered Email Addresses:</b><br/>"
            for email in emails[:10]:
                if isinstance(email, dict):
                    findings_text += f"• {email.get('email', 'N/A')}<br/>"
                else:
                    findings_text += f"• {email}<br/>"
        else:
            findings_text += "<b>Result:</b> No email addresses found via passive sources.<br/>"
        
        if breaches:
            findings_text += "<br/><b>Data Breach Analysis:</b><br/>"
            breach_info = breaches[0] if isinstance(breaches[0], dict) else {}
            findings_text += f"• Emails Checked: {breach_info.get('total_checked', 0)}<br/>"
            findings_text += f"• Clean Emails: {breach_info.get('clean_count', 0)}<br/>"
            findings_text += f"• Breached Emails: {breach_info.get('breached_count', 0)}<br/>"
        else:
            findings_text += "<br/><b>Breach Status:</b> No associated data leaks found.<br/>"
        
        content.append(Paragraph(findings_text, styles['BodyJustified']))
        
        return content
    
    def _create_social_findings(self, styles):
        """Create social media findings"""
        content = []
        
        social_data = self.combined_data.get('social_media_enumeration', {}).get('results', [])
        github_data = self.combined_data.get('github_intelligence', {}).get('results', [])
        
        findings_text = """
        Social media and public platform intelligence:
        <br/><br/>
        """
        
        if social_data:
            findings_text += f"<b>Social Media Profiles Found:</b> {len(social_data)}<br/>"
            platforms = set()
            for item in social_data[:20]:
                if isinstance(item, dict):
                    platform = item.get('platform', 'Unknown')
                    platforms.add(platform)
            findings_text += f"<b>Platforms Detected:</b> {', '.join(platforms)}<br/>"
        else:
            findings_text += "<b>Social Media:</b> Limited public presence detected.<br/>"
        
        if github_data:
            findings_text += f"<br/><b>GitHub Intelligence:</b> {len(github_data)} items found<br/>"
        else:
            findings_text += "<br/><b>GitHub:</b> No publicly exposed code or repositories found.<br/>"
        
        content.append(Paragraph(findings_text, styles['BodyJustified']))
        
        return content
    
    def _create_analysis(self, styles):
        """Create analysis section"""
        content = []
        
        content.append(Paragraph("5. ANALYSIS AND DISCUSSION", styles['SectionHeading']))
        content.append(Spacer(1, 0.2*inch))
        
        content.append(Paragraph("5.1 Attack Surface Analysis", styles['SubHeading']))
        attack_surface_text = f"""
        The passive reconnaissance revealed the external attack surface of <b>{self.target}</b>. 
        The attack surface comprises all publicly accessible assets, exposed services, and 
        information that could be leveraged by malicious actors.
        <br/><br/>
        <b>Key Observations:</b><br/>
        • Digital footprint spans multiple subdomains and IP addresses<br/>
        • Public exposure through various online platforms and services<br/>
        • Historical data available through archive services<br/>
        • Email addresses discoverable through public sources<br/>
        <br/>
        The attack surface analysis indicates areas where security hardening may be beneficial 
        to reduce the organization's exposure to potential threats.
        """
        content.append(Paragraph(attack_surface_text, styles['BodyJustified']))
        content.append(Spacer(1, 0.2*inch))
        
        content.append(Paragraph("5.2 Security Posture Evaluation", styles['SubHeading']))
        security_text = """
        The security posture evaluation examines the organization's defensive measures as 
        observable through passive reconnaissance:
        <br/><br/>
        <b>Positive Findings:</b><br/>
        • SSL/TLS certificates properly configured (if applicable)<br/>
        • No immediate malicious IP reputation issues<br/>
        • Email security protocols in place (if configured)<br/>
        <br/>
        <b>Areas of Concern:</b><br/>
        • Publicly exposed information may aid reconnaissance<br/>
        • Historical data reveals infrastructure changes over time<br/>
        • Email addresses publicly available may be targeted for phishing<br/>
        • Data breaches (if any) represent credential exposure risk
        """
        content.append(Paragraph(security_text, styles['BodyJustified']))
        content.append(Spacer(1, 0.2*inch))
        
        content.append(Paragraph("5.3 Risk Assessment", styles['SubHeading']))
        risk_text = """
        Based on the passive reconnaissance findings, the following risk categories have been 
        identified:
        <br/><br/>
        <b>Information Disclosure Risk:</b> The amount of publicly available information 
        provides attackers with reconnaissance data that can be used to plan targeted attacks.
        <br/><br/>
        <b>Credential Compromise Risk:</b> If email addresses are found in data breaches, 
        associated credentials may be compromised and could be used for unauthorized access.
        <br/><br/>
        <b>Social Engineering Risk:</b> Discovered email addresses and social media profiles 
        can be leveraged for phishing and social engineering campaigns.
        <br/><br/>
        <b>Infrastructure Targeting Risk:</b> Identified IP addresses, ports, and services 
        provide attackers with potential entry points for exploitation attempts.
        """
        content.append(Paragraph(risk_text, styles['BodyJustified']))
        
        return content
    
    def _create_conclusion(self, styles):
        """Create conclusion section"""
        content = []
        
        content.append(Paragraph("6. CONCLUSION", styles['SectionHeading']))
        content.append(Spacer(1, 0.2*inch))
        
        metrics = self._calculate_key_metrics()
        
        conclusion_text = f"""
        This passive reconnaissance assessment of <b>{self.target}</b> has successfully mapped 
        the organization's external digital footprint without directly interacting with the 
        target infrastructure. The assessment utilized multiple independent sources and 
        techniques to ensure comprehensive coverage and accuracy.
        <br/><br/>
        <b>Summary of Key Findings:</b><br/>
        • Discovered {metrics['subdomains']} unique subdomains<br/>
        • Identified {metrics['ips']} IP addresses<br/>
        • Found {metrics['emails']} email addresses<br/>
        • Detected {metrics['breached_emails']} email(s) in data breaches<br/>
        • Analyzed {metrics['ports']} open ports/services<br/>
        <br/>
        The findings indicate that while the organization maintains a typical online presence, 
        there are opportunities to reduce the attack surface and improve security posture. 
        The information gathered through this passive reconnaissance demonstrates what is 
        readily available to potential attackers and highlights the importance of continuous 
        security monitoring and remediation.
        <br/><br/>
        <b>Overall Assessment:</b><br/>
        The target demonstrates a standard security posture with both strengths and areas for 
        improvement. The recommendations section provides actionable steps to enhance the 
        organization's defensive capabilities and reduce exposure to potential threats.
        """
        
        content.append(Paragraph(conclusion_text, styles['BodyJustified']))
        
        return content
    
    def _create_recommendations(self, styles):
        """Create recommendations section"""
        content = []
        
        content.append(Paragraph("7. RECOMMENDATIONS", styles['SectionHeading']))
        content.append(Spacer(1, 0.2*inch))
        
        content.append(Paragraph("7.1 High Priority Recommendations", styles['SubHeading']))
        high_priority = """
        <b>1. Email Breach Remediation:</b><br/>
        If any email addresses were found in data breaches, immediately enforce password resets 
        for affected accounts and enable multi-factor authentication (MFA).
        <br/><br/>
        <b>2. Email Security Hardening:</b><br/>
        Implement or strengthen SPF, DMARC, and DKIM records to prevent email spoofing and 
        phishing attacks. Set DMARC policy to "quarantine" or "reject" for maximum protection.
        <br/><br/>
        <b>3. Subdomain Management:</b><br/>
        Review all discovered subdomains and ensure they are intentional and properly secured. 
        Decommission any unnecessary subdomains that expand the attack surface.
        <br/><br/>
        <b>4. SSL/TLS Certificate Management:</b><br/>
        Monitor certificate expiration dates and ensure all certificates are from trusted 
        Certificate Authorities. Remove or update any weak cipher suites.
        """
        content.append(Paragraph(high_priority, styles['BodyJustified']))
        content.append(Spacer(1, 0.2*inch))
        
        content.append(Paragraph("7.2 Medium Priority Recommendations", styles['SubHeading']))
        medium_priority = """
        <b>5. Port and Service Minimization:</b><br/>
        Review all publicly accessible ports and services. Close unnecessary ports and ensure 
        all services are running the latest patched versions.
        <br/><br/>
        <b>6. Information Disclosure Management:</b><br/>
        Minimize the amount of technical information exposed in public-facing assets such as 
        error messages, headers, and metadata.
        <br/><br/>
        <b>7. Security Awareness Training:</b><br/>
        Conduct security awareness training for employees whose email addresses are publicly 
        available, focusing on phishing recognition and social engineering tactics.
        <br/><br/>
        <b>8. GitHub and Code Repository Security:</b><br/>
        If GitHub repositories or code was discovered, ensure no sensitive information (API keys, 
        credentials, internal documentation) is exposed in public repositories.
        """
        content.append(Paragraph(medium_priority, styles['BodyJustified']))
        content.append(Spacer(1, 0.2*inch))
        
        content.append(Paragraph("7.3 Low Priority Recommendations", styles['SubHeading']))
        low_priority = """
        <b>9. Social Media Profile Management:</b><br/>
        Review organizational social media presence and ensure profiles contain appropriate 
        information without exposing sensitive technical or organizational details.
        <br/><br/>
        <b>10. Continuous Monitoring:</b><br/>
        Implement continuous passive reconnaissance monitoring to track changes in the 
        organization's digital footprint and identify new exposures as they emerge.
        <br/><br/>
        <b>11. DNS Security:</b><br/>
        Consider implementing DNSSEC to protect against DNS spoofing and cache poisoning attacks.
        <br/><br/>
        <b>12. Regular Security Assessments:</b><br/>
        Conduct passive reconnaissance assessments quarterly to maintain visibility into the 
        organization's external attack surface and track remediation progress.
        """
        content.append(Paragraph(low_priority, styles['BodyJustified']))
        
        return content
    
    def _create_references(self, styles):
        """Create references section"""
        content = []
        
        content.append(Paragraph("8. REFERENCES", styles['SectionHeading']))
        content.append(Spacer(1, 0.2*inch))
        
        references = """
        <b>Data Sources and Intelligence Platforms:</b><br/>
        <br/>
        1. Certificate Transparency Logs (crt.sh)<br/>
        &nbsp;&nbsp;&nbsp;https://crt.sh<br/>
        <br/>
        2. VirusTotal - Multi-engine malware and reputation analysis<br/>
        &nbsp;&nbsp;&nbsp;https://www.virustotal.com<br/>
        <br/>
        3. AbuseIPDB - IP address abuse reporting database<br/>
        &nbsp;&nbsp;&nbsp;https://www.abuseipdb.com<br/>
        <br/>
        4. Have I Been Pwned - Data breach notification service<br/>
        &nbsp;&nbsp;&nbsp;https://haveibeenpwned.com<br/>
        <br/>
        5. Shodan - Search engine for Internet-connected devices<br/>
        &nbsp;&nbsp;&nbsp;https://www.shodan.io<br/>
        <br/>
        6. Censys - Internet-wide scanning and intelligence<br/>
        &nbsp;&nbsp;&nbsp;https://censys.io<br/>
        <br/>
        7. SecurityTrails - DNS and domain intelligence<br/>
        &nbsp;&nbsp;&nbsp;https://securitytrails.com<br/>
        <br/>
        8. Wayback Machine - Internet archive<br/>
        &nbsp;&nbsp;&nbsp;https://archive.org/web<br/>
        <br/>
        9. GitHub - Code repository platform<br/>
        &nbsp;&nbsp;&nbsp;https://github.com<br/>
        <br/>
        10. Hunter.io - Email discovery and verification<br/>
        &nbsp;&nbsp;&nbsp;https://hunter.io<br/>
        <br/>
        <b>Methodological References:</b><br/>
        <br/>
        • OWASP Testing Guide - Passive Information Gathering<br/>
        • NIST Cybersecurity Framework<br/>
        • MITRE ATT&CK Framework - Reconnaissance Tactics<br/>
        • OSINT Framework and Methodologies<br/>
        <br/>
        <b>Security Standards:</b><br/>
        <br/>
        • RFC 7208 - Sender Policy Framework (SPF)<br/>
        • RFC 7489 - Domain-based Message Authentication (DMARC)<br/>
        • RFC 6376 - DomainKeys Identified Mail (DKIM)<br/>
        • RFC 6698 - DNS-Based Authentication of Named Entities (DANE)
        """
        
        content.append(Paragraph(references, styles['Normal']))
        
        return content
    
    def _create_appendices(self, styles):
        """Create appendices section"""
        content = []
        
        content.append(Paragraph("9. APPENDICES", styles['SectionHeading']))
        content.append(Spacer(1, 0.2*inch))
        
        content.append(Paragraph("Appendix A: Technical Data Summary", styles['SubHeading']))
        appendix_a = f"""
        This appendix contains technical details about the reconnaissance process and data 
        collection statistics.
        <br/><br/>
        <b>Assessment Details:</b><br/>
        • Target Domain: {self.target}<br/>
        • Assessment Date: {self.report_date.strftime('%Y-%m-%d %H:%M:%S')}<br/>
        • Modules Executed: {len([k for k, v in self.combined_data.items() if isinstance(v, dict) and v.get('results')])}<br/>
        • Total Data Points: {sum(len(v.get('results', [])) for v in self.combined_data.values() if isinstance(v, dict))}<br/>
        <br/>
        <b>Output Files Generated:</b><br/>
        • Combined JSON Report<br/>
        • Combined HTML Report<br/>
        • Professional PDF Report (this document)<br/>
        • Individual module JSON/HTML outputs<br/>
        <br/>
        For detailed raw data, please refer to the JSON output files in the outputs directory.
        """
        content.append(Paragraph(appendix_a, styles['BodyJustified']))
        content.append(Spacer(1, 0.2*inch))
        
        content.append(Paragraph("Appendix B: Tool Alternatives and Equivalents", styles['SubHeading']))
        appendix_b = """
        This appendix lists alternative tools that can perform equivalent passive reconnaissance 
        functions. This information is provided for reference and validation purposes.
        <br/><br/>
        <b>Subdomain Enumeration:</b><br/>
        • Sublist3r, Amass, Subfinder, Assetfinder, Findomain<br/>
        <br/>
        <b>DNS Intelligence:</b><br/>
        • DNSdumpster, DNSrecon, Fierce, DNSEnum<br/>
        <br/>
        <b>IP Reputation:</b><br/>
        • GreyNoise, IPVoid, Talos Intelligence, IBM X-Force<br/>
        <br/>
        <b>SSL/TLS Analysis:</b><br/>
        • SSLLabs, testssl.sh, SSL Checker<br/>
        <br/>
        <b>Email Discovery:</b><br/>
        • theHarvester, EmailHunter, Skrapp<br/>
        <br/>
        <b>Breach Checking:</b><br/>
        • LeakCheck, Dehashed, BreachDirectory, Snusbase<br/>
        <br/>
        <b>Port Intelligence:</b><br/>
        • ZoomEye, LeakIX, BinaryEdge, FullHunt<br/>
        <br/>
        <b>Social Media OSINT:</b><br/>
        • Sherlock, Social-Analyzer, Maigret<br/>
        <br/>
        These tools provide redundancy and cross-validation capabilities for reconnaissance data.
        """
        content.append(Paragraph(appendix_b, styles['BodyJustified']))
        content.append(Spacer(1, 0.2*inch))
        
        content.append(Paragraph("Appendix C: Glossary of Terms", styles['SubHeading']))
        appendix_c = """
        <b>Common Terms and Abbreviations:</b><br/>
        <br/>
        <b>OSINT:</b> Open-Source Intelligence - gathering information from publicly available sources<br/>
        <b>Passive Reconnaissance:</b> Information gathering without directly interacting with target<br/>
        <b>Attack Surface:</b> Sum of all possible entry points for unauthorized access<br/>
        <b>SPF:</b> Sender Policy Framework - email authentication method<br/>
        <b>DMARC:</b> Domain-based Message Authentication, Reporting & Conformance<br/>
        <b>DKIM:</b> DomainKeys Identified Mail - email authentication technique<br/>
        <b>SSL/TLS:</b> Secure Sockets Layer / Transport Layer Security - encryption protocols<br/>
        <b>Certificate Transparency:</b> Public log of SSL/TLS certificates<br/>
        <b>DNS:</b> Domain Name System - translates domain names to IP addresses<br/>
        <b>Subdomain:</b> Domain that is part of a larger domain<br/>
        <b>API:</b> Application Programming Interface<br/>
        <b>CAPTCHA:</b> Challenge-response test to distinguish humans from bots<br/>
        <b>Rate Limiting:</b> Controlling the frequency of requests to prevent abuse<br/>
        <b>False Positive:</b> Incorrect identification of an issue<br/>
        <b>MFA:</b> Multi-Factor Authentication<br/>
        <b>IP Reputation:</b> Assessment of an IP address's trustworthiness based on behavior<br/>
        """
        content.append(Paragraph(appendix_c, styles['Normal']))
        
        return content
    
    def _calculate_key_metrics(self):
        """Calculate key metrics from combined data"""
        metrics = {
            'subdomains': 0,
            'ips': 0,
            'ports': 0,
            'emails': 0,
            'breached_emails': 0,
            'ssl_issues': 0,
        }
        
        if 'subdomain_enumeration' in self.combined_data:
            metrics['subdomains'] = len(self.combined_data['subdomain_enumeration'].get('results', []))
        
        if 'ip_reputation' in self.combined_data:
            metrics['ips'] = len(self.combined_data['ip_reputation'].get('results', []))
        
        if 'port_enumeration' in self.combined_data:
            metrics['ports'] = len(self.combined_data['port_enumeration'].get('results', []))
        
        if 'email_harvesting' in self.combined_data:
            metrics['emails'] = len(self.combined_data['email_harvesting'].get('results', []))
        
        if 'email_leak_check' in self.combined_data:
            leak_data = self.combined_data['email_leak_check'].get('results', [])
            if leak_data and isinstance(leak_data[0], dict):
                metrics['breached_emails'] = leak_data[0].get('breached_count', 0)
        
        if 'ssl_tls_analysis' in self.combined_data:
            ssl_data = self.combined_data['ssl_tls_analysis'].get('results', [])
            if ssl_data and isinstance(ssl_data[0], dict):
                metrics['ssl_issues'] = ssl_data[0].get('issues_found', 0)
        
        return metrics
    
    def _get_status_indicator(self, count):
        """Get status indicator based on count"""
        if count == 0:
            return "None Found"
        elif count < 10:
            return "Low"
        elif count < 50:
            return "Medium"
        else:
            return "High"
    
    def _get_severity_indicator(self, count):
        """Get severity indicator for issues"""
        if count == 0:
            return "✓ Clean"
        elif count < 3:
            return "⚠ Low"
        elif count < 10:
            return "⚠ Medium"
        else:
            return "⚠ High"
