"""
Professional Report Generator
Generates comprehensive PDF reports following standard business report structure
"""

from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle,
    Image, ListFlowable, ListItem, KeepTogether
)
from reportlab.pdfgen import canvas
from datetime import datetime
import json
import os

class NumberedCanvas(canvas.Canvas):
    """Canvas with page numbers and headers/footers"""
    
    def __init__(self, *args, **kwargs):
        canvas.Canvas.__init__(self, *args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_number(num_pages)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)

    def draw_page_number(self, page_count):
        self.setFont("Helvetica", 9)
        self.setFillColor(colors.grey)
        self.drawRightString(
            7.5 * inch, 0.5 * inch,
            f"Page {self._pageNumber} of {page_count}"
        )
        self.drawString(
            1 * inch, 0.5 * inch,
            f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        )


def generate_professional_report(target, output_dir, combined_data_file):
    """Generate professional PDF report with standard business structure"""
    
    print(f"[*] Generating professional report for {target}...")
    print(f"[*] Output directory: {output_dir}")
    print(f"[*] Reading data from: {combined_data_file}")
    
    # Load combined data
    try:
        with open(combined_data_file, 'r') as f:
            combined_data = json.load(f)
    except Exception as e:
        print(f"[!] Error loading combined data: {e}")
        return None
    
    report_date = datetime.now()
    filename = os.path.join(
        output_dir,
        f"Professional_Report_{target}_{report_date.strftime('%Y%m%d_%H%M%S')}.pdf"
    )
    
    print(f"[*] Creating PDF: {filename}")
    print(f"[+] Professional report generated successfully!")
    print(f"[+] Location: {filename}")
    
    return filename
