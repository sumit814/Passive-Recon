"""
HTML Visualizer - Generate beautiful HTML reports
"""

from typing import List, Dict, Any
from datetime import datetime
from pathlib import Path
import json

class HTMLVisualizer:
    """Generate HTML reports with tabular data"""
    
    @staticmethod
    def generate_html_report(
        data: List[Dict[str, Any]], 
        title: str, 
        module_name: str,
        target: str = "",
        metadata: Dict[str, Any] = None
    ) -> str:
        """
        Generate complete HTML report
        
        Args:
            data: List of dictionaries to display
            title: Report title
            module_name: Name of the module
            target: Target domain/IP
            metadata: Additional metadata
        
        Returns:
            HTML string
        """
        if not data:
            return HTMLVisualizer._generate_empty_report(title, module_name, target)
        
        # Extract column headers from first item
        headers = list(data[0].keys())
        
        html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} - Passive Recon Report</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
        }}
        
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }}
        
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }}
        
        .header h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }}
        
        .header .subtitle {{
            font-size: 1.2em;
            opacity: 0.9;
        }}
        
        .meta-info {{
            background: #f8f9fa;
            padding: 20px 30px;
            border-bottom: 2px solid #e9ecef;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }}
        
        .meta-item {{
            display: flex;
            align-items: center;
        }}
        
        .meta-label {{
            font-weight: bold;
            color: #495057;
            margin-right: 8px;
        }}
        
        .meta-value {{
            color: #667eea;
            font-weight: 600;
        }}
        
        .stats {{
            background: #e7f3ff;
            padding: 20px 30px;
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            gap: 20px;
        }}
        
        .stat-box {{
            text-align: center;
            padding: 15px 30px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        
        .stat-number {{
            font-size: 2.5em;
            font-weight: bold;
            color: #667eea;
        }}
        
        .stat-label {{
            color: #6c757d;
            margin-top: 5px;
            font-size: 0.9em;
        }}
        
        .content {{
            padding: 30px;
        }}
        
        .table-wrapper {{
            overflow-x: auto;
            margin-top: 20px;
        }}
        
        table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95em;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        
        thead {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }}
        
        th {{
            padding: 15px;
            text-align: left;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.85em;
            letter-spacing: 0.5px;
        }}
        
        tbody tr {{
            border-bottom: 1px solid #dee2e6;
            transition: background-color 0.2s;
        }}
        
        tbody tr:hover {{
            background-color: #f8f9fa;
        }}
        
        tbody tr:nth-child(even) {{
            background-color: #f8f9fa;
        }}
        
        tbody tr:nth-child(even):hover {{
            background-color: #e9ecef;
        }}
        
        td {{
            padding: 12px 15px;
            color: #495057;
        }}
        
        .empty-state {{
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }}
        
        .empty-state svg {{
            width: 100px;
            height: 100px;
            margin-bottom: 20px;
            opacity: 0.5;
        }}
        
        .footer {{
            background: #f8f9fa;
            padding: 20px;
            text-align: center;
            color: #6c757d;
            font-size: 0.9em;
            border-top: 2px solid #e9ecef;
        }}
        
        .badge {{
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.85em;
            font-weight: 600;
        }}
        
        .badge-success {{
            background: #d4edda;
            color: #155724;
        }}
        
        .badge-warning {{
            background: #fff3cd;
            color: #856404;
        }}
        
        .badge-danger {{
            background: #f8d7da;
            color: #721c24;
        }}
        
        .badge-info {{
            background: #d1ecf1;
            color: #0c5460;
        }}
        
        @media print {{
            body {{
                background: white;
                padding: 0;
            }}
            
            .container {{
                box-shadow: none;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔍 {title}</h1>
            <div class="subtitle">Passive Reconnaissance Report</div>
        </div>
        
        <div class="meta-info">
            <div class="meta-item">
                <span class="meta-label">Module:</span>
                <span class="meta-value">{module_name}</span>
            </div>
            <div class="meta-item">
                <span class="meta-label">Target:</span>
                <span class="meta-value">{target or 'N/A'}</span>
            </div>
            <div class="meta-item">
                <span class="meta-label">Generated:</span>
                <span class="meta-value">{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</span>
            </div>
            <div class="meta-item">
                <span class="meta-label">Results Found:</span>
                <span class="meta-value">{len(data)}</span>
            </div>
        </div>
        
        <div class="stats">
            <div class="stat-box">
                <div class="stat-number">{len(data)}</div>
                <div class="stat-label">Total Records</div>
            </div>
            <div class="stat-box">
                <div class="stat-number">{len(headers)}</div>
                <div class="stat-label">Data Fields</div>
            </div>
        </div>
        
        <div class="content">
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
"""
        
        # Add headers
        for header in headers:
            html += f"                            <th>{header.replace('_', ' ').title()}</th>\n"
        
        html += """                        </tr>
                    </thead>
                    <tbody>
"""
        
        # Add data rows
        for idx, row in enumerate(data, 1):
            html += f"                        <tr>\n"
            html += f"                            <td><strong>{idx}</strong></td>\n"
            
            for header in headers:
                value = row.get(header, 'N/A')
                # Convert lists and dicts to readable format
                if isinstance(value, (list, dict)):
                    value = json.dumps(value, indent=2)
                html += f"                            <td>{value}</td>\n"
            
            html += f"                        </tr>\n"
        
        html += """                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="footer">
            <p>Generated by Passive Recon Framework | All rights reserved © 2025</p>
            <p style="margin-top: 5px; font-size: 0.85em;">⚠️ This data is for authorized security research only</p>
        </div>
    </div>
</body>
</html>
"""
        return html
    
    @staticmethod
    def _generate_empty_report(title: str, module_name: str, target: str) -> str:
        """Generate report for when no data is found"""
        return f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} - No Results</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }}
        .container {{
            background: white;
            border-radius: 12px;
            padding: 60px;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }}
        h1 {{ color: #667eea; margin-bottom: 20px; }}
        p {{ color: #6c757d; font-size: 1.1em; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 {title}</h1>
        <p>No results found for target: <strong>{target}</strong></p>
        <p style="margin-top: 20px; font-size: 0.9em;">Module: {module_name}</p>
    </div>
</body>
</html>
"""
