"""
Data Formatter - Handles deduplication and false positive filtering
"""

import hashlib
import re
from typing import List, Dict, Any, Set
from urllib.parse import urlparse

class DataFormatter:
    """Format, deduplicate and filter reconnaissance data"""
    
    def __init__(self):
        self.seen_hashes: Set[str] = set()
    
    def deduplicate(self, data: List[Dict[str, Any]], key_fields: List[str] = None) -> List[Dict[str, Any]]:
        """
        Remove duplicate entries based on key fields
        
        Args:
            data: List of dictionaries to deduplicate
            key_fields: Fields to use for uniqueness (if None, uses all fields)
        
        Returns:
            Deduplicated list
        """
        unique_data = []
        seen = set()
        
        for item in data:
            if key_fields:
                # Create hash from specific fields
                key_values = tuple(str(item.get(field, "")) for field in key_fields)
                item_hash = hashlib.md5(str(key_values).encode()).hexdigest()
            else:
                # Create hash from entire item
                item_hash = hashlib.md5(str(sorted(item.items())).encode()).hexdigest()
            
            if item_hash not in seen:
                seen.add(item_hash)
                unique_data.append(item)
        
        return unique_data
    
    def filter_false_positives(self, data: List[Dict[str, Any]], data_type: str) -> List[Dict[str, Any]]:
        """
        Filter out likely false positives based on data type
        
        Args:
            data: Data to filter
            data_type: Type of data (subdomain, email, ip, etc.)
        
        Returns:
            Filtered data
        """
        if data_type == "subdomain":
            return self._filter_subdomains(data)
        elif data_type == "email":
            return self._filter_emails(data)
        elif data_type == "ip":
            return self._filter_ips(data)
        elif data_type == "url":
            return self._filter_urls(data)
        else:
            return data
    
    def _filter_subdomains(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Filter invalid subdomains"""
        valid_subdomain_pattern = re.compile(
            r'^(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$'
        )
        
        filtered = []
        for item in data:
            subdomain = item.get('subdomain', item.get('domain', ''))
            
            # Skip wildcards and invalid patterns
            if '*' in subdomain or subdomain.startswith('.'):
                continue
            
            # Skip extremely long subdomains (likely false positive)
            if len(subdomain) > 253:
                continue
            
            # Validate format
            if valid_subdomain_pattern.match(subdomain):
                filtered.append(item)
        
        return filtered
    
    def _filter_emails(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Filter invalid emails"""
        email_pattern = re.compile(
            r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
        
        # Common false positive patterns
        fake_emails = [
            'noreply@', 'no-reply@', 'example@', 'test@', 
            'admin@example', 'user@example', '@example.com',
            'support@example', 'info@example'
        ]
        
        filtered = []
        for item in data:
            email = item.get('email', item.get('address', ''))
            
            # Skip fake patterns
            if any(fake in email.lower() for fake in fake_emails):
                continue
            
            # Validate format
            if email_pattern.match(email):
                filtered.append(item)
        
        return filtered
    
    def _filter_ips(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Filter private/invalid IPs"""
        filtered = []
        
        for item in data:
            ip = item.get('ip', item.get('address', ''))
            
            # Skip private ranges
            if self._is_private_ip(ip):
                continue
            
            # Skip localhost
            if ip.startswith('127.') or ip == '0.0.0.0':
                continue
            
            filtered.append(item)
        
        return filtered
    
    def _filter_urls(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Filter invalid URLs"""
        filtered = []
        
        for item in data:
            url = item.get('url', '')
            
            try:
                parsed = urlparse(url)
                # Must have scheme and netloc
                if parsed.scheme and parsed.netloc:
                    filtered.append(item)
            except:
                continue
        
        return filtered
    
    def _is_private_ip(self, ip: str) -> bool:
        """Check if IP is in private range"""
        try:
            octets = list(map(int, ip.split('.')))
            
            # 10.0.0.0/8
            if octets[0] == 10:
                return True
            
            # 172.16.0.0/12
            if octets[0] == 172 and 16 <= octets[1] <= 31:
                return True
            
            # 192.168.0.0/16
            if octets[0] == 192 and octets[1] == 168:
                return True
            
            return False
        except:
            return False
    
    def normalize_data(self, data: List[Dict[str, Any]], schema: Dict[str, str]) -> List[Dict[str, Any]]:
        """
        Normalize data fields according to schema
        
        Args:
            data: Raw data
            schema: Field mapping {old_name: new_name}
        
        Returns:
            Normalized data
        """
        normalized = []
        
        for item in data:
            new_item = {}
            for old_key, new_key in schema.items():
                if old_key in item:
                    new_item[new_key] = item[old_key]
            
            # Keep unmapped fields
            for key, value in item.items():
                if key not in schema:
                    new_item[key] = value
            
            normalized.append(new_item)
        
        return normalized
    
    def merge_results(self, *result_lists: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Merge multiple result lists and deduplicate"""
        merged = []
        for results in result_lists:
            if results:
                merged.extend(results)
        
        return self.deduplicate(merged)
