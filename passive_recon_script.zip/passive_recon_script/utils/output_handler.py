"""
Output Handler - Manages saving data to JSON and HTML formats
"""

import json
from pathlib import Path
from typing import List, Dict, Any
from datetime import datetime
from .visualizer import HTMLVisualizer
from config import Config

class OutputHandler:
    """Handle output generation for JSON and HTML formats"""
    
    def __init__(self, module_name: str):
        """
        Initialize output handler
        
        Args:
            module_name: Name of the module generating output
        """
        self.module_name = module_name
        self.output_dir = Config.OUTPUT_DIR / module_name
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def save(
        self, 
        data: List[Dict[str, Any]], 
        target: str = "",
        title: str = None,
        metadata: Dict[str, Any] = None
    ) -> Dict[str, Path]:
        """
        Save data to both JSON and HTML formats
        
        Args:
            data: List of dictionaries to save
            target: Target domain/IP
            title: Report title (defaults to module name)
            metadata: Additional metadata to include
        
        Returns:
            Dictionary with paths to saved files
        """
        if title is None:
            title = self.module_name.replace('_', ' ').title()
        
        # Prepare metadata
        full_metadata = {
            "module": self.module_name,
            "target": target,
            "timestamp": datetime.now().isoformat(),
            "record_count": len(data),
            **(metadata or {})
        }
        
        # Save JSON
        json_path = self._save_json(data, full_metadata)
        
        # Save HTML
        html_path = self._save_html(data, title, target, full_metadata)
        
        return {
            "json": json_path,
            "html": html_path
        }
    
    def _save_json(self, data: List[Dict[str, Any]], metadata: Dict[str, Any]) -> Path:
        """Save data to JSON file"""
        json_path = self.output_dir / "data.json"
        
        output = {
            "metadata": metadata,
            "results": data
        }
        
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(output, f, indent=2, ensure_ascii=False)
        
        return json_path
    
    def _save_html(
        self, 
        data: List[Dict[str, Any]], 
        title: str, 
        target: str,
        metadata: Dict[str, Any]
    ) -> Path:
        """Save data to HTML file"""
        html_path = self.output_dir / "report.html"
        
        html_content = HTMLVisualizer.generate_html_report(
            data=data,
            title=title,
            module_name=self.module_name,
            target=target,
            metadata=metadata
        )
        
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return html_path
    
    def load_json(self) -> Dict[str, Any]:
        """Load previously saved JSON data"""
        json_path = self.output_dir / "data.json"
        
        if not json_path.exists():
            return {"metadata": {}, "results": []}
        
        with open(json_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def append_results(self, new_data: List[Dict[str, Any]]):
        """Append new results to existing data"""
        existing = self.load_json()
        existing_results = existing.get("results", [])
        
        # Merge and save
        all_data = existing_results + new_data
        existing["results"] = all_data
        existing["metadata"]["record_count"] = len(all_data)
        existing["metadata"]["last_updated"] = datetime.now().isoformat()
        
        json_path = self.output_dir / "data.json"
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(existing, f, indent=2, ensure_ascii=False)
    
    @staticmethod
    def get_all_results() -> Dict[str, List[Dict[str, Any]]]:
        """Load results from all modules"""
        results = {}
        
        if not Config.OUTPUT_DIR.exists():
            return results
        
        for module_dir in Config.OUTPUT_DIR.iterdir():
            if module_dir.is_dir():
                json_file = module_dir / "data.json"
                if json_file.exists():
                    with open(json_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        results[module_dir.name] = data.get("results", [])
        
        return results
