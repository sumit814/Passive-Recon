"""
Domain Parser - Extract clean domain from various input formats
"""

import re
from urllib.parse import urlparse
import validators

class DomainParser:
    """Parse and validate domain names from various input formats"""
    
    @staticmethod
    def extract_domain(target: str) -> str:
        """
        Extract clean domain from various formats
        
        Args:
            target: Input that might be URL, domain, or IP
        
        Returns:
            Clean domain name
        
        Examples:
            https://example.com/ -> example.com
            http://sub.example.com:8080/path -> sub.example.com
            example.com/ -> example.com
            www.example.com -> example.com (optionally remove www)
        """
        if not target:
            return target
        
        # Remove whitespace
        target = target.strip()
        
        # Try to parse as URL first
        if '://' in target:
            parsed = urlparse(target)
            domain = parsed.netloc or parsed.path
            # Remove port if present
            domain = domain.split(':')[0]
        else:
            # Remove trailing slashes
            domain = target.rstrip('/')
            # Remove port if present
            domain = domain.split(':')[0]
        
        # Remove www. prefix (optional - you can keep it if needed)
        # if domain.startswith('www.'):
        #     domain = domain[4:]
        
        return domain
    
    @staticmethod
    def is_valid_domain(domain: str) -> bool:
        """
        Check if domain is valid
        
        Args:
            domain: Domain to validate
        
        Returns:
            True if valid domain
        """
        if not domain:
            return False
        
        # Use validators library
        return validators.domain(domain) is True
    
    @staticmethod
    def is_valid_ip(ip: str) -> bool:
        """
        Check if input is valid IP
        
        Args:
            ip: IP address to validate
        
        Returns:
            True if valid IP
        """
        if not ip:
            return False
        
        return validators.ipv4(ip) is True or validators.ipv6(ip) is True
    
    @staticmethod
    def clean_target(target: str) -> str:
        """
        Clean and validate target
        
        Args:
            target: Raw target input
        
        Returns:
            Cleaned target
        
        Raises:
            ValueError: If target is invalid
        """
        # Extract domain
        domain = DomainParser.extract_domain(target)
        
        # Validate
        if DomainParser.is_valid_domain(domain):
            return domain
        elif DomainParser.is_valid_ip(domain):
            return domain
        else:
            # Return as-is, let individual modules handle it
            return domain
