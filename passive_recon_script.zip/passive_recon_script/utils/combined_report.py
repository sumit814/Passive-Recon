"""
Combined Report Generator
Combines all module outputs into a single comprehensive report
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any
from jinja2 import Template

class CombinedReportGenerator:
    """Generate combined reports from all module outputs"""
    
    @staticmethod
    def generate_combined_report(target: str, output_dir: Path) -> Dict[str, str]:
        """
        Generate combined JSON and HTML reports from all modules
        
        Args:
            target: Target domain/IP
            output_dir: Base output directory
        
        Returns:
            Dict with paths to combined reports
        """
        # Collect all module data
        combined_data = CombinedReportGenerator._collect_all_data(target, output_dir)
        
        # Create combined directory
        combined_dir = output_dir / "combined_report"
        combined_dir.mkdir(parents=True, exist_ok=True)
        
        # Generate JSON report
        json_path = combined_dir / "all_results.json"
        CombinedReportGenerator._save_json(combined_data, json_path)
        
        # Generate HTML report
        html_path = combined_dir / "all_results.html"
        CombinedReportGenerator._save_html(combined_data, html_path)
        
        return {
            'json': str(json_path),
            'html': str(html_path)
        }
    
    @staticmethod
    def _collect_all_data(target: str, output_dir: Path) -> Dict[str, Any]:
        """Collect data from all module outputs"""
        combined = {
            'target': target,
            'scan_time': datetime.now().isoformat(),
            'total_results': 0,
            'modules_executed': 0,
            'modules_with_results': 0,
            'modules': {}
        }
        
        # List of all possible module directories
        module_dirs = [
            'subdomain_enumeration',
            'certificate_search',
            'shodan_search',
            'github_intelligence',
            'email_harvesting',
            'virustotal_lookup',
            'urlscan_lookup',
            'dns_intelligence',
            'whois_lookup',
            'zoomeye_search',
            'leakix_search',
            'greynoise_lookup',
            'vulners_lookup',
            'fullhunt_search',
            'publicwww_search',
            'wayback_search',
            'dnslytics_lookup',
            'builtwith_lookup',
            'otx_lookup',
            'hackertarget_lookup',
            'social_media_enumeration',
            'port_enumeration'
        ]
        
        for module_dir in module_dirs:
            json_file = output_dir / module_dir / "data.json"
            
            if json_file.exists():
                try:
                    with open(json_file, 'r') as f:
                        module_data = json.load(f)
                    
                    module_name = module_data.get('metadata', {}).get('module', module_dir)
                    results = module_data.get('results', [])
                    result_count = len(results)
                    
                    combined['modules'][module_name] = {
                        'result_count': result_count,
                        'results': results,
                        'metadata': module_data.get('metadata', {}),
                        'scan_info': module_data.get('scan_info', {})
                    }
                    
                    combined['modules_executed'] += 1
                    combined['total_results'] += result_count
                    
                    if result_count > 0:
                        combined['modules_with_results'] += 1
                        
                except Exception as e:
                    print(f"[!] Error reading {module_dir}: {str(e)}")
        
        return combined
    
    @staticmethod
    def _save_json(data: Dict[str, Any], path: Path):
        """Save combined JSON report"""
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
    
    @staticmethod
    def _save_html(data: Dict[str, Any], path: Path):
        """Save combined HTML report"""
        
        html_template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Combined Reconnaissance Report - {{ target }}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            color: #333;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .header .target {
            font-size: 1.5em;
            opacity: 0.9;
            margin-bottom: 20px;
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            padding: 30px;
            background: #f8f9fa;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card h3 {
            color: #667eea;
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .stat-card p {
            color: #666;
            font-size: 1em;
        }
        
        .content {
            padding: 40px;
        }
        
        .module-section {
            margin-bottom: 40px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            overflow: hidden;
            background: white;
        }
        
        .module-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
        }
        
        .module-header:hover {
            background: linear-gradient(135deg, #5568d3 0%, #6a3f8f 100%);
        }
        
        .module-header h2 {
            font-size: 1.5em;
        }
        
        .result-badge {
            background: rgba(255,255,255,0.2);
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 1.1em;
            font-weight: bold;
        }
        
        .module-content {
            padding: 20px;
            max-height: 600px;
            overflow-y: auto;
        }
        
        .results-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        
        .results-table th {
            background: #667eea;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            position: sticky;
            top: 0;
        }
        
        .results-table td {
            padding: 12px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .results-table tr:hover {
            background: #f8f9fa;
        }
        
        .no-results {
            padding: 30px;
            text-align: center;
            color: #999;
            font-style: italic;
        }
        
        .footer {
            background: #f8f9fa;
            padding: 20px;
            text-align: center;
            color: #666;
            border-top: 2px solid #e0e0e0;
        }
        
        .collapse-btn {
            background: none;
            border: none;
            color: white;
            font-size: 1.5em;
            cursor: pointer;
            transition: transform 0.3s;
        }
        
        .collapse-btn:hover {
            transform: rotate(180deg);
        }
        
        .summary-section {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 30px;
            margin-bottom: 30px;
            border-radius: 10px;
        }
        
        .summary-section h2 {
            margin-bottom: 20px;
        }
        
        .module-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 10px;
        }
        
        .module-item {
            background: rgba(255,255,255,0.2);
            padding: 10px;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
        }
        
        @media print {
            body {
                background: white;
            }
            .module-content {
                max-height: none;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎯 Combined Reconnaissance Report</h1>
            <div class="target">Target: {{ target }}</div>
            <div>Scan completed: {{ scan_time }}</div>
        </div>
        
        <div class="stats">
            <div class="stat-card">
                <h3>{{ total_results }}</h3>
                <p>Total Results</p>
            </div>
            <div class="stat-card">
                <h3>{{ modules_executed }}</h3>
                <p>Modules Executed</p>
            </div>
            <div class="stat-card">
                <h3>{{ modules_with_results }}</h3>
                <p>Successful Modules</p>
            </div>
            <div class="stat-card">
                <h3>{{ module_count }}</h3>
                <p>Total Modules</p>
            </div>
        </div>
        
        <div class="content">
            <div class="summary-section">
                <h2>📊 Module Summary</h2>
                <div class="module-list">
                    {% for module_name, module_data in modules.items() %}
                    <div class="module-item">
                        <span>{{ module_name }}</span>
                        <span><strong>{{ module_data.result_count }}</strong> results</span>
                    </div>
                    {% endfor %}
                </div>
            </div>
            
            {% for module_name, module_data in modules.items() %}
            <div class="module-section">
                <div class="module-header" onclick="toggleModule('{{ loop.index }}')">
                    <h2>{{ module_name }}</h2>
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <span class="result-badge">{{ module_data.result_count }} results</span>
                        <button class="collapse-btn" id="btn-{{ loop.index }}">▼</button>
                    </div>
                </div>
                <div class="module-content" id="content-{{ loop.index }}">
                    {% if module_data.result_count > 0 %}
                        <table class="results-table">
                            <thead>
                                <tr>
                                    {% set first_result = module_data.results[0] %}
                                    {% for key in first_result.keys() %}
                                    <th>{{ key|title }}</th>
                                    {% endfor %}
                                </tr>
                            </thead>
                            <tbody>
                                {% for result in module_data.results %}
                                <tr>
                                    {% for key, value in result.items() %}
                                    <td>{{ value }}</td>
                                    {% endfor %}
                                </tr>
                                {% endfor %}
                            </tbody>
                        </table>
                    {% else %}
                        <div class="no-results">No results found</div>
                    {% endif %}
                </div>
            </div>
            {% endfor %}
        </div>
        
        <div class="footer">
            <p><strong>Passive Reconnaissance Framework v1.0</strong></p>
            <p>Generated on {{ scan_time }}</p>
            <p>This report combines results from {{ modules_executed }} reconnaissance modules</p>
        </div>
    </div>
    
    <script>
        function toggleModule(index) {
            const content = document.getElementById('content-' + index);
            const btn = document.getElementById('btn-' + index);
            
            if (content.style.display === 'none') {
                content.style.display = 'block';
                btn.textContent = '▼';
            } else {
                content.style.display = 'none';
                btn.textContent = '▶';
            }
        }
        
        // Start with first 3 modules expanded, rest collapsed
        window.onload = function() {
            const moduleCount = {{ modules|length }};
            for (let i = 4; i <= moduleCount; i++) {
                const content = document.getElementById('content-' + i);
                const btn = document.getElementById('btn-' + i);
                if (content) {
                    content.style.display = 'none';
                    btn.textContent = '▶';
                }
            }
        };
    </script>
</body>
</html>
        """
        
        template = Template(html_template)
        html_content = template.render(
            target=data['target'],
            scan_time=data['scan_time'],
            total_results=data['total_results'],
            modules_executed=data['modules_executed'],
            modules_with_results=data['modules_with_results'],
            module_count=len(data['modules']),
            modules=data['modules']
        )
        
        with open(path, 'w') as f:
            f.write(html_content)
