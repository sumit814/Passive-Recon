"""
Google Search CAPTCHA Avoidance Utility
Implements techniques to avoid triggering Google CAPTCHA during automated searches
"""

import time
import random
import hashlib
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import requests


class GoogleSearchCAPTCHAAvoidance:
    """
    Comprehensive CAPTCHA avoidance for Google searches
    
    Techniques implemented:
    1. Request throttling with intelligent delays
    2. User-Agent rotation
    3. Query result caching
    4. Exponential backoff
    5. Session management
    6. Query optimization
    """
    
    def __init__(self):
        # Timing controls
        self.min_delay = 5  # Minimum seconds between requests
        self.max_delay = 15  # Maximum seconds between requests
        self.last_request_time = 0
        self.request_count = 0
        self.requests_per_session = 3  # Max requests before long cooldown
        self.session_cooldown = 60  # Seconds to wait after session limit
        
        # Cache management
        self.cache = {}
        self.cache_ttl = 3600  # Cache results for 1 hour
        
        # User-Agent rotation pool
        self.user_agents = [
            # Chrome on Windows
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            
            # Chrome on Mac
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            
            # Firefox on Windows
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
            
            # Firefox on Mac
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:122.0) Gecko/20100101 Firefox/122.0',
            
            # Safari on Mac
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
            
            # Edge on Windows
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0'
        ]
        
        # Session object with connection pooling
        self.session = requests.Session()
        self._update_session_headers()
        
        # CAPTCHA detection
        self.captcha_encountered = False
        self.captcha_count = 0
    
    def _update_session_headers(self):
        """Update session with rotated headers"""
        self.session.headers.update({
            'User-Agent': random.choice(self.user_agents),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Cache-Control': 'max-age=0'
        })
    
    def smart_delay(self):
        """Implement intelligent delay with human-like randomness"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        # Calculate base delay with randomness
        base_delay = random.uniform(self.min_delay, self.max_delay)
        
        # Add extra delay based on request count (fatigue simulation)
        fatigue_factor = min(self.request_count * 0.5, 10)
        required_delay = base_delay + fatigue_factor
        
        if time_since_last < required_delay:
            sleep_time = required_delay - time_since_last
            # Add micro-jitter for more human-like behavior
            jitter = random.uniform(0, 2)
            sleep_time += jitter
            
            print(f"  [*] Smart delay: {sleep_time:.1f}s (avoiding CAPTCHA)")
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
        self.request_count += 1
        
        # Session cooldown after batch of requests
        if self.request_count % self.requests_per_session == 0:
            print(f"  [*] Session cooldown: {self.session_cooldown}s (CAPTCHA prevention)")
            time.sleep(self.session_cooldown)
            
            # Rotate User-Agent for next session
            self._update_session_headers()
            print(f"  [*] User-Agent rotated")
    
    def check_cache(self, query: str) -> Optional[Dict]:
        """Check if query results are cached"""
        cache_key = hashlib.md5(query.encode()).hexdigest()
        
        if cache_key in self.cache:
            cached_data, timestamp = self.cache[cache_key]
            # Check if cache is still valid
            if time.time() - timestamp < self.cache_ttl:
                print(f"  [✓] Using cached results (age: {int(time.time() - timestamp)}s)")
                return cached_data
            else:
                # Cache expired
                del self.cache[cache_key]
        
        return None
    
    def update_cache(self, query: str, data: Dict):
        """Update cache with new query results"""
        cache_key = hashlib.md5(query.encode()).hexdigest()
        self.cache[cache_key] = (data, time.time())
    
    def detect_captcha(self, response: requests.Response) -> bool:
        """Detect if CAPTCHA was triggered"""
        if not response:
            return False
        
        # Common CAPTCHA indicators
        captcha_indicators = [
            'captcha',
            'recaptcha',
            'unusual traffic',
            'automated queries',
            'robot',
            '/sorry/',
            'http://www.google.com/sorry/'
        ]
        
        content = response.text.lower()
        
        for indicator in captcha_indicators:
            if indicator in content:
                return True
        
        # Check response code
        if response.status_code == 429:
            return True
        
        return False
    
    def handle_captcha_detection(self):
        """Handle when CAPTCHA is detected"""
        self.captcha_encountered = True
        self.captcha_count += 1
        
        print()
        print("  [!!!] ═══════════════════════════════════════════════")
        print("  [!!!] CAPTCHA PROTECTION DETECTED")
        print("  [!!!] ═══════════════════════════════════════════════")
        print(f"  [!!!] CAPTCHA encountered {self.captcha_count} time(s)")
        print("  [!!!] Google has blocked automated queries")
        print("  [!!!] ")
        print("  [!!!] Recommended actions:")
        print("  [!!!] 1. Stop making requests immediately")
        print("  [!!!] 2. Wait at least 30-60 minutes")
        print("  [!!!] 3. Use alternative search methods")
        print("  [!!!] 4. Consider using API-based approaches")
        print("  [!!!] ")
        print("  [!!!] Script will NOT generate fake results")
        print("  [!!!] ═══════════════════════════════════════════════")
        print()
        
        # Implement exponential backoff
        backoff_time = min(300, 60 * (2 ** (self.captcha_count - 1)))
        print(f"  [*] Waiting {backoff_time}s before continuing...")
        time.sleep(backoff_time)
    
    def optimize_query(self, query: str, target: str) -> str:
        """Optimize query to reduce repeated searches"""
        # Remove redundant terms
        optimized = query.strip()
        
        # Limit query length
        if len(optimized) > 100:
            optimized = optimized[:100]
        
        # Add site-specific operator to narrow results
        if 'site:' not in optimized:
            optimized = f'site:github.com {optimized}'
        
        return optimized
    
    def safe_google_search(self, query: str, max_results: int = 10) -> List[Dict[str, Any]]:
        """
        Perform Google search with CAPTCHA avoidance
        
        IMPORTANT: This method is NOT recommended.
        Use native APIs (GitHub API, etc.) instead.
        """
        print()
        print("  [⚠] WARNING: Google search is NOT recommended")
        print("  [⚠] High risk of CAPTCHA triggering")
        print("  [⚠] Use native APIs instead (GitHub API, etc.)")
        print()
        
        # Check cache first
        cached = self.check_cache(query)
        if cached:
            return cached
        
        # Check if CAPTCHA was previously encountered
        if self.captcha_encountered and self.captcha_count >= 2:
            print("  [!!!] CAPTCHA previously encountered multiple times")
            print("  [!!!] Skipping Google search to avoid further blocks")
            return []
        
        # Implement smart delay
        self.smart_delay()
        
        # Prepare search URL (custom search or scraping alternative)
        # Note: Direct Google scraping will trigger CAPTCHA
        # This is a placeholder - should use Google Custom Search API
        
        print("  [!!!] Google web scraping DISABLED due to CAPTCHA risk")
        print("  [!!!] Please use:")
        print("  [!!!] - GitHub native API")
        print("  [!!!] - Google Custom Search API")
        print("  [!!!] - Alternative search engines")
        
        return []
    
    def get_recommendations(self) -> Dict[str, List[str]]:
        """Get recommendations for CAPTCHA avoidance"""
        return {
            'primary_recommendations': [
                'Use native APIs (GitHub API, etc.) - CAPTCHA-free',
                'Implement 5-15 second delays between requests',
                'Rotate User-Agent headers',
                'Cache search results',
                'Limit requests to 3-5 per session',
                'Take 60+ second breaks between sessions'
            ],
            'api_alternatives': [
                'GitHub API - https://api.github.com',
                'Google Custom Search API - https://developers.google.com/custom-search',
                'Bing Web Search API - https://azure.microsoft.com/en-us/services/cognitive-services/bing-web-search-api/',
                'DuckDuckGo API - https://duckduckgo.com/api'
            ],
            'tools_without_captcha': [
                'GitHub Advanced Search - https://github.com/search/advanced',
                'GitDorker - https://github.com/obheda12/GitDorker',
                'TruffleHog - https://github.com/trufflesecurity/trufflehog',
                'GitLeaks - https://github.com/zricethezav/gitleaks'
            ],
            'if_captcha_encountered': [
                'Stop all requests immediately',
                'Wait 30-60 minutes before retry',
                'Switch to API-based methods',
                'Use different IP address if possible',
                'Never try to bypass CAPTCHA programmatically'
            ]
        }
    
    def reset_session(self):
        """Reset session to clear state"""
        self.request_count = 0
        self.last_request_time = 0
        self.session.close()
        self.session = requests.Session()
        self._update_session_headers()
        print("  [*] Session reset complete")


# Global instance
captcha_avoider = GoogleSearchCAPTCHAAvoidance()
