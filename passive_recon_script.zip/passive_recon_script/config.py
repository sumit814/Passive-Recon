"""
Configuration Manager for Passive Recon Framework
Handles API keys and global settings
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Config:
    """Configuration class for API keys and settings"""
    
    # Base directories
    BASE_DIR = Path(__file__).parent
    OUTPUT_DIR = BASE_DIR / "outputs"
    TEMPLATE_DIR = BASE_DIR / "templates"
    
    # Internet Scanners
    SHODAN_API_KEY = os.getenv("SHODAN_API_KEY", "myNIM1yiCvuP94poVG2BFWnantnrCwXF")
    CENSYS_API_ID = os.getenv("CENSYS_API_ID", "censys_GohYZXLi_HVy3Mct4CkZFKbYQYvYzSpkF")
    CENSYS_API_SECRET = os.getenv("CENSYS_API_SECRET", "")
    ZOOMEYE_API_KEY = os.getenv("ZOOMEYE_API_KEY", "6F020722-D6fD-7D558-3C90-e1d794f470e")
    BINARYEDGE_API_KEY = os.getenv("BINARYEDGE_API_KEY", "")
    FOFA_EMAIL = os.getenv("FOFA_EMAIL", "")
    FOFA_API_KEY = os.getenv("FOFA_API_KEY", "")
    NETLAS_API_KEY = os.getenv("NETLAS_API_KEY", "")
    LEAKIX_API_KEY = os.getenv("LEAKIX_API_KEY", "")
    ONYPHE_API_KEY = os.getenv("ONYPHE_API_KEY", "")
    GREYNOISE_API_KEY = os.getenv("GREYNOISE_API_KEY", "")
    
    # Vulnerability & Threat Intel
    VULNERS_API_KEY = os.getenv("VULNERS_API_KEY", "X2VMFT9X08RE16IT7ZDFLLL80SUR64LLZW4U58Z8DPN37B7WTS2S320KSJ98K65B")
    PULSEDIVE_API_KEY = os.getenv("PULSEDIVE_API_KEY", "")
    SOCRADAR_API_KEY = os.getenv("SOCRADAR_API_KEY", "")
    FULLHUNT_API_KEY = os.getenv("FULLHUNT_API_KEY", "")
    ALIENVAULT_API_KEY = os.getenv("ALIENVAULT_API_KEY", "")
    
    # DNS & Subdomain Intelligence
    SECURITYTRAILS_API_KEY = os.getenv("SECURITYTRAILS_API_KEY", "")
    VIRUSTOTAL_API_KEY = os.getenv("VIRUSTOTAL_API_KEY", "")
    WHOISXML_API_KEY = os.getenv("WHOISXML_API_KEY", "")
    
    # Email & People Intelligence
    HUNTER_API_KEY = os.getenv("HUNTER_API_KEY", "")
    INTELX_API_KEY = os.getenv("INTELX_API_KEY", "c7b9025b-f487-4dd7-85a3-106f7982e8d2")
    
    # Code & Repository Intelligence
    GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "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")
    PUBLICWWW_API_KEY = os.getenv("PUBLICWWW_API_KEY", "")
    
    # Web Intelligence
    URLSCAN_API_KEY = os.getenv("URLSCAN_API_KEY", "")
    BUILTWITH_API_KEY = os.getenv("BUILTWITH_API_KEY", "")
    
    # Network Intelligence
    WIGLE_API_NAME = os.getenv("WIGLE_API_NAME", "")
    WIGLE_API_TOKEN = os.getenv("WIGLE_API_TOKEN", "")
    IPINFO_TOKEN = os.getenv("IPINFO_TOKEN", "")
    
    # IP Reputation & Threat Intelligence
    ABUSEIPDB_API_KEY = os.getenv("ABUSEIPDB_API_KEY", "1f19eb1ee9c4b63f839a50c690c5ad33d7f0cb9ca93a144b395494811d9a64a9a5f97cbe689a545f")
    
    # Breach & Leak Databases
    HIBP_API_KEY = os.getenv("HIBP_API_KEY", "")
    DEHASHED_API_KEY = os.getenv("DEHASHED_API_KEY", "")
    DEHASHED_EMAIL = os.getenv("DEHASHED_EMAIL", "")
    LEAKCHECK_API_KEY = os.getenv("LEAKCHECK_API_KEY", "")
    
    # HTTP Settings
    TIMEOUT = 30
    MAX_RETRIES = 3
    USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    
    # Module execution settings
    MODULE_TIMEOUT = 120  # Maximum seconds to wait for a module to complete
    
    @classmethod
    def ensure_directories(cls):
        """Ensure all required directories exist"""
        cls.OUTPUT_DIR.mkdir(exist_ok=True)
        cls.TEMPLATE_DIR.mkdir(exist_ok=True)
    
    @classmethod
    def get_api_keys_status(cls):
        """Return status of configured API keys"""
        keys = {
            "Shodan": bool(cls.SHODAN_API_KEY),
            "Censys": bool(cls.CENSYS_API_ID and cls.CENSYS_API_SECRET),
            "ZoomEye": bool(cls.ZOOMEYE_API_KEY),
            "BinaryEdge": bool(cls.BINARYEDGE_API_KEY),
            "FOFA": bool(cls.FOFA_EMAIL and cls.FOFA_API_KEY),
            "Netlas": bool(cls.NETLAS_API_KEY),
            "LeakIX": bool(cls.LEAKIX_API_KEY),
            "Onyphe": bool(cls.ONYPHE_API_KEY),
            "GreyNoise": bool(cls.GREYNOISE_API_KEY),
            "Vulners": bool(cls.VULNERS_API_KEY),
            "PulseDive": bool(cls.PULSEDIVE_API_KEY),
            "SecurityTrails": bool(cls.SECURITYTRAILS_API_KEY),
            "VirusTotal": bool(cls.VIRUSTOTAL_API_KEY),
            "Hunter.io": bool(cls.HUNTER_API_KEY),
            "IntelX": bool(cls.INTELX_API_KEY),
            "GitHub": bool(cls.GITHUB_TOKEN),
            "URLScan": bool(cls.URLSCAN_API_KEY),
            "WiGLE": bool(cls.WIGLE_API_NAME and cls.WIGLE_API_TOKEN),
            "AbuseIPDB": bool(cls.ABUSEIPDB_API_KEY),
            "HaveIBeenPwned": bool(cls.HIBP_API_KEY),
            "DeHashed": bool(cls.DEHASHED_API_KEY and cls.DEHASHED_EMAIL),
            "LeakCheck": bool(cls.LEAKCHECK_API_KEY),
        }
        return keys
