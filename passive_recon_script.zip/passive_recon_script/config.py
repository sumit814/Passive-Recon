"""
Configuration Manager for Passive Recon Framework
Handles API keys and global settings
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Config:
    """Configuration class for API keys and settings"""
    
    # Base directories
    BASE_DIR = Path(__file__).parent
    OUTPUT_DIR = BASE_DIR / "outputs"
    TEMPLATE_DIR = BASE_DIR / "templates"
    
    # Internet Scanners
    SHODAN_API_KEY = os.getenv("SHODAN_API_KEY", "")
    CENSYS_API_ID = os.getenv("CENSYS_API_ID", "")
    CENSYS_API_SECRET = os.getenv("CENSYS_API_SECRET", "")
    ZOOMEYE_API_KEY = os.getenv("ZOOMEYE_API_KEY", "")
    BINARYEDGE_API_KEY = os.getenv("BINARYEDGE_API_KEY", "")
    FOFA_EMAIL = os.getenv("FOFA_EMAIL", "")
    FOFA_API_KEY = os.getenv("FOFA_API_KEY", "")
    NETLAS_API_KEY = os.getenv("NETLAS_API_KEY", "")
    LEAKIX_API_KEY = os.getenv("LEAKIX_API_KEY", "")
    ONYPHE_API_KEY = os.getenv("ONYPHE_API_KEY", "")
    GREYNOISE_API_KEY = os.getenv("GREYNOISE_API_KEY", "")
    
    # Vulnerability & Threat Intel
    VULNERS_API_KEY = os.getenv("VULNERS_API_KEY", "")
    PULSEDIVE_API_KEY = os.getenv("PULSEDIVE_API_KEY", "")
    SOCRADAR_API_KEY = os.getenv("SOCRADAR_API_KEY", "")
    FULLHUNT_API_KEY = os.getenv("FULLHUNT_API_KEY", "")
    ALIENVAULT_API_KEY = os.getenv("ALIENVAULT_API_KEY", "")
    
    # DNS & Subdomain Intelligence
    SECURITYTRAILS_API_KEY = os.getenv("SECURITYTRAILS_API_KEY", "")
    VIRUSTOTAL_API_KEY = os.getenv("VIRUSTOTAL_API_KEY", "")
    WHOISXML_API_KEY = os.getenv("WHOISXML_API_KEY", "")
    
    # Email & People Intelligence
    HUNTER_API_KEY = os.getenv("HUNTER_API_KEY", "")
    INTELX_API_KEY = os.getenv("INTELX_API_KEY", "")
    
    # Code & Repository Intelligence
    GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")
    PUBLICWWW_API_KEY = os.getenv("PUBLICWWW_API_KEY", "")
    
    # Web Intelligence
    URLSCAN_API_KEY = os.getenv("URLSCAN_API_KEY", "")
    BUILTWITH_API_KEY = os.getenv("BUILTWITH_API_KEY", "")
    
    # Network Intelligence
    WIGLE_API_NAME = os.getenv("WIGLE_API_NAME", "")
    WIGLE_API_TOKEN = os.getenv("WIGLE_API_TOKEN", "")
    IPINFO_TOKEN = os.getenv("IPINFO_TOKEN", "")
    
    # HTTP Settings
    TIMEOUT = 30
    MAX_RETRIES = 3
    USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    
    # Module execution settings
    MODULE_TIMEOUT = 120  # Maximum seconds to wait for a module to complete
    
    @classmethod
    def ensure_directories(cls):
        """Ensure all required directories exist"""
        cls.OUTPUT_DIR.mkdir(exist_ok=True)
        cls.TEMPLATE_DIR.mkdir(exist_ok=True)
    
    @classmethod
    def get_api_keys_status(cls):
        """Return status of configured API keys"""
        keys = {
            "Shodan": bool(cls.SHODAN_API_KEY),
            "Censys": bool(cls.CENSYS_API_ID and cls.CENSYS_API_SECRET),
            "ZoomEye": bool(cls.ZOOMEYE_API_KEY),
            "BinaryEdge": bool(cls.BINARYEDGE_API_KEY),
            "FOFA": bool(cls.FOFA_EMAIL and cls.FOFA_API_KEY),
            "Netlas": bool(cls.NETLAS_API_KEY),
            "LeakIX": bool(cls.LEAKIX_API_KEY),
            "Onyphe": bool(cls.ONYPHE_API_KEY),
            "GreyNoise": bool(cls.GREYNOISE_API_KEY),
            "Vulners": bool(cls.VULNERS_API_KEY),
            "PulseDive": bool(cls.PULSEDIVE_API_KEY),
            "SecurityTrails": bool(cls.SECURITYTRAILS_API_KEY),
            "VirusTotal": bool(cls.VIRUSTOTAL_API_KEY),
            "Hunter.io": bool(cls.HUNTER_API_KEY),
            "IntelX": bool(cls.INTELX_API_KEY),
            "GitHub": bool(cls.GITHUB_TOKEN),
            "URLScan": bool(cls.URLSCAN_API_KEY),
            "WiGLE": bool(cls.WIGLE_API_NAME and cls.WIGLE_API_TOKEN),
        }
        return keys
