# API Keys Setup Guide

This guide explains which API keys are **required**, **optional**, and **recommended** for the Passive Reconnaissance Framework.

## 📋 Current API Keys Status

Run `python main.py apikeys` to check your current configuration.

---

## 🔴 **CRITICAL - Keys Needed for New Enhanced Modules**

These API keys are **required** for the new security analysis features:

### 1. **AbuseIPDB** (IP Reputation Module)
- **Purpose**: IP threat intelligence & abuse reputation
- **Cost**: Free tier available (1,000 checks/day)
- **Sign up**: https://www.abuseipdb.com/register
- **Documentation**: https://docs.abuseipdb.com/
- **How to get**:
  1. Create account
  2. Go to Account → API
  3. Generate API key
  4. Add to `.env`: `ABUSEIPDB_API_KEY=your_key_here`

### 2. **HaveIBeenPwned (HIBP)** (Email Leak Check Module)
- **Purpose**: Check emails for data breaches
- **Cost**: Paid ($3.50/month minimum)
- **Sign up**: https://haveibeenpwned.com/API/Key
- **Documentation**: https://haveibeenpwned.com/API/v3
- **How to get**:
  1. Purchase API key via Pwned Passwords
  2. Receive key via email
  3. Add to `.env`: `HIBP_API_KEY=your_key_here`

### 3. **DeHashed** (Email Leak Check Module - Optional but Recommended)
- **Purpose**: Search leaked credentials database
- **Cost**: Paid (credits-based, ~$1-2 per 100 queries)
- **Sign up**: https://dehashed.com/register
- **Documentation**: https://dehashed.com/docs
- **How to get**:
  1. Create account
  2. Purchase credits
  3. Get API key from dashboard
  4. Add to `.env`: 
     - `DEHASHED_API_KEY=your_key_here`
     - `DEHASHED_EMAIL=your_account_email`

### 4. **LeakCheck** (Email Leak Check Module - Optional)
- **Purpose**: Leak database searches
- **Cost**: Paid (~$2/month for basic)
- **Sign up**: https://leakcheck.io/api
- **Documentation**: https://leakcheck.io/api
- **How to get**:
  1. Create account
  2. Subscribe to API plan
  3. Get API key from dashboard
  4. Add to `.env`: `LEAKCHECK_API_KEY=your_key_here`

---

## ✅ **ALREADY CONFIGURED** (Based on your current setup)

These keys are already set up and working:

- ✓ **Shodan** - Internet-connected device search
- ✓ **Censys** - SSL/TLS certificate & host search
- ✓ **ZoomEye** - Cyberspace search engine
- ✓ **LeakIX** - Exposed services & data leaks
- ✓ **GreyNoise** - Internet noise & threat intel (used in IP reputation)
- ✓ **Vulners** - Vulnerability intelligence
- ✓ **SecurityTrails** - DNS & subdomain intelligence
- ✓ **VirusTotal** - Multi-engine file & URL analysis (used in IP reputation)
- ✓ **Hunter.io** - Email discovery
- ✓ **IntelX** - OSINT search engine
- ✓ **GitHub** - Code & repository search
- ✓ **URLScan** - Website analysis & screenshots

---

## 🟡 **OPTIONAL - Not Configured Yet**

These services are optional and provide additional coverage:

### Internet Scanners
- **BinaryEdge** - https://www.binaryedge.io/
- **FOFA** - https://fofa.info/
- **Netlas** - https://netlas.io/
- **Onyphe** - https://www.onyphe.io/
- **PulseDive** - https://pulsedive.com/

### Network Intelligence
- **WiGLE** - https://wigle.net/

---

## 📊 **Module-to-API Mapping**

### IP Reputation Module (`iprep`)
**Required APIs:**
- ✓ VirusTotal (configured)
- ✓ GreyNoise (configured)
- ❌ AbuseIPDB (NOT configured) - **CRITICAL**

**Result:** Module will run with limited data. AbuseIPDB provides critical abuse scores.

### SSL/TLS Analysis Module (`ssl`)
**Required APIs:** None (uses direct TLS connection)
**Result:** ✅ Fully functional

### Email Leak Check Module (`leakcheck`)
**Required APIs:**
- ❌ HaveIBeenPwned (NOT configured) - **CRITICAL**
- ❌ DeHashed (NOT configured) - Recommended
- ❌ LeakCheck (NOT configured) - Optional

**Result:** Module will not return meaningful results without at least HIBP.

---

## 🚀 **Quick Setup Instructions**

### Step 1: Copy example environment file
```bash
cp .env.example .env
```

### Step 2: Edit .env file
```bash
nano .env
# or
vim .env
```

### Step 3: Add your API keys
Replace `your_xxx_key_here` with actual keys:

```bash
# IP REPUTATION & THREAT INTELLIGENCE
ABUSEIPDB_API_KEY=your_abuseipdb_key_here

# BREACH & LEAK DATABASES
HIBP_API_KEY=your_haveibeenpwned_key_here
DEHASHED_API_KEY=your_dehashed_key_here
DEHASHED_EMAIL=your_dehashed_email_here
LEAKCHECK_API_KEY=your_leakcheck_key_here
```

### Step 4: Verify configuration
```bash
python main.py apikeys
```

---

## 💰 **Cost Summary**

### Free Services
- AbuseIPDB (1,000 checks/day free tier)
- VirusTotal (configured - 4 requests/minute)
- GreyNoise (configured - community tier)
- All SSL/TLS analysis (no API needed)

### Paid Services
- **HaveIBeenPwned**: $3.50/month minimum (~$42/year)
- **DeHashed**: ~$1-2 per 100 queries (pay-as-you-go)
- **LeakCheck**: ~$2/month for basic plan

### Recommended Minimum Investment
**$3.50/month** for HIBP gives you email leak checking capability.

---

## 🎯 **Priority Recommendations**

### Priority 1 (High)
1. **AbuseIPDB** (FREE) - Essential for IP reputation analysis
2. **HaveIBeenPwned** ($3.50/mo) - Most comprehensive breach database

### Priority 2 (Medium)
3. **DeHashed** (pay-per-use) - Additional breach coverage
4. **LeakCheck** ($2/mo) - Extra leak database coverage

### Priority 3 (Low)
- Other optional services (BinaryEdge, FOFA, etc.) - Only if you need additional coverage

---

## 🧪 **Testing New Modules**

### Test IP Reputation Module
```bash
python main.py run example.com -m iprep
```

### Test SSL/TLS Analysis Module (No API key needed)
```bash
python main.py run example.com -m ssl
```

### Test Email Leak Check Module
```bash
# First harvest emails
python main.py run example.com -m email

# Then check for leaks
python main.py run example.com -m leakcheck
```

---

## ⚠️ **Important Notes**

### Rate Limits
- **AbuseIPDB Free**: 1,000 checks/day
- **HIBP**: 1,500 requests per API key daily
- **VirusTotal Free**: 4 requests/minute
- **GreyNoise Community**: Limited queries/day

### Best Practices
1. **Start with free tiers** - Test before committing to paid plans
2. **Cache results** - The script automatically deduplicates to save API calls
3. **Respect rate limits** - Built-in retry logic handles rate limiting
4. **Monitor usage** - Check your API dashboards regularly

### Privacy & Security
- **Never commit `.env` file** to version control
- **Keep API keys secure** - They're like passwords
- **Use read-only keys** when available
- **Rotate keys periodically**

---

## 🆘 **Troubleshooting**

### API Key Not Working
1. Check if key is properly set in `.env`
2. Verify no extra spaces or quotes
3. Confirm API key is active on provider's dashboard
4. Check rate limits haven't been exceeded

### Module Returns No Results
- Check API key status: `python main.py apikeys`
- Verify internet connectivity
- Check provider's status page for outages
- Review error messages in console output

### Rate Limit Errors
- Wait and retry later
- Upgrade to paid tier if needed
- The script automatically handles rate limiting with exponential backoff

---

## 📚 **Additional Resources**

- Official Documentation: See `README.md`
- Quick Start Guide: See `QUICKSTART.md`
- Troubleshooting: See `TROUBLESHOOTING.md`
- Module Examples: See `EXAMPLES.md`

---

## 📞 **Support**

For issues related to:
- **API Keys**: Contact the respective provider
- **Script Issues**: Check existing documentation or create an issue
- **General Questions**: Review the documentation first

---

**Last Updated**: December 2024
