# ✅ Installation & Usage Checklist

Complete step-by-step checklist to get your Passive Recon Framework up and running.

## 📦 Pre-Installation Checklist

- [ ] Python 3.8 or higher installed
  ```bash
  python --version  # Should show 3.8+
  ```

- [ ] pip package manager available
  ```bash
  pip --version
  ```

- [ ] whois command-line tool installed (for WHOIS module)
  ```bash
  # Linux
  sudo apt-get install whois
  
  # macOS
  brew install whois
  
  # Windows - included by default
  ```

- [ ] Internet connection available
- [ ] Approximately 100MB disk space free

## 🔧 Installation Steps

### Step 1: Dependencies
- [ ] Navigate to project directory
  ```bash
  cd /home/Vangdu/passive_recon_script
  ```

- [ ] Install Python dependencies
  ```bash
  pip install -r requirements.txt
  ```

- [ ] Verify installation
  ```bash
  pip list | grep -E "(requests|rich|click)"
  ```

### Step 2: Configuration
- [ ] Copy environment template
  ```bash
  cp .env.example .env
  ```

- [ ] Make main.py executable (Linux/Mac)
  ```bash
  chmod +x main.py
  chmod +x test_demo.py
  ```

- [ ] Verify file permissions
  ```bash
  ls -la main.py test_demo.py
  ```

### Step 3: Initial Test
- [ ] Run test demo
  ```bash
  python test_demo.py
  ```

- [ ] Expected output: "All tests passed!"

- [ ] Check if CLI works
  ```bash
  python main.py --help
  ```

- [ ] View available modules
  ```bash
  python main.py modules
  ```

## 🔑 API Configuration (Optional but Recommended)

### Free Tier APIs (No Credit Card Required)

#### GitHub (Highly Recommended)
- [ ] Go to: https://github.com/settings/tokens
- [ ] Click "Generate new token (classic)"
- [ ] Select scopes: `public_repo`, `read:user`
- [ ] Copy token and add to `.env`:
  ```
  GITHUB_TOKEN=ghp_your_token_here
  ```
- [ ] Test:
  ```bash
  python main.py run github.com -m github
  ```

#### VirusTotal (Recommended)
- [ ] Go to: https://www.virustotal.com/gui/join-us
- [ ] Sign up for free account
- [ ] Get API key from: https://www.virustotal.com/gui/my-apikey
- [ ] Add to `.env`:
  ```
  VIRUSTOTAL_API_KEY=your_key_here
  ```
- [ ] Test:
  ```bash
  python main.py run example.com -m virustotal
  ```

#### Shodan (For Advanced Features)
- [ ] Go to: https://account.shodan.io/register
- [ ] Free tier: 1 scan/month + 100 results
- [ ] Get API key from account page
- [ ] Add to `.env`:
  ```
  SHODAN_API_KEY=your_key_here
  ```
- [ ] Test:
  ```bash
  python main.py run example.com -m shodan
  ```

### Paid/Limited APIs (Optional)

#### Hunter.io
- [ ] Free tier: 25 searches/month
- [ ] Sign up: https://hunter.io/users/sign_up
- [ ] Add to `.env`: `HUNTER_API_KEY=`

#### SecurityTrails
- [ ] Free tier: 50 queries/month
- [ ] Sign up: https://securitytrails.com/app/signup
- [ ] Add to `.env`: `SECURITYTRAILS_API_KEY=`

#### URLScan
- [ ] Free tier: unlimited public scans
- [ ] Sign up: https://urlscan.io/user/signup
- [ ] Add to `.env`: `URLSCAN_API_KEY=`

#### Censys
- [ ] Free tier: 250 queries/month
- [ ] Sign up: https://censys.io/register
- [ ] Add to `.env`:
  ```
  CENSYS_API_ID=
  CENSYS_API_SECRET=
  ```

### Check API Status
- [ ] Run API key checker
  ```bash
  python main.py apikeys
  ```

- [ ] Green checkmarks = configured
- [ ] Red crosses = not configured (still works with free modules)

## 🎯 First Scan Checklist

### Test with Free Modules (No API Keys Needed)

#### DNS Intelligence
- [ ] Run DNS scan
  ```bash
  python main.py run example.com -m dns
  ```

- [ ] Check output directory
  ```bash
  ls -la outputs/dns_intelligence/
  ```

- [ ] Open HTML report
  ```bash
  xdg-open outputs/dns_intelligence/report.html  # Linux
  open outputs/dns_intelligence/report.html      # Mac
  ```

- [ ] Verify JSON output
  ```bash
  cat outputs/dns_intelligence/data.json
  ```

#### WHOIS Lookup
- [ ] Run WHOIS scan
  ```bash
  python main.py run example.com -m whois
  ```

- [ ] Check results
  ```bash
  cat outputs/whois_lookup/data.json | jq
  ```

#### Subdomain Enumeration (Uses free crt.sh)
- [ ] Run subdomain scan
  ```bash
  python main.py run example.com -m subdomain
  ```

- [ ] Count results
  ```bash
  jq '.metadata.record_count' outputs/subdomain_enumeration/data.json
  ```

### Full Scan Test
- [ ] Run all modules
  ```bash
  python main.py scan example.com --all
  ```

- [ ] Verify all module outputs
  ```bash
  ls -la outputs/
  ```

- [ ] Review summary table
- [ ] Check for any errors in output

## 📊 Verification Checklist

### Output Validation
For each module:
- [ ] JSON file exists in `outputs/<module_name>/data.json`
- [ ] HTML file exists in `outputs/<module_name>/report.html`
- [ ] JSON contains `metadata` and `results` keys
- [ ] HTML can be opened in browser
- [ ] Results are properly formatted

### Functionality Tests
- [ ] CLI shows colored output
- [ ] Progress indicators work
- [ ] Error messages are clear
- [ ] Module list displays correctly
- [ ] API status shows correctly
- [ ] Help commands work

### Common Issues
- [ ] If "Module not found": Check Python path
- [ ] If "API key error": Verify `.env` file
- [ ] If "No results": Normal for some targets
- [ ] If "Rate limit": Wait and retry
- [ ] If "Import error": Reinstall requirements

## 🚀 Ready for Production Checklist

### Before First Real Scan
- [ ] Tested with example.com
- [ ] Configured at least 3 API keys
- [ ] Verified all output formats work
- [ ] Understand module purposes
- [ ] Read usage examples
- [ ] Know where outputs are saved

### Best Practices Review
- [ ] Only scan authorized targets
- [ ] Respect rate limits
- [ ] Don't commit `.env` file to git
- [ ] Use custom output directories for organization
- [ ] Review results manually
- [ ] Keep API keys secure

### Documentation Review
- [ ] Read README.md for overview
- [ ] Check QUICKSTART.md for basics
- [ ] Review EXAMPLES.md for use cases
- [ ] Understand ARCHITECTURE.md (optional)
- [ ] Know how to add modules (MODULE_TEMPLATE.py)

## 🎓 Learning Path Checklist

### Beginner (Day 1)
- [ ] Complete installation
- [ ] Run test_demo.py
- [ ] Test DNS and WHOIS modules
- [ ] Open first HTML report
- [ ] Configure GitHub API key

### Intermediate (Week 1)
- [ ] Configure 5+ API keys
- [ ] Run full scan on test target
- [ ] Parse JSON with jq
- [ ] Create custom output workflow
- [ ] Integrate with other tools

### Advanced (Month 1)
- [ ] Create custom module
- [ ] Automate regular scans
- [ ] Set up monitoring
- [ ] Contribute improvements
- [ ] Help others in community

## 📋 Maintenance Checklist

### Weekly
- [ ] Check for API limit usage
- [ ] Review collected data
- [ ] Clean old output files if needed

### Monthly
- [ ] Update dependencies
  ```bash
  pip install --upgrade -r requirements.txt
  ```
- [ ] Check for new API sources
- [ ] Review and update API keys
- [ ] Backup important scan results

### As Needed
- [ ] Add new modules
- [ ] Update documentation
- [ ] Report issues
- [ ] Share improvements

## 🆘 Troubleshooting Checklist

### Installation Issues
- [ ] Python version correct?
  ```bash
  python --version
  ```
- [ ] All dependencies installed?
  ```bash
  pip check
  ```
- [ ] File permissions correct?
  ```bash
  ls -la main.py
  ```

### Runtime Issues
- [ ] Is `.env` file present?
  ```bash
  ls -la .env
  ```
- [ ] Are API keys formatted correctly?
  ```bash
  cat .env | grep API_KEY
  ```
- [ ] Is internet connection working?
  ```bash
  ping -c 1 google.com
  ```

### Output Issues
- [ ] Does outputs directory exist?
  ```bash
  ls -la outputs/
  ```
- [ ] Are files being created?
  ```bash
  ls -laR outputs/
  ```
- [ ] Can you read the files?
  ```bash
  cat outputs/*/data.json
  ```

## ✨ Success Criteria

You're ready when:
- ✅ All tests pass
- ✅ At least 3 modules working
- ✅ Can view HTML reports
- ✅ Can parse JSON output
- ✅ Understand basic usage
- ✅ Know where to find help

## 🎉 Congratulations!

If you've completed this checklist, you're ready to use the Passive Reconnaissance Framework for real-world security research!

### Next Steps:
1. Start with a test target (not production!)
2. Run: `python main.py scan yourtarget.com --all`
3. Review results in HTML reports
4. Extract data with jq for further analysis
5. Integrate into your workflow

### Need Help?
- Check [README.md](README.md) for details
- Review [EXAMPLES.md](EXAMPLES.md) for use cases
- Read [QUICKSTART.md](QUICKSTART.md) for basics
- Study [ARCHITECTURE.md](ARCHITECTURE.md) for technical info

---

**Happy Hunting! 🎯**

*Remember: Only scan targets you have authorization to investigate*
