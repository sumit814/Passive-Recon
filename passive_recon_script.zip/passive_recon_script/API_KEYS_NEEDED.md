# 🔑 REQUIRED API KEYS - Quick Reference

## ⚡ TL;DR - What You Need to Configure

You have **most API keys already configured**. Here's what's **missing** for the new enhanced features:

---

## 🔴 CRITICAL - Configure These Now

### For IP Reputation Analysis Module

**1. AbuseIPDB** (FREE!)
```bash
# Add to .env file:
ABUSEIPDB_API_KEY=your_key_here
```
- **Get it**: https://www.abuseipdb.com/register
- **Cost**: FREE (1,000 checks/day)
- **Why**: Essential for IP abuse reputation scoring
- **Without it**: IP reputation module will only use VirusTotal + GreyNoise (limited data)

---

### For Email Leak Check Module

**2. HaveIBeenPwned** (PAID - $3.50/month)
```bash
# Add to .env file:
HIBP_API_KEY=your_key_here
```
- **Get it**: https://haveibeenpwned.com/API/Key
- **Cost**: $3.50/month minimum
- **Why**: Most comprehensive breach database
- **Without it**: Email leak check module won't work

**3. DeHashed** (OPTIONAL - Paid, ~$2 per 100 queries)
```bash
# Add to .env file:
DEHASHED_API_KEY=your_key_here
DEHASHED_EMAIL=your_account_email
```
- **Get it**: https://dehashed.com/register
- **Cost**: Pay-per-use (~$1-2 per 100 queries)
- **Why**: Additional breach coverage
- **Without it**: Module works but with less coverage

**4. LeakCheck** (OPTIONAL - $2/month)
```bash
# Add to .env file:
LEAKCHECK_API_KEY=your_key_here
```
- **Get it**: https://leakcheck.io/api
- **Cost**: ~$2/month for basic plan
- **Why**: Extra leak database
- **Without it**: Module works but with less coverage

---

## ✅ ALREADY WORKING

These are **already configured** on your system:

- ✓ Shodan
- ✓ Censys
- ✓ ZoomEye
- ✓ LeakIX
- ✓ GreyNoise (used in IP reputation)
- ✓ Vulners
- ✓ SecurityTrails
- ✓ VirusTotal (used in IP reputation)
- ✓ Hunter.io
- ✓ IntelX
- ✓ GitHub
- ✓ URLScan

---

## 🆓 NO API KEY NEEDED

These new modules work **without any API keys**:

- ✅ **SSL/TLS Analysis** (`ssl`) - Uses direct TLS connection
  ```bash
  python main.py run example.com -m ssl
  ```

---

## 📊 Module Functionality Matrix

| Module | Works Now? | With What? | Missing Keys Impact |
|--------|-----------|-----------|---------------------|
| **iprep** | ⚠️ Partial | VirusTotal + GreyNoise | Missing AbuseIPDB = incomplete reputation scoring |
| **ssl** | ✅ Full | Direct connection | N/A - No keys needed |
| **leakcheck** | ❌ Limited | None | Missing HIBP = no breach data |

---

## 🎯 Recommended Priority

### Priority 1 (Do This First)
1. **AbuseIPDB** - FREE, takes 5 minutes to set up
   - Makes IP reputation module fully functional
   
### Priority 2 (If Budget Allows)
2. **HaveIBeenPwned** - $3.50/month
   - Enables email leak check module
   - Most comprehensive breach database

### Priority 3 (Nice to Have)
3. **DeHashed** + **LeakCheck** - Pay-per-use or $2/month
   - Additional coverage for email leak checks

---

## 🚀 Quick Setup Steps

### Step 1: Install New Dependency
```bash
pip install pyOpenSSL
```

### Step 2: Get Free API Key (5 minutes)
1. Go to https://www.abuseipdb.com/register
2. Create account
3. Navigate to Account → API
4. Copy your API key
5. Add to `.env` file:
   ```bash
   ABUSEIPDB_API_KEY=paste_your_key_here
   ```

### Step 3: Test It
```bash
# Check status
python main.py apikeys

# Test modules
python main.py run example.com -m ssl      # No key needed
python main.py run example.com -m iprep    # Needs AbuseIPDB
```

---

## 📈 What You Get

### With Just AbuseIPDB (FREE):
- ✅ Complete IP reputation analysis
- ✅ Multi-source threat intelligence (3 sources)
- ✅ Full SSL/TLS security analysis
- ⚠️ Limited email leak checking (need HIBP)

### With AbuseIPDB + HIBP ($3.50/month):
- ✅ Complete IP reputation analysis
- ✅ Full SSL/TLS security analysis
- ✅ Complete email leak checking
- ✅ All new features fully functional

---

## ❓ FAQ

**Q: Can I use the script without any new keys?**
A: Yes! SSL/TLS analysis works without any keys. IP reputation works with limited data (using existing VirusTotal + GreyNoise keys).

**Q: What's the minimum I need to spend?**
A: Zero! AbuseIPDB is free. However, $3.50/month for HIBP unlocks email leak checking.

**Q: Will the script break if I don't add new keys?**
A: No. All modules gracefully handle missing keys and report what's available.

**Q: How do I check which keys are configured?**
A: Run `python main.py apikeys`

**Q: Where do I add the API keys?**
A: Edit the `.env` file in the script directory. Create it from `.env.example` if it doesn't exist.

---

## 📞 Next Steps

1. **Read full guide**: `API_KEYS_GUIDE.md`
2. **See improvements**: `IMPROVEMENTS_SUMMARY.md`
3. **Test script**: `python main.py modules`
4. **Get AbuseIPDB** (free!): https://www.abuseipdb.com/register

---

**Quick Command Reference:**
```bash
# Check API status
python main.py apikeys

# List all modules
python main.py modules

# Test SSL analysis (no key needed)
python main.py run example.com -m ssl

# Test IP reputation (needs AbuseIPDB)
python main.py run example.com -m iprep

# Run everything
python main.py scan example.com --all
```

---

**Last Updated**: December 2024
