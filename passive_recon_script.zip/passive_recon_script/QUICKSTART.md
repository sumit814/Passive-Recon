# 🚀 Quick Start Guide

Get up and running with Passive Recon Framework in 5 minutes!

## Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

## Step 2: Configure API Keys (Optional)

Edit the `.env` file and add your API keys:

```bash
nano .env
```

**Minimum recommended APIs** (all have free tiers):
- GitHub Token (for code search)
- VirusTotal API Key (for domain intel)
- Shodan API Key (for internet scanning)

**Get these first:**
```
GITHUB_TOKEN=ghp_your_token_here
VIRUSTOTAL_API_KEY=your_vt_key_here
SHODAN_API_KEY=your_shodan_key_here
```

## Step 3: Test the Installation

Check if everything works:

```bash
python main.py modules
```

You should see a beautiful table of available modules!

## Step 4: Check API Status

```bash
python main.py apikeys
```

This shows which API keys are configured.

## Step 5: Run Your First Scan

**Test with a simple module (no API key required):**

```bash
python main.py run example.com -m dns
```

**Or try subdomain enumeration (works with crt.sh - no API needed):**

```bash
python main.py run example.com -m subdomain
```

**Run everything at once:**

```bash
python main.py scan example.com --all
```

## 📊 View Results

Results are saved in two formats:

1. **JSON** - `outputs/<module_name>/data.json`
2. **HTML** - `outputs/<module_name>/report.html`

Open the HTML file in your browser for a beautiful report!

```bash
# On Linux
xdg-open outputs/subdomain_enumeration/report.html

# On Mac
open outputs/subdomain_enumeration/report.html

# On Windows
start outputs/subdomain_enumeration/report.html
```

## 🎯 Common Use Cases

### Bug Bounty Recon
```bash
# Get all intelligence on target
python main.py scan target.com --all

# Focus on attack surface
python main.py run target.com -m subdomain
python main.py run target.com -m certificate
python main.py run target.com -m shodan
```

### Quick Domain Check
```bash
python main.py run example.com -m dns
python main.py run example.com -m whois
python main.py run example.com -m virustotal
```

### Email Intelligence
```bash
python main.py run company.com -m email
```

### GitHub Secrets Hunting
```bash
python main.py run company.com -m github
```

## 🔧 Troubleshooting

**Problem: Module shows "API key not configured"**
- Solution: Add the required API key to `.env` file

**Problem: "No results found"**
- This is normal! Not all targets have data in all sources
- Try different modules
- Check if the domain/IP is correct

**Problem: Rate limit errors**
- Wait a few minutes and try again
- Upgrade to paid API tier for higher limits
- Use different API keys for different scans

**Problem: Import errors**
- Run: `pip install -r requirements.txt` again
- Check Python version: `python --version` (needs 3.8+)

## 💡 Pro Tips

1. **Start with free modules** (dns, whois, subdomain via crt.sh)
2. **Get GitHub token first** - it's free and very useful
3. **Run modules individually** while learning
4. **Save API keys** for important targets (Shodan credits are limited)
5. **Check outputs directory** regularly to avoid confusion
6. **Use custom output paths** for organized scanning:
   ```bash
   python main.py scan target.com --all --output ./scans/target-com
   ```

## 📚 Next Steps

1. Read the full [README.md](README.md)
2. Configure more API keys for better coverage
3. Explore individual module outputs
4. Create custom modules for your needs
5. Integrate outputs into your workflow

## 🎓 Learning Resources

### Getting API Keys
- GitHub: Settings → Developer settings → Personal access tokens
- VirusTotal: Sign up → Profile → API Key
- Shodan: Account → API Key
- Hunter.io: Sign up → API tab

### Understanding Results
- **Subdomains**: Look for staging, dev, admin subdomains
- **Certificates**: Check for internal domain names
- **GitHub**: Search for credentials, API keys, secrets
- **Emails**: Useful for social engineering assessments
- **Shodan**: Find exposed services and technologies

## ⚡ Quick Reference

```bash
# Show help
python main.py --help

# List modules
python main.py modules

# Check API keys
python main.py apikeys

# Run single module
python main.py run <target> -m <module>

# Run all modules
python main.py scan <target> --all

# Custom output
python main.py scan <target> --all -o /path/to/output
```

---

**Need help?** Check the main [README.md](README.md) or open an issue!

Happy hunting! 🎯
